<?php
	include_once("../functions.php");
	unset($_SESSION['tempPayment']);
	$amount = $common->get_prep($_POST['amount']);
	$send_currency = $common->get_prep($_POST['send_currency']);
	$dectt_fee = $common->get_prep($_POST['dectt_fee']);
	
	$rate = $settings->getOne($send_currency);
	
	$fee = (10/100)*$amount;
	$total = $fee+$amount;
	if ($dectt_fee === "true") {
		$balance = $total- $fee;
	} else {
		$balance = $total;
	}
	
	$xchange = $balance*$rate;
	
	$_SESSION['tempPayment']['amount'] = $amount;
	$_SESSION['tempPayment']['dectt_fee'] = $dectt_fee;
	$_SESSION['tempPayment']['send_currency'] = $send_currency;
	$_SESSION['tempPayment']['fee'] = $fee;
	$_SESSION['tempPayment']['total'] = $total;
	$_SESSION['tempPayment']['balance'] = $balance;
	$_SESSION['tempPayment']['xchange'] = $rate;
	
	echo $result = number_format($fee, 2)."_".number_format($total, 2)."_".number_format($balance, 2)."_".number_format($xchange, 2)."_".number_format($rate, 2);
?>