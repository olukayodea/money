<?php
	$redirect = "sendMoney";
	include_once("includes/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Welcome to PayMack</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body>
<!--Model login-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Log in to your PayMack Account</span></div>
      </div>
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15">
        	<input name="redirect" id="redirect" type="hidden" value="<?php echo $redirect; ?>">
          <input type="email" name="email" id="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="password" id="password" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
         <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-green1" href="Javascript:void(0)" onClick="login()" id="login_button">LOG IN</a>
           </p>
         </div>
        <div class="forgotten-password"><a href="#" data-dismiss="modal" data-target="#myModal5" data-toggle="modal">Forgotten your password?</a> </div>
        <p class="text-center font-size14 margin-top20">Don’t have an Account? <a href="#" class="text-red" data-dismiss="modal" data-target="#myModal2" data-toggle="modal"><strong>Sign up</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model login-->

<!--Model singup-->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content  model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Create an Account with PayMack</span></div>
      </div>
		<input name="redirect" id="redirect2" type="hidden" value="<?php echo $redirect; ?>">
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue2" style="color:#F00; display:none" align="center"></div>
        <!-- <div class="padding-left-right15">
          <input type="text" name="fullNames" id="fullNames" placeholder="Full Names" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Full Names'" class="form-control">
        </div> -->
        <div class="padding-left-right15 margin-top15">
          <input type="text" name="createEmail" id="createEmail" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control" onChange="checkEmail(this.value)">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="newPassword" id="newPassword" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Confirm Password'"  class="form-control">
        </div>
        <p class="text-center font-size11 margin-top15">By signing up, you are agreeing to PayMack’s <br>
          <a class="margin-right5" href="terms-conditions.php" target="_blank"><u>Terms and Conditions</u></a> and <a class="margin-left5" href="privacy-policy.php" target="_blank"><u>Privacy Policy</u></a></p>
        <!--<div class="text-center"> <a href="registration.html" class="btn btn-red btn-signup" type="button">SIGN UP</a> </div>-->
        <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-red1" href="Javascript:void(0)" onClick="register()" id="register_button">SIGN UP</a>
           </p>
         </div>
        
        <p class="text-center font-size14 margin-top4">Already have an account? <a href="#" class="text-green" data-toggle="modal" data-target="#myModal" data-dismiss="modal"><strong>Log in</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model singup--> 

<!--Model Forgotten your password-->
<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Reset Your PayMack Password</span></div>
         <p class="forgotten-text">Enter the email address you registered with and we will send <br>you an email with a link to reset your password </p>
      </div>
		<input name="redirect" id="redirect3" type="hidden" value="<?php echo $redirect; ?>">
        
        <div class="padding-left-right15" id="notificationDialogue3" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15" id="notificationDialogue4" style="color:#060; display:none" align="center"></div>
      <div class="modal-body form-horizontal modal-box">
        <div class="padding-left-right15">
          <input name="forgotPassword" id="forgotPassword" type="text" placeholder="Enter your email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your email address'" class="form-control">
        </div>
        <div class="send-email"> <a href="Javascript:void(0)" onClick="remeberPassword()" class="btn btn-green btn-login2" type="button">SEND EMAIL</a> </div>
      </div>
    </div>
  </div>
</div>
<!--Model Forgotten your password-->  
<!--Model Get Started Now--> 

<?php $pages->topMenu(); ?>
  
  <!--Banner-->
  <div class="banner-panel">
    <div class="container">
      <div class="row">
        <div class="banner-text">
          <div class="font-size30"><strong>THE SMARTEST WAY TO SEND</strong></div>
          <h4><strong>MONEY ABROAD</strong></h4>
          <div class="font-size22 margin-bottom20"><strong>Send Money Online to a Bank Account Abroad <br>
            Using your Debit or Credit Card</strong></div>
        </div>
        <div id="from-panel">
            <div class="form-horizontal banner-right-con">
              	<div id="status" style="color:#F00"></div>
              <div class="form-group">
                <label for="service" class="col-xs-3 control-label text-center paddingTop0">Select Servicee</label>
                <div class="col-xs-6">
                  <select name="service" id="service" class="form-control" style="width:100%" onChange="selectService()">
                    <option value="none">Select a Service</option>
                    <option value="Airtime">Send Airtime</option>
                    <option value="Money">Send Money</option>
                    <option value="Bills">Pay Bills</option>
                  </select>
                </div>
              </div>
              <div id="payBills" style="display:none"></div>
              <div id="sendAirtime" style="display:none"></div>
              <div id="sendMoney" style="display:none">
                  <div class="form-group">
                    <label class="col-xs-3 control-label text-center paddingTop0">I want to <br>
                      send</label>
                    <div class="col-xs-6">
                      <input type="text" name="amount" id="amount" class="form-control" onChange="calculateCharges()">
                    </div>
                    <div class="col-xs-3 dark padding-left0">
                      <select name="send_currency" id="send_currency" class="country-select" style="width:100%" onChange="calculateCharges()">
                        <!--<option value="CA">CAD</option>
                        <option value="US">USD</option>-->
                        <option value="GB" selected>GBP</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-3 control-label text-center">To</label>
                    <div class="col-xs-6">
                      <select name="dest_country" id="dest_country" class="country-select" style="width:100%">
                        <option selected value="NG">Nigeria</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group margin-bottom0">
                    <label class="col-xs-3 control-label text-center">Our Fees</label>
                    <div class="col-xs-6">
                      <input readonly type="text" name="fee" id="fee" class="form-control">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-xs-3"></div>
                    <div class="col-xs-9">
                        <input type="checkbox" name="dectt_fee" value="true" id="dectt_fee" onChange="calculateCharges()" onclick="calculateCharges()">
                        <label for="dectt_fee"><small>Deduct fees from send amount</small></label>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-3 control-label text-center paddingTop0">Total to <br>
                      Pay</label>
                    <div class="col-xs-6">
                      <input readonly type="text" name="total_pay" id="total_pay" class="form-control">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-3 control-label text-center paddingTop0">Recipient Receives</label>
                    <div class="col-xs-6">
                      <input type="text" name="rec_amount" id="rec_amount" value="" class="form-control" readonly>
                    </div>
                    <div class="col-xs-3 dark padding-left0">
                      <select name="s2" class="country-select" style="width:100%">
                        <option selected value="NG">NGN</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-3 control-label text-center paddingTop0">Receives <br>
                      by</label>
                    <div class="col-xs-6">
                      <select class="single-select" name="rec_medium" id="rec_medium" style="width:100%">
                        <option value="access">Bank Transfer</option>
                      </select>
                      <span class="margin-top4 font-size11 margin-left10" id="conversionRate"></span></div>
                      
                  </div>
                  <div class="form-group">
                    <!--<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-xs-offset-3 text-center"> <a href="#" data-toggle="modal" data-target="#myModal3" class="btn btn-green btn-block send-btn">Send Now</a> </div>-->
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-xs-offset-3 text-center"> <a href="#" onClick="sendMoney()" style="display:block" class="btn btn-green btn-block send-btn">Send Now</a> </div>
                  </div>
              </div>
            </div>
        </div>
        </div>
      </div>
    </div>
  <!--/Banner--> 
  
  <!--Gray box-->
  <div class="gray-box">
    <div class="container">
      <div class="row"> 
        <div class="col-xs-6 col-sm-5 col-md-4 col-lg-3">
          <span class="font-size18 margin-top10"><strong>All Major Credit and Debit Cards Accepted</strong></span> 
        </div>
        <div class="col-xs-6 col-sm-6 col-md-5 col-lg-5 visa-icon">
          <img src="images/Visa.png">
          <img src="images/MasterCard_Logo.png"> 
          <img src="images/MasterCard_Logo-2.png"> 
          <img class="x-small" src="images/American_Express.png">
        </div>
        <div class="hidden-xs hidden-sm col-md-3 col-lg-4 text-right">
          <span class="btn-started"> <a href="#" data-toggle="modal" data-target="#myModal4" class="btn btn-red get-slider">Get Started Now</a> </span>
        </div>
      </div>
    </div>
  </div>
  <!--/Gray box--> 
  
  <!--OUR CUSTOMERS CHOOSE-->
  <div class="bag-img">
    <div class="container margin-top20">
      <h3 class="text-center">WHY OUR CUSTOMERS CHOOSE US</h3>
      <div class="row margin-top30">
        <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
          <div class="text-center"><img class="service-img" src="images/Low-Cost-Service.png"></div>
          <p class="text-service">LOW COST SERVICE</p>
          <p class="text-center">Our super low fees and excellent <br>
            exchange rates make us the first </br>choice amongst
            our customers.</p>
        </div>
        <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
          <div class="text-center"><img class="service-img" src="images/Safety-and-Security.png"></div>
          <p class="text-service">SAFETY AND SECURITY</p>
          <p class="text-center">We utilise proven privacy and </br>payment security
            technology to </br>protect our customers'
            information.</p>
        </div>
        <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
          <div class="text-center"><img class="service-img" src="images/Fast-and-Reliable.png"></div>
          <p class="text-service">FAST AND RELIABLE</p>
          <p class="text-center">95% of our transfers are delivered </br>instantly. We
            keep our customers </br>updated via email every step
            of </br>the way.</p>
        </div>
        <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
          <div class="text-center"><img class="service-img" src="images/MBG.png"></div>
          <p class="text-service">MONEY BACK GUARANTEE</p>
          <p class="text-center">If a payment is cancelled or refused for </br>any
            reason, the payment will be </br>returned in full to the
            customer's card </br>or bank account.</p>
        </div>
        <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
          <div class="text-center"><img class="service-img" src="images/no_hidden_charges.png"></div>
          <p class="text-service">NO HIDDEN CHARGES</p>
          <p class="text-center">We offer our customers transparent, </br>crystal clear
            and simple pricing. </br>Absolutely no hidden
            charges.</p>
        </div>
        <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
          <div class="text-center"><img class="service-img" src="images/Fully-Regulated.png"></div>
          <p class="text-service">FULLY REGULATED</p>
          <p class="text-center">We are fully regulated by the FCA <br>and registered
            with HMRC in the <br>United Kingdom. We are in<br>
            compliance with regulations that <br>provide
            our customers with <br>protections and rights
            under the law.</p>
        </div>
      </div>
    </div>
  </div>
  <!--/OUR CUSTOMERS CHOOSE--> 
  
  <!--MONEY TRANSFER MADE EASY-->
  <div class="sky-box-panel">
    <div class="container">
      <h3 class="text-center">MONEY TRANSFER MADE EASY</h3>
      <p class="text-center font-size20 text-sky"><strong>Send Money in 3 Simple Steps</strong></p>
      <div class="row margin-top50">
          <div class="col-xs-12  col-sm-12 col-md-2 col-lg-2 col-md-offset-1 col-lg-offset-1 padding-all-0">
          <div class="all-rounded-box icon-red">
            <p class="icon-text"><span class="font-size23"><strong>1</strong></span><br>
              <span class="text-amount"><strong>Enter <br>
              Amount to </br>Send</strong></span></p>
            <p class="small-text-con hidden-md hidden-lg">Enter the amount you want to send, select the  transfer destination and choose how you want your recipient to receive the money.</p>
          </div>
        </div>
          <div class="hidden-xs hidden-sm col-md-2 col-lg-2  margin-top80 text-center"> <img src="images/icon-img-sky.png" class="img-box"> </div>
          <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 padding-all-0">
          <div class="all-rounded-box icon-yellow">
            <p class="icon-text"><span class="font-size23"><strong>2</strong></span><br>
              <span class="text-amount"><strong>Add <br>
              Recipient's </br>Details</strong></span></p>
            <p class="small-text-con hidden-md hidden-lg">Add the name of your recipient , their account details and provide us with their contact details.</p>
          </div>
        </div>
          <div class="hidden-xs hidden-sm col-md-2 col-lg-2 margin-top80 text-center"> <img src="images/icon-img-sky.png" class="img-box"> </div>
          <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 padding-all-0">
          <div class="all-rounded-box icon-green">
            <p class="icon-text"><span class="font-size23"><strong>3</strong></span><br>
              <span class="text-amount"><strong>Confirm & <br>
              Send Money</strong></span></p>
            <p class="small-text-con hidden-md hidden-lg padding-top30">Review and confirm the amount you wish to send, enter your payment details and submit.</p>  
          </div>
        </div>
      </div>
      <div class="row how-works-btn hidden-xs hidden-sm">
        <span><a class="text-btn" href="how-it-works.php">How it Works</a></span>
      </div>
    </div>
  </div>
  <!--/MONEY TRANSFER MADE EASY--> 
  
  <!--WAYS TO SEND MONEY-->
  <div class="gray-box">
    <div class="container">
      <h3 class="text-gray2 send-money-panel">WAYS TO SEND MONEY</h3>
      <div class="row margin-top50 margin-bottom20">
        <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4 col-md-offset-2">
          <div class="text-center"><img class="service-img" src="images/Debit-credit-card.png"></div>
          <p class="text-transfer">BY DEBIT / CREDIT CARD</p>
          <p class="text-center">Money can be sent using a debit or credit card <br>
            in exactly the same way a payment is made <br>
            for goods at online shops.</p>
        </div>
        <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
          <div class="text-center"><img class="service-img" src="images/Bank-Transfer.png"></div>
          <p class="text-service">BY BANK TRANSFER</p>
          <p class="text-center">Money can be sent by online bank transfer <br>
            directly into PayMack’s bank account in <br>
            exactly the same way money is transferred <br>
            online to any other bank account.</p>
        </div>
      </div>
    </div>
  </div>
  <!--/WAYS TO SEND MONEY--> 
  
  <!--WAYS TO RECEIVE MONEY-->
  <div class="container margin-top20">
    <h3 class="text-center">WAYS TO RECEIVE MONEY</h3>
    <div class="row margin-top50">
      <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
        <div class="text-center"><img class="service-img" src="images/Bank-Transfer.png"></div>
        <p class="text-service">BANK TRANSFER</p>
        <p class="text-center">Money can be received directly into <br>the recipient’s bank account.</p>
      </div>
      <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
        <div class="text-center"><img class="service-img" src="images/Mobile-Airtime.png"></div>
        <p class="text-withdrawal">MOBILE AIRTIME</p>
        <p class="text-center">Money can be received instantly as <br>mobile credit to top-up recipient's <br>mobile airtime.</p>
      </div>
      <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
        <div class="text-center"><img class="service-img" src="images/Mobile-Wallet.png"></div>
        <p class="text-withdrawal">MOBILE WALLET</p>
        <p class="text-center">Money can be received into the <br>recipient's mobile money wallet</p>
      </div>
    </div>
      <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
        <div class="text-center"><img class="service-img" src="images/atm-icon.png"></div>
        <p class="text-withdrawal">CARDLESS ATM WITHDRAWAL</p>
        <p class="text-center">Money can be withdrawn from an ATM using <br>a code sent via sms to the recipient's mobile <br>phone. No card required</p>
      </div>
      <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
        <div class="text-center"><img class="service-img" src="images/Visa-Prepaid.png"><img class="margin-left10 service-img" src="images/prepaid.png" width="100" height="auto"></div>
        <p class="text-withdrawal">PREPAID DEBIT CARDS</p>
        <p class="text-center">Money can be received into a prepaid  <br>virtual Visa or MasterCard account.<br> Recipient's virtual prepaid account will <br>be set up automatically. No bank <br>required.</p>
      </div>
      <div class="service-box col-xs-12 col-sm-12 col-md-4 col-lg-4">
        <div class="text-center"><img class="service-img" src="images/Pay-Bills.png"></div>
        <p class="text-withdrawal">BILL PAYMENT</p>
        <p class="text-center">Money can be received as online <br>payments for bills or invoices to 3rd <br>party companies.</p>
      </div>
  </div>
  <!--/WAYS TO RECEIVE MONEY--> 
  
  <!--OUR CUSTOMERS ARE SAYING-->
  <div class="sky-box-slider">
    <div class="container">
      <h3 class="text-center">WHAT OUR CUSTOMERS ARE SAYING</h3>
      <div id="carousel-example-generic" class="carousel slide" data-ride="carousel"> 
        <!-- Wrapper for slides -->
        <div class="carousel-box">
          <div class="carousel-inner" role="listbox">
            <div class="item active">
              <div class="icon-box">
                <div class="icon-img"><img class="text-img" src="images/man-img.png"></div>
              </div>
              <h5 class="text-white"><?php echo $last_name." ".$other_names; ?> Glasgow</h5>
              <div class="carousel-caption"> "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper porta. Mauris massa. Vestibulum lacinia arcu eget nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur sodales ligula in libero. Sed dignissim lacinia nunc. Curabitur tortor. Pellentesque nibh. Aenean quam. In scelerisque sem at dolor. Maecenas mattis. Sed convallis tristique sem. Proin ut ligula vel nunc egestas porttitor."
                <div class="carousel-notes"> </div>
              </div>
            </div>
            <div class="item">
              <div class="icon-box">
                <div class="icon-img"><img src="images/man-img.png"></div>
              </div>
              <div class="carousel-caption"> "sss, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper porta. Mauris massa. Vestibulum lacinia arcu eget nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur sodales ligula in libero. Sed dignissim lacinia nunc. Curabitur tortor. Pellentesque nibh. Aenean quam. In scelerisque sem at dolor. Maecenas mattis. Sed convallis tristique sem. Proin ut ligula vel nunc egestas porttitor." </div>
            </div>
            <div class="item">
              <div class="icon-box">
                <div class="icon-img"><img src="images/man-img.png"></div>
              </div>
              <div class="carousel-caption"> "ssssss, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper porta. Mauris massa. Vestibulum lacinia arcu eget nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur sodales ligula in libero. Sed dignissim lacinia nunc. Curabitur tortor. Pellentesque nibh. Aenean quam. In scelerisque sem at dolor. Maecenas mattis. Sed convallis tristique sem. Proin ut ligula vel nunc egestas porttitor." </div>
            </div>
          </div>
        </div>
        <!-- Controls --> 
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev"> <img class="responsive-img" src="images/icon-left.png"> <span class="sr-only">Previous</span> </a> <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next"> <img class="responsive-img" src="images/icon-right.png"> <span class="sr-only">Next</span> </a> 
        
        <!-- Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
          <li data-target="#carousel-example-generic" data-slide-to="1"></li>
          <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        </ol>
      </div>
    </div>
  </div>
  <!--/OUR CUSTOMERS ARE SAYING--> 
  
  <?php $pages->homeFooter(); ?>
<script language="javascript" src="js/home.js"></script>
</body>
</html>