<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>
<form method="post" action="">
  <table width="100%" border="2" cellpadding="1">
    <tr>
      <td>name</td>
      <td><label for="textfield"></label>
      <input type="text" name="textfield" id="textfield"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Submit"></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
</body>
</html>