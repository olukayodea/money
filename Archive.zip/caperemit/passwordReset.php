<?php
	include_once("includes/functions.php");
	$id = $common->get_prep($_REQUEST['id']);
	$token = $common->get_prep($_REQUEST['token']);
	
	$token_data = base64_decode($token);
	$token_split = explode("+", $token_data);
	
	if (isset($_POST['submit'])) {
		$edit = $users->updatePassword($_POST);
		
		if ($edit) {
			header("location: login?done");
		} else {
			header("location: login?error");
		}
	}
	
	if (sha1($id) !=  $token_split[1]) {
		$error = "This request is invalid";
	} else if (time() > $token_split[2]) {
		$error = "This link has expired, please try a new password reset";
	} else {
		$error = false;
		$data = $users->listOne($token_split[0]);
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Login</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationConfirm.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css">
<link href="SpryAssets/SpryValidationConfirm.css" rel="stylesheet" type="text/css">
</head>
<body class="my-account">
<?php $pages->topMenu($redirect); ?>
  
  <!--Body Part-->
  <div class="gray-bg">
    <div class="container">
      <div class="row margin-top10"> 
        <!--REGISTRATION-->
        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" id="main-body">
          <div class="white-bg">
            <h2 class="header registration-box hidden-xs hidden-sm"><i class="glyphicons glyphicons-user"></i> RESET PASSWORD</h2>
            <p>&nbsp;</p>
            <?php if ($error) { ?>
            <p class="text-center font-size14" style="color:#F00;" align="center"><?php echo $error; ?></p>
            <?php } else { ?>
            <p class="text-center font-size14">Hello <?php echo $data['last_name']." ".$data['other_names']; ?>, you recntly requested a password reset, pleease enter your new password to continue. If you didn't make this request or you don't want to change the password at this time, please ignore this message</p>
            
            <p class="text-center font-size14" id="notificationDialogue" style="color:#F00; display:none" align="center"></p>
            <div class="form-horizontal">
              <div class="row margin-top30 choose-box">
                <div class="col-xs-12 margin-left20">
                  <form name="form1" method="post" action="">
                  <div class="form-group">
                    <div class="col-xs-3 text-center">
                      <input type="hidden" name="id" id="id" value="<?php echo $id; ?>">
                      <input type="hidden" name="token" id="token" value="<?php echo $token; ?>">
                    <input name="ref" id="ref" type="hidden" value="<?php echo $token_split[0]; ?>">
                      <label for="password" class="control-label">New Password</label>
                    </div>
                    <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6"><span id="sprypassword1">
                    <input type="password" name="password" id="password" placeholder="New Password" onFocus="this.placeholder = ''" onBlur="this.placeholder = 'New Password'" class="form-control">
                    <span class="passwordRequiredMsg">A value is required.</span><span class="passwordMinCharsMsg">Minimum number of characters not met.</span></span></div>
                    <div class="pull-left margin-top10"> <span class="text-red">*</span> </div>
                  </div>
                  <div class="form-group margin-top24">
                    <div class="col-xs-3 text-center">
                      <label for="confirmPassword" class="control-label">Confirm Password</label>
                    </div>
                    <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6"><span id="spryconfirm1">
                      <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" onFocus="this.placeholder = ''" onBlur="this.placeholder = 'Confirm Password'" class="form-control">
                    <span class="confirmRequiredMsg">A value is required.</span><span class="confirmInvalidMsg">The values don't match.</span></span></div>
                    <div class="pull-left margin-top10"> <span class="text-red">*</span> </div>
                  </div>
                  <div class="row margin-top30">
                     <p class="continue-btn">
                      <button class="btn-sky" name="submit" id="submit" type="submit">CHANGE PASSWORD</button>
                     </p>
                    </div>
                    </form>
                </div>
              </div>
            </div>
            <?php } ?>
          </div>
        </div>
        <!--/REGISTRATION--> 
        
        <!--Icon-Panel-->
        <div class="col-xs-4 col-sm-12 col-md-12 col-lg-12 hidden-xs hidden-sm" id="sidebar">
          <div class="white-bg padding-top15">
            <div class="padding-left-right15 clearfix">
              <div id="box-panel"> 
              	<a href="sendMoney" class="money-box"> <span class="glyphicons glyphicons-credit-card font-size45"></span><span class="margin-top15 all-icon-box">Send Money</span> </a> 
                <a href="send-mobile-airtime.php" class="send-mobile-box"> <span><img src="images/mobile-phone-icon.png" height="44"></span><span class="margin-top15 all-icon-box">Send  Mobile Airtime</span> </a> 
                <a href="pay-bills.php"class="pay-bills-box"> <span><img src="images/bill.png" width="37" height="auto"></span><span class="margin-top15 all-icon-box">Pay Bills</span> </a> 
                <a href="myPayments" class="payments-box"> <span class="glyphicons glyphicons-circle-arrow-right small-payments-text"></span><span class="margin-top15 all-icon-box">My Payments</span> </a> 
                <a href="profile" class="profile-box"> <span class="glyphicons glyphicons-user font-size45"></span><span class="margin-top15 all-icon-box">My Profile</span> </a> 
                <a href="myRecipientList"class="recipients-box"> <span class="glyphicons glyphicons-group small-payments-text"></span><span class="margin-top15 all-icon-box">My Recipients</span> </a> 
                <a href="invite-friends.php" class="invite-box"> <span class="glyphicons glyphicons-user-add small-payments-text"></span><span class="margin-top15 all-icon-box">Invite Friends</span> </a> 
                <a href="changePassword" class="password-box"> <span class="glyphicons glyphicons-lock"></span><span class="margin-top15 all-icon-box">Change Password</span> </a> 
             </div>
            </div>
          </div>
        </div>
        <!--/Icon-Panel--> 
      </div>
    </div>
  </div>
  
  <!--/Body Part--> 
  
  <?php $pages->homeFooter(); ?>
<script language="javascript" src="js/home.js"></script>
<script type="text/javascript">
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1", {minChars:8});
var spryconfirm1 = new Spry.Widget.ValidationConfirm("spryconfirm1", "password");
</script>
</body>
</html>