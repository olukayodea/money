<?php
	$redirect = "sendMoney";
	include_once("includes/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Terms and Conditions</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body>

<!--Model login-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Log in to your PayMack Account</span></div>
      </div>
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15">
        	<input name="redirect" id="redirect" type="hidden" value="<?php echo $redirect; ?>">
          <input type="email" name="email" id="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="password" id="password" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
         <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-green1" href="Javascript:void(0)" onClick="login()" id="login_button">LOG IN</a>
           </p>
         </div>
        <div class="forgotten-password"><a href="#" data-dismiss="modal" data-target="#myModal5" data-toggle="modal">Forgotten your password?</a> </div>
        <p class="text-center font-size14 margin-top20">Don’t have an Account? <a href="#" class="text-red" data-dismiss="modal" data-target="#myModal2" data-toggle="modal"><strong>Sign up</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model login-->

<!--Model singup-->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content  model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Create an Account with PayMack</span></div>
      </div>
		<input name="redirect" id="redirect2" type="hidden" value="<?php echo $redirect; ?>">
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue2" style="color:#F00; display:none" align="center"></div>
        <!-- <div class="padding-left-right15">
          <input type="text" name="fullNames" id="fullNames" placeholder="Full Names" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Full Names'" class="form-control">
        </div> -->
        <div class="padding-left-right15 margin-top15">
          <input type="text" name="createEmail" id="createEmail" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control" onChange="checkEmail(this.value)">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="newPassword" id="newPassword" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Confirm Password'"  class="form-control">
        </div>
        <p class="text-center font-size11 margin-top15">By signing up, you are agreeing to PayMack’s <br>
          <a class="margin-right5" href="terms-conditions.php" target="_blank"><u>Terms and Conditions</u></a> and <a class="margin-left5" href="privacy-policy.php" target="_blank"><u>Privacy Policy</u></a></p>
        <!--<div class="text-center"> <a href="registration.html" class="btn btn-red btn-signup" type="button">SIGN UP</a> </div>-->
        <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-red1" href="Javascript:void(0)" onClick="register()" id="register_button">SIGN UP</a>
           </p>
         </div>
        
        <p class="text-center font-size14 margin-top4">Already have an account? <a href="#" class="text-green" data-toggle="modal" data-target="#myModal" data-dismiss="modal"><strong>Log in</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model singup--> 

<!--Model Forgotten your password-->
<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Reset Your PayMack Password</span></div>
         <p class="forgotten-text">Enter the email address you registered with and we will send <br>you an email with a link to reset your password </p>
      </div>
		<input name="redirect" id="redirect3" type="hidden" value="<?php echo $redirect; ?>">
        
        <div class="padding-left-right15" id="notificationDialogue3" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15" id="notificationDialogue4" style="color:#060; display:none" align="center"></div>
      <div class="modal-body form-horizontal modal-box">
        <div class="padding-left-right15">
          <input name="forgotPassword" id="forgotPassword" type="text" placeholder="Enter your email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your email address'" class="form-control">
        </div>
        <div class="send-email"> <a href="Javascript:void(0)" onClick="remeberPassword()" class="btn btn-green btn-login2" type="button">SEND EMAIL</a> </div>
      </div>
    </div>
  </div>
</div>
<!--Model Forgotten your password--> 

<?php $pages->topMenu(); ?>
<!--Body Part-->
 <div class="main-container">
  <div class="container margin-bottom50">
    <div class="row margin-top10 margin-bottom20"> 
      <!--From-left-panel-->
      <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
        <div id="box-con" class="all-box-panel hidden-xs hidden-sm">
        <div class="red-box"><a href="terms-conditions.php">Terms & Conditions</a></div>
        <div class="gray-box-con"><a href="privacy-policy.php">Privacy Policy</a></div>
        <div class="gray-box-con"><a href="cookie-policy.php">Cookie Policy</a></div>
        </div>
      </div>
      <!--/From-left-panel--> 
      
      <!--ABOUT US-->
      <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
         <h2 class="border-panel"><strong>TERMS & CONDITIONS</strong></h2>
              <ul class="number">
                 <li class="margin-top20">
                 		<h6>INTRODUCTION</h6>
                    <ul class="point">
                      <li><span class="number-line">1.1</span>These Terms and Conditions govern the terms under which you may access and use this website and the services associated with it (together, the "<strong>Service</strong>"). By accessing, registering with and using the Service, you agree to be bound by the terms of these Terms and Conditions. If you do not wish to be bound by these Terms and Conditions, do not access, register with or use the Service. The language of these Terms and Conditions is English and all Services, instructions and transactions carried out in connection with it shall be in English.</li>
                   	  <li><span class="number-line">1.2</span>In these Terms and Conditions, the terms "<strong>PayMack</strong>", "<strong>we</strong>", "<strong>us</strong>", and "<strong>our</strong>" refer to PayMack Ltd, together with its employees, directors, affiliates, successors, and assigns. PayMack Limited is a company registered in England and Wales with registration number <strong>9756778</strong>, with its registered office at <strong>47 Stanley Road Stevenage Hertfordshire SG2 0EE</strong>. It is registered by the Financial Services Authority (FSA) under the Payment Service Regulations 2009 for the provision of payment services. Registration number; <strong class="text-red">724684</strong>.</li>
                      
                      <li><span class="number-line">1.3</span>The terms "<strong>you</strong>" and "<strong>your</strong>" refer to users of the Service, whether in their capacity as Senders, Recipients, or visitors to this website.</li>	
                      
                      <li><span class="number-line">1.4</span>These Terms and Conditions are effective from <strong>01 March 2016</strong>. The Terms and Conditions may change from time to time, but changes will only be effective from the date they are made and will not change the terms on which you previously used the Service.</li>
                      
                      <li><span class="number-line">1.5</span>The Service was created to assist customers to send money to their family and friends, and to receive money from family and friends, around the world. For security reasons, we recommend that you only send money through the Service to people you know personally. You must not use the Service to send money to strangers for example sellers of goods and/or services, private or retail.</li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>DEFINITIONS</h6>
                    <ul class="point">
                     <li><span class="number-line">2.1</span>In this Terms and Conditions:
                     		<ul>
                        	<li><span class="number-line">a)</span> <strong>"Destination Country"</strong> means the country in which the Recipient receives money through the Service.</li>
                          <li><span class="number-line">b)</span> <strong>"Local Taxes"</strong> means any taxes or charges payable in the Destination Country.</li>
                          <li><span class="number-line">c)</span> <strong>"Payment Instrument"</strong> means a valid instrument of payment such as a bank account, debit card or credit card.</li>
                          <li><span class="number-line">d)</span> <strong>"Payout Amount"</strong> means the amount paid out to the Recipient, after any foreign exchange conversion and excluding Local Taxes.</li>
                          <li><span class="number-line">e)</span> <strong>"Recipient"</strong> means someone who receives money through the Service.</li>
                          <li><span class="number-line">f)</span> <strong>"Sender"</strong> means someone who uses the Service to send money. </li>
                          <li><span class="number-line">g)</span> <strong>"Service Fee"</strong> means the fee plus any additional charges applicable to each Transaction.</li>
                          <li><span class="number-line">h)</span> <strong>"Service Provider"</strong> means a local bank, money exchange house, or other third party service providers in the Destination Country with whom PayMack works in providing the Service.</li>
                          <li><span class="number-line">i)</span> <strong>"Transaction"</strong> means a specific instruction to send money through the Service.</li>
                          <li><span class="number-line">j)</span> <strong>"Transaction Amount"</strong> means the amount of money that the Sender wishes to send to the Recipient, excluding any applicable fees and prior to any foreign exchange conversion.</li>
                        </ul>
                     </li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>OUR OBLIGATIONS</h6>
                    <ul class="point">
                      <li><span class="number-line">3.1</span> Subject to these Terms and Conditions, we agree to provide the Service to you using reasonable care. The Service may not be available in whole or in part in certain regions, countries, or jurisdictions.</li>
                   	  <li><span class="number-line">3.2</span> We are not obliged to process any particular Transaction. When you submit a Transaction, you are requesting that we process the Transaction on your behalf. We may, in our sole discretion, choose whether or not to accept the offer to process that Transaction. However, if we decide not to process the Transaction, we will notify you promptly of that decision and repay the money paid to us.</li>
                      <li><span class="number-line">3.3</span> PayMack reserves the right to modify or discontinue the service or any part of the Service without notice, at any time and from time to time. We may, in our absolute discretion, refuse any Transaction or limit the amount to be transferred, either on a per transaction basis or on an aggregate basis, and either on individual accounts or on related accounts.</li>
                      <li><span class="number-line">3.4</span> We may, in our sole discretion, refuse Transactions from certain Senders or to certain Recipients, including but not limited to entities and individuals on restricted or prohibited lists issued from time to time by the UK Government. In addition, not all Payment Instruments are available to all customers at all times and we may, in our sole discretion, refuse Transactions funded from certain Payment Instruments.</li>
                      <li><span class="number-line">3.5</span> We will attempt to process Transactions promptly, but any Transaction may be delayed or cancelled for a number of reasons including but not limited to: our efforts to verify your identity; to validate your Transaction instructions; to contact you; or otherwise to comply with applicable law; or due to variations in business hours and currency availability.</li>
                      <li><span class="number-line">3.6</span> We will attempt to provide Senders and Recipients with up to date information regarding the location and opening hours of our Service Providers by means of information on our website. However, you agree that PayMack shall not be held responsible for any inaccuracies that may appear in that information or any consequential loss which may result from incorrect or incomplete information.</li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>YOUR OBLIGATIONS</h6>
                    <ul class="point">
                      <li><span class="number-line">4.1</span>  You agree that:
                      	<ul>
                        	<li><span class="number-line">a)</span> you will not access, use or attempt to use the Service as a Sender unless you are at least 18 years old, and that you have the legal capacity to form a binding legal contract in the relevant jurisdiction; </li>
                          <li><span class="number-line">b)</span> For each Transaction that you submit, you will pay us the Service Fee in addition to the Transaction Amount. Payment becomes due at the time that you submit your Transaction. If you submit a Transaction that results in PayMack becoming liable for charges including but not limited to chargeback or other fees, you agree to reimburse us for all such fees; </li>
                        </ul>
                      </li>
                      <li><span class="number-line">4.2</span> In connection with your registration and use of the Service, you will:
                      	<ul>
                        	<li><span class="number-line">a)</span> Provide us with true, accurate, current and complete evidence of your identity, and promptly update your personal information if and when it changes; </li>
                          <li><span class="number-line">b)</span> Provide our merchant with details of one or more Payment Instruments; and </li>
                          <li><span class="number-line">c)</span> Provide us with true, accurate, current and complete information for all Transactions. </li>
                        </ul>
                      </li>
                      <li><span class="number-line">4.3</span> We do not accept any liability for damages resulting from non-payment or delay in payment of a money transfer to a Recipient or failure to perform a transaction under the Service by reason of any of these matters.</li>
                      <li><span class="number-line">4.4</span> When you pay for a Transaction in one currency and the Recipient is paid in another currency, there will be a difference between the exchange rate at which we buy foreign currency and the exchange rate provided to you. PayMack and its Service Providers usually make a small profit in these circumstances. If such account is denominated in another currency the amount to be received by the Recipient will be reduced by the amount of extra charges incurred by reason of the incorrect information given by you and we will have no obligation to make good such reduction;</li>
                      <li><span class="number-line">4.5</span> When you are sending money under these Terms and Conditions, it is your responsibility to make sure all the Transaction details are accurate before submission. Once a Transaction has been submitted for processing it is not normally possible to change any of its details. You will be given the opportunity to confirm Transactions before submission and you must check the details carefully.</li>
                      <li><span class="number-line">4.6</span> PayMack will have no responsibility for any fees or charges you may incur by the use of a particular Payment Instrument to fund a Transaction. These may include but are not limited to unauthorised overdraft fees imposed by banks if there are insufficient funds in your bank account or "cash advance" fees and additional interest which may be imposed by credit card providers if they treat use of the Service as a cash transaction rather than a purchase transaction;</li>
                      <li><span class="number-line">4.7</span> You will only use the Service to send money to people that you know personally and not to pay for goods or services. If, in breach of this clause, you choose to pay third parties for goods and services using the Service, you acknowledge that PayMack has no control over, and is not responsible for, the quality, safety, legality, or delivery of such goods or services and that any such use of the Service is entirely at your own risk. If PayMack reasonably believes you are using the Service to purchase goods or services, we reserve the right to cancel your Transaction(s);</li>
                      <li><span class="number-line">4.8</span> Both you and the Recipients will only act on your own behalf. You may not submit or receive a Transaction on behalf of a third person. If you intend to submit or receive a Transaction on behalf of a company, business or any entity other than a human individual, you must first inform PayMack of your desire to do so and provide us with any additional information about the entity we may request in order that we may decide whether to permit the Transaction;</li>
                      <li><span class="number-line">4.9</span> In using the Service you will comply with these Terms and Conditions as well as any applicable laws, rules or regulations. It is a breach of these Terms and Conditions to use the Service to send money (i) to a Recipient who has violated the Terms and Conditions, or (ii) in connection with illegal activity including without limitation money-laundering, fraud and the funding of terrorist organisations. If you use the Service in connection with illegal activity, PayMack may report you to the appropriate legal authorities;</li>
                      <li><span class="number-line">4.10</span> When using our website or the Service or when interacting with PayMack, with another user or with a third party, you will not:
                      	<ul>
                        	<li><span class="number-line">a)</span> Breachthese Terms and Conditions, or any other agreement between you and PayMack;</li>
                          <li><span class="number-line">b)</span> Open more than one account, without our prior written permission;</li>
                          <li><span class="number-line">c)</span> Provide false, inaccurate, or misleading information;</li>
                          <li><span class="number-line">d)</span> Allow anyone else access to your registration details, and will keep those details secure;</li>
                          <li><span class="number-line">e)</span> Refuse to provide confirmation of any information you provide to us, including proof of identity, or refuse to co-operate in any investigation;</li>
                          <li><span class="number-line">f)</span> Use an anonymising proxy (a tool that attempts to make activity untraceable); or</li>
                          <li><span class="number-line">g)</span> Copy or monitor our website using any robot, spider, or other automatic device or manual process, without our prior written permission.</li>
                        </ul>
                      </li>
                      <li><span class="number-line">4.11</span> PayMack may, as necessary in providing the Service, store all information required of a Recipient to prove his or her identity or associated with their specific Transaction. Such proofs may include a suitable form of valid, unexpired identification from a list of acceptable papers provided by the Service Provider, and/or a Transaction tracking number, a personal identification number (PIN), a "password", a "secret word", or other similar identifiers.</li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>CANCELLATION AND REFUNDS</h6>
                    <ul class="point">
                      <li><span class="number-line">5.1</span> If you have any problems using the Service you should contact us through the channels listed at the end of this Terms and Conditions.</li>
                   	  <li><span class="number-line">5.2</span> You have the statutory right to cancel your agreement with us after you have submitted a Transaction. This right of cancellation continues until fourteen days after you have submitted the transaction, or until we have completed the contract by paying the Payout Amount to the Recipient, whichever is the earlier. If you exercise your right to cancel under this clause, we may make a cancellation charge.</li>
                      <li><span class="number-line">5.3</span> If you wish to exercise your right to cancel under this clause, you must submit a written request to one of the contact points listed at the bottom of this Terms and Conditions, giving the Sender's full name, address, and phone number, together with the Transaction tracking number, Transaction Amount, and the reason for your refund request.</li>	
                      <li><span class="number-line">5.4</span> Any refunds will be credited back to the same Payment Instrument used to fund the Transaction and in the same currency. No adjustment will be made for any currency fluctuations which may have occurred in the meanwhile.</li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>COLLECTION OF INFORMATION</h6>
                    <ul class="point">
                      <li><span class="number-line">6.1</span> <strong>Customer Identification Program. </strong>UK law requires all financial institutions to assist in the fight against money laundering activities and the funding of terrorism by obtaining, verifying, and recording identifying information about all customers. We may therefore require you to supply us with personal identifying information and we may also legally consult other sources to obtain information about you.</li>
                      <li><span class="number-line">6.2</span> <strong>Verification and Checks.</strong> We will verify your residential address and personal details in order to confirm your identity. We may also pass your personal information to a credit reference agency, which may keep a record of that information. You can be rest assured that this is done only to confirm your identity, that a credit check is not performed and that your credit rating will be unaffected. All information provided by you will be treated securely and strictly in accordance with the Data Protection Act 1998.</li>
                      <li><span class="number-line">6.3</span> By accepting these Terms and Conditions you authorise us to make any inquiries we consider necessary to validate the information that you provide to us. We may do this directly, for example by asking you for additional information, requiring you to take steps to confirm ownership of your Payment Instruments or email address; or by verifying your information against third party databases; or through other sources.</li>
                      <li><span class="number-line">6.4</span> <strong>Privacy Policy.</strong> You consent to our processing your personal information for the purposes of providing the Service, including for verification purposes as set out in this clause. You also consent to the use of such data for communicating with you, and for statutory, accounting and archival purposes. You acknowledge that you have read and consented to PayMack's Data Privacy Policy. The Data Privacy Policy can be found by clicking here: <a href="privacy-policy.php">Privacy Policy.</a></li>
                      <li><span class="number-line">6.5</span> <strong>Government Disclosures.</strong> We may be required by law to provide information about you and your Transactions to government or other competent authorities as described in our Data Privacy Policy. You acknowledge and consent to our doing this.</li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>INTELLECTUAL PROPERTY</h6>
                    <ul class="point">
                      <li><span class="number-line">7.1</span> The PayMack website and the PayMack Service, the content, and all intellectual property relating to them and contained in them (including but not limited to copyrights, patents, database rights, trademarks and service marks) are owned by us, our affiliates, or third parties. All right, title and interest in and to the PayMack Online Site and the PayMack Online Service shall remain our property and/or the property of such other third parties.</li>
                      <li><span class="number-line">7.2</span> The PayMack website and the PayMack Service may be used only for the purposes permitted by these Terms and Conditions or described on this website. You are authorized solely to view and to retain a copy of the pages of the PayMack website for your own personal use. You may not duplicate, publish, modify, create derivative works from, participate in the transfer or sale of, post on the internet, or in any way distribute or exploit the PayMack website, the PayMack Service or any portion thereof for any public or commercial use without our express written permission. You may not: (a) use any robot, spider, scraper or other automated device to access the PayMack website or the PayMack Service; and/or (b) remove or alter any copyright, trademark or other proprietary notice or legend displayed on the PayMack website (or printed pages of the website). The name PayMack and other names and indicia of ownership of PayMack's products and/or services referred to on the PayMack website are our exclusive marks or the exclusive marks of other third parties. Other product, service and company names appearing on the website may be trademarks of their respective owners.</li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>WARRANTIES AND LIABILITY</h6>
                    <ul class="point">
                      <li><span class="number-line">8.1</span> We will refund to you any benefit which we receive as a result of any breach of our agreement with you (this means that, for example, where a money transfer has failed in such circumstances we will refund to you the Transaction Amount and the Service Fee).</li>
                      <li><span class="number-line">8.2</span> If a money transfer is delayed or fails, you may have a right to receive a refund or compensation under laws relating to the provision of international money transfer services. We will provide you with the details of your rights to a refund or compensation if you contact us using the contact details at the end of this agreement.</li>
                      <li><span class="number-line">8.3</span> Any claim for compensation made by you and/or a Recipient (who is not registered with us) must be supported by any available relevant documentation.</li>
                      <li><span class="number-line">8.4</span> If any loss which you or a Recipient (who is not registered with us) suffers is not covered by a right to payment under the laws referred to in clause 8.2, we will only accept liability for that loss up to a limit which is the greater of: (a) the amount of any service charge; and (b) €250, unless otherwise agreed by us in writing. Our cap on our liability only limits a claim for loss arising out of any single transaction or related transactions, or (if a loss does not arise out of a transaction or transactions) any single act, omission or event or related acts, omissions or events. This means that if, for example, you suffer loss by reason of our failure to perform our agreement with you under two unrelated transactions, you might be able to claim up to €500.</li>
                      <li><span class="number-line">8.5</span> We do not, in any event, accept responsibility for:
                      	<ul>
                        	<li><span class="number-line">a)</span> Any failure to perform your instructions as a result of circumstances which could reasonably be considered to be outside our control;</li>
                          <li><span class="number-line">b)</span> Malfunctions in communications facilities which cannot reasonably be considered to be under our control and that may affect the accuracy or timeliness of messages you send to us;</li>
                          <li><span class="number-line">c)</span> Any losses or delays in transmission of messages arising out of the use of any internet service provider or caused by any browser or other software which is not under our control;</li>
                          <li><span class="number-line">d)</span> Errors on the website or with the Service caused by incomplete or incorrect information provided to us by you or a third party.</li>
                        </ul>
                      </li>
                      <li><span class="number-line">8.6</span> Nothing in this clause 8 shall (a) exclude or limit liability on our part for death or personal injury resulting from our negligence; or (b) exclude liability for our fraud.</li>
                      <li><span class="number-line">8.7</span> Where you are sending a money transfer to a Recipient who is not registered with us, you agree to accept the provisions of this clause 11 not only for yourself, but also on behalf of the Recipient.</li>
                      <li><span class="number-line">8.8</span> Your relationship is with PayMack only. You agree that no affiliate or agent of PayMack owes you any duty of care when performing a task which would otherwise have to be performed by PayMack under its agreement with you. </li>
                      <li><span class="number-line">8.9</span> You agree to indemnify and hold harmless PayMack, our subsidiaries, affiliates, officers, directors, employees, agents, independent contractors, advertisers, partners, and co-branders from all loss, damage, claims, actions or demands, including reasonable legal fees, arising out of your use or misuse of this website or Service, all activities that occur under your password or account e- mail login, your violation of this Terms and Conditions or any other violation of the rights of another person or party.</li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>ELECTRONIC COMMUNICATIONS</h6>
                    <ul class="point">
                      <li><span class="number-line">9.1</span> You acknowledge that this Terms and Conditions shall be entered into electronically, and that the following categories of information <strong>("Communications")</strong> may be provided by electronic means:
                      	<ul>
                        	<li><span class="number-line">a)</span> These Terms and Conditions and any amendments, modifications or supplements to it.</li>
                          <li><span class="number-line">b)</span> Your records of transactions through the Service.</li>
                          <li><span class="number-line">c)</span> Any initial, periodic or other disclosures or notices provided in connection with the Service, including without limitation those required by law.</li>
                          <li><span class="number-line">d)</span> Any customer service communications, including without limitation communications with respect to claims of error or unauthorised use of the Service.</li>
                          <li><span class="number-line">e)</span> Any other communication related to the Service or PayMack.</li>
                        </ul>
                      </li>
                      <li><span class="number-line">9.2</span> The Service does not allow for Communications to be provided in paper format or through other non-electronic means. You may withdraw your consent to receive Communications electronically, but if you do, your use of the Service shall be terminated. In order to withdraw your consent, you must contact us using our contact information at the end of this Terms and Conditions.</li>
                      <li><span class="number-line">9.3</span> In order to access and retain Communications, you must have or have access to the following:
                      	<ul>
                        	<li><span class="number-line">a)</span> An Internet browser that supports 128-bit encryption, such as Internet Explorer version 4.0 or above;</li>
                          <li><span class="number-line">b)</span> An e-mail account and e-mail software capable of interfacing with PayMack's e-mail servers;</li>
                          <li><span class="number-line">c)</span> A personal computer, operating system and telecommunications connections to the Internet capable of supporting the foregoing;</li>
                          <li><span class="number-line">d)</span> Sufficient electronic storage capacity on your computer's hard drive or other data storage unit; and</li>
                          <li><span class="number-line">e)</span> A printer that is capable of printing from your browser and e-mail software. In addition, you must promptly update us with any change in your email address by updating your profile at http://www.PayMack.com.</li>
                        </ul>
                      </li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>TERMINATION</h6>
                    <ul class="point">
                    	<li><span class="number-line">10.1</span> Either party may terminate this Terms and Conditions on one day's written notice.</li>
                      <li><span class="number-line">10.2</span> We may terminate this Terms and Conditions with immediate effect if:
                      	<ul>
                        	<li><span class="number-line">a)</span> You become, or are likely to become, insolvent or are declared bankrupt;</li>
                          <li><span class="number-line">b)</span> You are in breach of any provision of this Terms and Conditions;</li>
                          <li><span class="number-line">c)</span> Your use of the Service or the website is disruptive to our other customers, or you do anything which in our opinion is likely to bring us into disrepute;</li>
                          <li><span class="number-line">d)</span> You breach or attempt to breach the security of the website (including but not limited to: modifying or attempting to modify any information; unauthorised log-ins, unauthorised data access or deletion; interfering with the service, system, host or network; reverse engineering of any kind; spamming; hacking; falsifying data; introducing viruses, Trojan horses, worms or other destructive or damaging programs or engines; or testing security in any way);</li>
                        </ul>
                      </li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>COMPLAINTS</h6>
                    <ul class="point">
                    	<li><span class="number-line">11.1</span> If you wish to make a complaint about any aspect of the PayMack service, please send your complaint in writing to the address shown on the Contact Us page or by email to support@PayMack.com. </li>
                      <li><span class="number-line">11.2</span> We will acknowledge receipt of your complaint within 2 business days. We will investigate your complaint and come back to you with the results of our investigation no later than 7 business days of receipt of your complaint. If you are not satisfied with the manner in which we have dealt with your complaint, or the outcome, then you may refer the matter to the;</li>
                    </ul>
                    <p class="address">
                    Financial Ombudsman Service<br>
                    South Quay Plaza, 183 Marsh Wall<br>
                    London E14 9SR<br>
                    Tel No: 0800 0234 567<br>
                    Email: <a href="mailto:complaint.info@financial-ombudsman.org.uk">complaint.info@financial-ombudsman.org.uk</a>
										</p>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>GENERAL</h6>
                    <ul class="point">
                    	<li><span class="number-line">12.1</span> <strong>Governing law:</strong> This Agreement will be governed by English law and the parties submit to the exclusive jurisdiction of the English Courts.</li>
                      <li><span class="number-line">12.2</span> <strong>No Waiver:</strong> The failure of PayMack to exercise or enforce any right or provision of the Terms and Conditions shall not constitute a waiver of such right or provision. </li>
                      <li><span class="number-line">12.3</span> <strong>Modification:</strong> We may modify this Terms and Conditions from time to time without notice to you, except as may be required by law. You can review the most current version of the Terms and Conditions at any time by reviewing this website. You may terminate your use of the Service if you do not agree with any modification or amendment. If you use the Service after the effective date of an amendment or modification, you shall be deemed to have accepted that amendment or modification. You agree that you shall not modify this Terms and Conditions and acknowledge that any attempts by you to modify this Terms and Conditions shall be void.</li>
                      <li><span class="number-line">12.4</span> <strong>Entire Agreement:</strong> This agreement constitutes the entire agreement between the parties and supersedes all prior understandings or agreements relating to the subject matter of this agreement.</li>
                      <li><span class="number-line">12.5</span> <strong>Severability:</strong> If any provision of the Terms and Conditions is found by an arbitrator or court of competent jurisdiction to be invalid, the parties nevertheless agree that the arbitrator or court should endeavour to give appropriately valid effect to the intention of the Terms and Conditions as reflected in the provision, and the other provisions of the Terms and Conditions shall remain in full force and effect.</li>
                      <li><span class="number-line">12.6</span> Any external links to third-party websites on the website are provided as a convenience to you. These sites are not controlled by us in any way and we are not responsible for the accuracy, completeness, legality or any other aspect of these other sites including any content provided on them. You access such websites at your own risk.</li>
                    </ul>
                 </li>
                 
                 <li class="margin-top30">
                 		<h6>SECURITY</h6>
                    <ul class="point">
                    	<li>We take security very seriously at PayMack, and we work hard, using state-of-the-art security measures, to make sure that your information remains secure. The PayMack Service is a safe and convenient way to send money to friends and family and to other people that you trust. However, we do advise you to consider very carefully before sending money to anyone that you do not know well. In particular, you should be very cautious of deals or offers that seem too good to be true - they may be scams. If you are aware of anyone or any entity that is using the Service inappropriately, please email us using our <a href="contact-us.php">contact form</a>. Similarly, if you receive any emails, purporting to be from PayMack, which you suspect may be "phishing" (fake) emails, please forward them to us using our <a href="contact-us.php">contact form.</a></li>
                    </ul>
                 </li>
                 
                </ul>
     	
      </div>
      <!--/ABOUT US--> 
    </div>
   </div>
 </div>
<!--/Body Part--> 
    
  <?php $pages->homeFooter(); ?>
<script language="javascript" src="js/home.js"></script>
</body>
</html>