<?php
	$redirect = "sendMoney";
	include_once("includes/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Privacy Policy</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body>

<!--Model login-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Log in to your PayMack Account</span></div>
      </div>
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15">
        	<input name="redirect" id="redirect" type="hidden" value="<?php echo $redirect; ?>">
          <input type="email" name="email" id="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="password" id="password" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
         <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-green1" href="Javascript:void(0)" onClick="login()" id="login_button">LOG IN</a>
           </p>
         </div>
        <div class="forgotten-password"><a href="#" data-dismiss="modal" data-target="#myModal5" data-toggle="modal">Forgotten your password?</a> </div>
        <p class="text-center font-size14 margin-top20">Don’t have an Account? <a href="#" class="text-red" data-dismiss="modal" data-target="#myModal2" data-toggle="modal"><strong>Sign up</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model login-->

<!--Model singup-->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content  model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Create an Account with PayMack</span></div>
      </div>
		<input name="redirect" id="redirect2" type="hidden" value="<?php echo $redirect; ?>">
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue2" style="color:#F00; display:none" align="center"></div>
        <!-- <div class="padding-left-right15">
          <input type="text" name="fullNames" id="fullNames" placeholder="Full Names" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Full Names'" class="form-control">
        </div> -->
        <div class="padding-left-right15 margin-top15">
          <input type="text" name="createEmail" id="createEmail" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control" onChange="checkEmail(this.value)">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="newPassword" id="newPassword" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Confirm Password'"  class="form-control">
        </div>
        <p class="text-center font-size11 margin-top15">By signing up, you are agreeing to PayMack’s <br>
          <a class="margin-right5" href="terms-conditions.php" target="_blank"><u>Terms and Conditions</u></a> and <a class="margin-left5" href="privacy-policy.php" target="_blank"><u>Privacy Policy</u></a></p>
        <!--<div class="text-center"> <a href="registration.html" class="btn btn-red btn-signup" type="button">SIGN UP</a> </div>-->
        <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-red1" href="Javascript:void(0)" onClick="register()" id="register_button">SIGN UP</a>
           </p>
         </div>
        
        <p class="text-center font-size14 margin-top4">Already have an account? <a href="#" class="text-green" data-toggle="modal" data-target="#myModal" data-dismiss="modal"><strong>Log in</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model singup--> 

<!--Model Forgotten your password-->
<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Reset Your PayMack Password</span></div>
         <p class="forgotten-text">Enter the email address you registered with and we will send <br>you an email with a link to reset your password </p>
      </div>
		<input name="redirect" id="redirect3" type="hidden" value="<?php echo $redirect; ?>">
        
        <div class="padding-left-right15" id="notificationDialogue3" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15" id="notificationDialogue4" style="color:#060; display:none" align="center"></div>
      <div class="modal-body form-horizontal modal-box">
        <div class="padding-left-right15">
          <input name="forgotPassword" id="forgotPassword" type="text" placeholder="Enter your email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your email address'" class="form-control">
        </div>
        <div class="send-email"> <a href="Javascript:void(0)" onClick="remeberPassword()" class="btn btn-green btn-login2" type="button">SEND EMAIL</a> </div>
      </div>
    </div>
  </div>
</div>
<!--Model Forgotten your password--> 


<?php $pages->topMenu(); ?>

<!--Body Part-->
 <div class="main-container">
  <div class="container margin-bottom50">
    <div class="row margin-top10 margin-bottom20"> 
      <!--From-left-panel-->
      <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
        <div id="box-con" class="all-box-panel hidden-xs hidden-sm">
        <div class="gray-box-con"><a href="terms-conditions.php">Terms & Conditions</a></div>
        <div class="sky-box-con"><a href="privacy-policy.php">Privacy Policy</a></div>
        <div class="gray-box-con"><a href="cookie-policy.php">Cookie Policy</a></div>
        </div>
      </div>
      <!--/From-left-panel--> 
      
      <!--ABOUT US-->
      <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
        <h2 class="border-panel"><strong>PRIVACY POLICY</strong></h2>
        <p>This Privacy Policy explains how PayMack uses your Personal Data collected or processed from you in providing an online facility for transferring money to others ("<strong>Service</strong>").</p>
        
        <h5 class="margin-top30">Who processes your Personal Data?</h5>
        <p>PayMack processes and stores Personal Data collected from you via your use of the Service or where you have given your consent.</p>
        
        <h5 class="margin-top30">We might ask you to provide us with Personal Data</h5>
        <p>PayMack may request that you provide Personal Data when offering the Service to you. This Personal Data may include contact details, copies of identification documentation derived from publically accessible databases, your social security number as well as information relating to your device or internet service (such as an IP address and a MAC number).</p>
        
        <h5 class="margin-top30">How we use your Personal Data</h5>
        <p>PayMack uses Personal Data to communicate with you and to administer, deliver, improve and personalise the Service. PayMack might also generate generic data out of any Personal Data we collect and use it for our own purposes.</p>
        <p>We may also use such data to communicate with you in relation to other products or services offered by PayMack or its partners. PayMack may request that you confirm your consent to receive such communications (‘opt-in’) or to indicate that you would not like to receive such communications or that they should be discontinued (‘opt-out’). Where you opt-out, PayMack will not use your Personal Data for direct marketing.</p>
        <p>We do not share your Personal Data with third parties (other than partners in connection with their services to PayMack) except where you have given your consent.</p>
        
        <h5 class="margin-top30">Sharing your Personal Data</h5>
        <p>We may share your Personal Data with third parties:</p>
        <ul class="point">
          <li><ul>
          	<li><span class="number-line">a)</span> If we think that sharing is necessary to enforce the terms of a contract with you or to protect the rights, property or safety of PayMack or the services provided by PayMack.</li>
            <li><span class="number-line">b)</span> To enable us to comply with the law or to satisfy a legitimate government request or an order of any court of competent jurisdiction or any regulatory authority or, if necessary, to defend PayMack or its Subscribers (for example, in a lawsuit).</li>
            <li><span class="number-line">c)</span> In connection with the sale or transfer of our business or any part thereof.</li>
            <li><span class="number-line">d)</span> If you request a service or product that is administered by a third party, in order to allow us to respond to the request. If such third party is working for PayMack it may also send back to PayMack any new information obtained from you.</li>
            <li><span class="number-line">e)</span> To allow us to co-operate with law enforcement agencies to identify anyone who uses our Service for illegal activities. We reserve the right to report to law enforcement agencies any activities that we believe are unlawful including exchanging information with other companies, organisations and agencies for the purposes of fraud protection.</li>
            <li><span class="number-line">f)</span> To third parties who provide services to PayMack (such as such as administration or technical services). However we ensure that such partners do not use Personal Data for any other purposes, do not disclose it to anyone else and that they do not retain copies except as necessary to provide services to us or as required by law.</li>
          </ul></li>
        </ul>
        
        <h5 class="margin-top30">Storage, security and retention of your Personal Data</h5>
        <p>Personal Data that we collect is stored on our servers which may be located outside the EEA and may also be processed by staff operating outside the EEA. We implement and maintain the highest levels of security to protect any information stored on our servers and to comply with all local rules.</p>
        <p>It is your responsibility to keep your password secure. You should also be aware that the transmission of information via the Internet is not completely secure. Although we will do our best to protect your Personal Data, we cannot guarantee the security of Personal Data transmitted to our site outside our control.</p>
        <p>We strive to collect no more Personal Data than is required. This helps reduce the total risk of harm should data loss or a breach in security occur.</p>
        <p>Your passwords are stored on PayMack’s servers in encrypted form. We may disclose your first name and the first letter of your last name to other Subscribers, who are transacting with you via the Service.</p>
        
        <h5 class="margin-top30">Notification in the event of breach</h5>
        <p>It would be very unlikely, but if a breach in the security of Personal Data were to occur, we will notify you if you are actually or potentially affected. In this event we will contact you via email, in-Service messaging or publication on PayMack’s website. We reserve the right to delay notification if it is asked to do so by law enforcement or other authorities, or if giving notice immediately will increase the risk of harm to end-users overall.</p>
        
        <h5 class="margin-top30">Contacting PayMack about privacy questions or concerns</h5>
        <p>If you have any questions about this Privacy Policy or the use of your Personal Data, please contact us by sending an email to the following address (indicating "PRIVACY REQUEST" in the message line: <a href="mailto:support@PayMack.com">support@PayMack.com</a></p>
        <p>If you contact us by e-mail, we may keep a record of your correspondence and ask for your name and contact information in order to send you a reply.</p>
        <p>You may access the information that PayMack holds about you by submitting a request to PayMack to the email address set out above. Please note that we may charge you an administrative fee to deal with any such requests.</p>
        
        <h5 class="margin-top30">Privacy Policy changes</h5>
        <p>PayMack may change this Privacy Policy at any time by posting the revised policy on its website. Any changes will become effective immediately upon being posted unless stated otherwise.</p>
        
      </div>
      <!--/ABOUT US--> 
    </div>
   </div>
 </div>
<!--/Body Part--> 
    
  <?php $pages->homeFooter(); ?>
<script language="javascript" src="js/home.js"></script>
</body>
</html>