<?php
//session_start();
//print_r($_SESSION['tempPayment']);
include_once("includes/functions.php");
$merchantId = 264;
$currency = "NGN";
$orderID = time();
$bankAccountNumber = 1003766227;
$bankSortCode =
$bankCode = "999011";
$amount = 5000;
$key = "10B74BB71A54B041023F3D31C3DD56AE";
$raw = $merchantId.$orderID.$amount.$currency.$bankAccountNumber.$bankSortCode.$key;
$encKey = hash("sha256", $raw);

$link = "currency=".$currency."&merchantID=".$merchantId."&orderID=".$orderID."&bankAccountNumber=".$bankAccountNumber."&bankSortCode=".$bankSortCode."&amount=".$amount."&encKey=".$encKey;

//echo $url = "https://kegow.getitcard.net/getit/api/merchant/bankmerchantwithdraw.do?".($link);


$raw = $bankCode.$merchantId.$bankAccountNumber.$key;
$encKey = hash("sha256", $raw);

$valuesforurl = array(
"merchantID"=>$merchantId,
"bankCode"=>$bankCode,
"bankAccountNumber"=>$bankAccountNumber,
"encKey"=>$encKey
);

$outvalue = http_build_query($valuesforurl) . "\n";

echo $url = "https://kegow.getitcard.net/getit/api/merchant/verifybank.do?".$outvalue;

?>