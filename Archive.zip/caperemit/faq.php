<?php
	$redirect = "sendMoney";
	include_once("includes/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>FAQ</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body>
<!--Model login-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Log in to your PayMack Account</span></div>
      </div>
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15">
        	<input name="redirect" id="redirect" type="hidden" value="<?php echo $redirect; ?>">
          <input type="email" name="email" id="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="password" id="password" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
         <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-green1" href="Javascript:void(0)" onClick="login()" id="login_button">LOG IN</a>
           </p>
         </div>
        <div class="forgotten-password"><a href="#" data-dismiss="modal" data-target="#myModal5" data-toggle="modal">Forgotten your password?</a> </div>
        <p class="text-center font-size14 margin-top20">Don’t have an Account? <a href="#" class="text-red" data-dismiss="modal" data-target="#myModal2" data-toggle="modal"><strong>Sign up</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model login-->

<!--Model singup-->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content  model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Create an Account with PayMack</span></div>
      </div>
		<input name="redirect" id="redirect2" type="hidden" value="<?php echo $redirect; ?>">
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue2" style="color:#F00; display:none" align="center"></div>
        <!-- <div class="padding-left-right15">
          <input type="text" name="fullNames" id="fullNames" placeholder="Full Names" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Full Names'" class="form-control">
        </div> -->
        <div class="padding-left-right15 margin-top15">
          <input type="text" name="createEmail" id="createEmail" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control" onChange="checkEmail(this.value)">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="newPassword" id="newPassword" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Confirm Password'"  class="form-control">
        </div>
        <p class="text-center font-size11 margin-top15">By signing up, you are agreeing to PayMack’s <br>
          <a class="margin-right5" href="terms-conditions.php" target="_blank"><u>Terms and Conditions</u></a> and <a class="margin-left5" href="privacy-policy.php" target="_blank"><u>Privacy Policy</u></a></p>
        <!--<div class="text-center"> <a href="registration.html" class="btn btn-red btn-signup" type="button">SIGN UP</a> </div>-->
        <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-red1" href="Javascript:void(0)" onClick="register()" id="register_button">SIGN UP</a>
           </p>
         </div>
        
        <p class="text-center font-size14 margin-top4">Already have an account? <a href="#" class="text-green" data-toggle="modal" data-target="#myModal" data-dismiss="modal"><strong>Log in</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model singup--> 

<!--Model Forgotten your password-->
<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Reset Your PayMack Password</span></div>
         <p class="forgotten-text">Enter the email address you registered with and we will send <br>you an email with a link to reset your password </p>
      </div>
		<input name="redirect" id="redirect3" type="hidden" value="<?php echo $redirect; ?>">
        
        <div class="padding-left-right15" id="notificationDialogue3" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15" id="notificationDialogue4" style="color:#060; display:none" align="center"></div>
      <div class="modal-body form-horizontal modal-box">
        <div class="padding-left-right15">
          <input name="forgotPassword" id="forgotPassword" type="text" placeholder="Enter your email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your email address'" class="form-control">
        </div>
        <div class="send-email"> <a href="Javascript:void(0)" onClick="remeberPassword()" class="btn btn-green btn-login2" type="button">SEND EMAIL</a> </div>
      </div>
    </div>
  </div>
</div>

<?php $pages->topMenu(); ?>

    <!--Body Part-->
    <div class="main-container">
      <div class="container margin-bottom50">
        <div class="row margin-top10 margin-bottom20"> 
          <!--From-left-panel-->
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
            <div id="box-con" class="all-box-panel hidden-xs hidden-sm">
            <div class="gray-box-con red-box"><a href="contact-us.php">Contact Us</a></div>
            <div class="gray-box-con sky-box-con"><a href="how-it-works.php">How it Works</a></div>
            <div class="green-box-con"><a href="faq.php">FAQ</a></div>
            <div class="gray-box-con yellow-box-con"><a href="security.php">Security</a></div>
            </div>
          </div>
          <!--/From-left-panel--> 
          
          <!--CONTACT US-->
          <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
             <h2 class="border-panel"><strong>FREQUENTLY ASKED QUESTIONS</strong></h2>
             
          </div>
          <!--/CONTACT US--> 
        </div>
      </div>
     </div>
    <!--/Body Part--> 
    
  <?php $pages->homeFooter(); ?>
<script language="javascript" src="js/home.js"></script>
</body>
</html>