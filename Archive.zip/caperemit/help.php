<?php
	$redirect = "sendMoney";
	include_once("includes/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Help</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body class="my-account"> 

    <div id="main">
  <!--header-->
    <div class="main-header navbar-fixed-top">
      <div class="container text-black">
        <div class="row">
          <!--lago-->
          <div class="pull-left">
            <h1><strong>Cape Remit</strong></h1>
          </div>
          <!--/lago--> 
          
          <!--navber-->
          <nav class="main-nav pull-right">
            <ul class="">
              <li><a href="index.php">HOME</a></li>
              <li><a href="about-us.php">ABOUT US</a></li>
              <li class="active"><a href="profile">MY ACCOUNT</a></li>
              <li><a href="index.php" class="btn-login" rel="popover" data-placement="top"  data-trigger="hover" id="login_pop_link">LOG OUT</a></li>
            </ul>
          </nav>
          <!--/navber--> 
        </div>
      </div>
    </div>
    <!--/header--> 
    
    <!--Body Part-->
    
       <div class="container">
         <div class="row margin-top10">
         <!--MY PROFILE-->
           <div class="col-xs-8" id="main-body">
             <div class="white-bg">
                <h2 class="header help-con"><i class="glyphicons glyphicons-life-preserver"></i> HELP</h2>
               
             </div>
           </div>
         <!--/MY PROFILE-->
         
         <!--Icon-Panel-->  
           <div class="col-xs-4" id="sidebar">
            <div class="white-bg padding-top15">
              <div class="padding-left-right15 clearfix">
                  <div class="sky-box">
                    <div class="margin-top10 text-center font-size20"><strong>Hello</strong></div>
                      <span class="glyphicons glyphicons-user font-size70"></span>
                    <div class="margin-top10 text-center font-size20"><strong><?php echo $last_name." ".$other_names; ?></strong></div>
                </div>
                   <div id="box-panel"> 
              	<a href="sendMoney" class="money-box"> <span class="glyphicons glyphicons-credit-card font-size45"></span><span class="margin-top15 all-icon-box">Send Money</span> </a> 
                <a href="send-mobile-airtime.php" class="send-mobile-box"> <span><img src="images/mobile-phone-icon.png" height="44"></span><span class="margin-top15 all-icon-box">Send  Mobile Airtime</span> </a> 
                <a href="pay-bills.php"class="pay-bills-box"> <span><img src="images/bill.png" width="37" height="auto"></span><span class="margin-top15 all-icon-box">Pay Bills</span> </a> 
                <a href="myPayments" class="payments-box"> <span class="glyphicons glyphicons-circle-arrow-right font-size45"></span><span class="margin-top15 all-icon-box">My Payments</span> </a> 
                <a href="profile" class="profile-box"> <span class="glyphicons glyphicons-user font-size45"></span><span class="margin-top15 all-icon-box">My Profile</span> </a> 
                <a href="myRecipientList"class="recipients-box"> <span class="glyphicons glyphicons-group font-size45"></span><span class="margin-top15 all-icon-box">My Recipients</span> </a> 
                <a href="invite-friends.php" class="invite-box"> <span class="glyphicons glyphicons-user-add font-size45"></span><span class="margin-top15 all-icon-box">Invite Friends</span> </a> 
                <a href="changePassword" class="password-box"> <span class="glyphicons glyphicons-lock"></span><span class="margin-top15 all-icon-box">Change Password</span> </a> 
             </div>
              </div>
            </div>
          </div>   
         <!--/Icon-Panel-->
         </div>
       </div>
    
   
    <!--/Body Part-->
  
  
  <?php $pages->homeFooter(); ?>
</body>
</html>