$(document).ready(function(){
	// Initiating daterangePicker
	
	
	if($('input.daterange').length > 0){
		$('input.daterange').daterangepicker({
				
				singleDatePicker: true,
				showDropdowns: true,
				//autoApply:true,
				//autoUpdateInput:false,
				drops:'down',
				locale: {
						initialText : 'Select period...',
						format: 'MMMM D, YYYY'
				}
		}); 
	}
	
	var sidebarHeight = $('#sidebar .white-bg').outerHeight();
	var mainBodyHeight = $('#main-body .white-bg').outerHeight();
	if(sidebarHeight>=mainBodyHeight){
		$('#main-body .white-bg').css({'min-height':sidebarHeight});
		$('#sidebar .white-bg').css({'min-height':sidebarHeight});
	}else{
		$('#sidebar .white-bg').css({'min-height':mainBodyHeight});
		$('#main-body .white-bg').css({'min-height':mainBodyHeight});
	}
	$('.checkbox.black input').iCheck({
		checkboxClass: 'icheckbox_minimal',
		increaseArea: '20%'
	});
	$('.checkbox.grey input,.checkbox input').iCheck({
		checkboxClass: 'icheckbox_minimal-grey',
		increaseArea: '20%'
	});
	$('.checkbox.white input').iCheck({
		checkboxClass: 'icheckbox_minimal-white',
		increaseArea: '20%'
	});
	
	function formatState (state) {
		if (!state.id) { return state.text; }
		var $state = $(
			'<span><img src="images/flags/' + state.element.value.toLowerCase() + '.gif" class="img-flag" /> ' + state.text + '</span>'
		);
		return $state;
	};
	if($('.country-select').length > 0){ 
		$(".country-select").select2({
			templateResult: formatState,
			templateSelection: formatState
		});
	}
	function formatMobile (mobile) {
		if (!mobile.id) { return mobile.text; }
		var $mobile = $(
			'<span><img src="images/mobile/' + mobile.element.value.toLowerCase() + '.png" class="img-flag" /> ' + mobile.text + '</span>'
		);
		return $mobile;
	};
	if($('.mobile-select').length > 0){ 
		$(".mobile-select").select2({
			templateResult: formatMobile,
			templateSelection: formatMobile
		});
	}
	$('#btn-list,#btn-list2,#btn-list3').popover({ html: true, container: 'body'});
	
	$(".single-select").select2();
	
	$('.carousel').carousel({interval: false});
	
	if($('.dataTable').length > 0){
		$('#my-payments-tables,.view-recipients').DataTable({
			 responsive: true	
		});	
	}
	
	$('.toggle-menu').jPushMenu({
		pushBodyClass      : 'push-body',
		showLeftClass      : 'menu-left',
		showRightClass     : 'menu-right',
		showTopClass       : 'menu-top',
		showBottomClass    : 'menu-bottom',
		activeClass        : 'menu-active',
		menuOpenClass      : 'menu-sidebar-open',
		closeOnClickOutside: true,
		closeOnClickLink   : true	
	});
	
	if($('.menu-sidebar-open').length > 0){
		alert(0)
	}
	
	
});


