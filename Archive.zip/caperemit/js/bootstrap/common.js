$(document).ready(function(){
// hide #back-top first
	$("#back-top").hide();
	
	// fade in #back-top
	$(window).scroll(function () {
		if ($(this).scrollTop() > 100) {
			$('#back-top').fadeIn();
		} else {
			$('#back-top').fadeOut();
		}
	});

	// scroll body to 0px on click
	$('#back-top a').click(function () {
		$('body,html').animate({
			scrollTop: 0
		}, 800);
		return false;
	});
	
	
	$('.navbar').affix({
		offset: {
			top: 68
		}
	})
		
		
	$('.logo-small2').hide();
	
	$(document).scroll(function() {
	  var y = $(this).scrollTop();
	  if (y > 67) {
		$('.logo-small2').show();
	  } else {
		$('.logo-small2').hide();
	  }
	});
	
	
});




		