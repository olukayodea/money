<?php
	$redirect = "sendMoney";
	include_once("includes/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>index</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body class="my-account"> 
<?php $pages->topMenuSession(); ?>
   
       <div class="container">
         <div class="row margin-top10">
         <!--SEND MONEY-->
           <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" id="main-body">
             <div class="white-bg">
               <h2 class="deep-green hidden-xs hidden-sm"><img src="images/mobile-phone-icon.png" width="13" height="auto"> <span class="margin-left10">SEND MOBILE AIRTIME</span></h2>
                <div id="guide-con" class="padding-left-right15">
                   <div class="guide red">
                       You are sending <strong>NGN 1000.00</strong> Mobile Airtime to <strong>+234 812 345 6789</strong> on the <strong>MTN</strong> Network in <strong>Nigeria</strong>. Our fees will be <strong>£0.00.</strong> You will pay an exact total of <strong>£3.13.</strong> The mobile airtime will be applied instantly. The exchange rate is <strong>£1 = N320.00</strong>.
                    </div>
              <div class="form-horizontal">
                 <div class="row margin-top20 choose-box">
                   <div class="col-xs-12 margin-left20">
                       <div class="form-group margin-top24">
                        <div class="col-xs-4 col-sm-3 col-md-3 col-lg-3 text-center">
                         <label class="control-label">Name of <br>Cardholder</label><span class="text-red margin-left5">*</span>
                         </div>
                        <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                          <input type="text" value="NUBAN Account Number" class="form-control">
                        </div>
                      </div>
                     <div class="form-group margin-top24">
                          <div class="col-xs-4 col-sm-3 col-md-3 col-lg-3 text-center">
                          <label class="control-label">Card Type </label><span class="text-red margin-left5">*</span>
                        </div>
                        <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                            <select class="single-select" style="width:100%">
                                <option value="visa">Visa Credit </option>
                                <option value="debit">Visa Debit </option>
                                <option value="electron">Visa Electron </option>
                                <option value="mastercard">Mastercard</option>
                                <option value="solo">Solo</option>
                                <option value="maestro">Maestro</option>
                            </select>
                          </div>
                      </div>
                         <div class="form-group margin-top24">
                           <div class="col-xs-4 col-sm-3 col-md-3 col-lg-3 text-center">
                             <label class="control-label">Card Number </label><span class="text-red margin-left5">*</span>
                          </div>
                        <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                          <input type="text" class="form-control">
                        </div>
                      </div> 
                       <div class="form-group margin-top24">
                         <div class="col-xs-4 col-sm-3 col-md-3 col-lg-3 text-center">
                         <label class="control-label">Expiry Date</label><span class="text-red margin-left5">*</span>
                         </div>
                         <div class="col-xs-4 col-sm-2 col-md-2 col-lg-2">
                            <select class="form-control">
                              <option value="jan">Jan</option>
                              <option value="feb">Feb</option>
                              <option value="mar">March</option>
                              <option value="apr">April</option>
                              <option value="may">May</option>
                              <option value="jun">June</option>
                              <option value="jul">July</option>
                              <option value="aug">Aug</option>
                              <option value="sep">Sept</option>
                              <option value="oct">Oct</option>
                              <option value="nov">Nov</option>
                              <option value="dec">Dec</option>
                            </select>
                          </div>
                         <div class="col-xs-4 col-sm-2 col-md-2 col-lg-2">
                            <select class="form-control">
                              <option value="19">1999</option>
                              <option value="20">2000</option>
                              <option value="1">2001</option>
                              <option value="2">2002</option>
                              <option value="3">2003</option>
                              <option value="4">2004</option>
                              <option value="5">2005</option>
                              <option value="6">2006</option>
                              <option value="7">2007</option>
                              <option value="8">2008</option>
                              <option value="9">2009</option>
                              <option value="10">2010</option>
                              <option value="11">2011</option>
                              <option value="12">2012</option>
                              <option value="13">2013</option>
                              <option value="14">2014</option>
                            </select>
                          </div> 
                        </div>
                       <div class="form-group margin-top24">
                         <div class="col-xs-4 col-sm-3 col-md-3 col-lg-3 text-center">
                           <label class="control-label">CVV Number</label><span class="text-red margin-left5">*</span>
                          </div>
                        <div class="col-xs-5 col-sm-2 col-md-2 col-lg-2">
                           <input type="text" class="form-control">
                          </div>
                          <div class="col-xs-2">
                            <span class="glyphicon glyphicon-question-sign font-size26 margin-top4" aria-hidden="true"></span>
                          </div>
                        </div>
                       <p class="font-size12 text-center">This transaction will appear on your card/bank statement as <br>a payment to PayMack Limited</p>
                        <div class="col-xs-10 col-sm-12 col-md-12 col-lg-12 margin-top30 continue-btn">
                          <a href="send-mobile-airtime.php" class="btn-gray">Back</a>
                          <a href="sendMoney" class="btn-green2 margin-left18">Submit</a>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         <!--/SEND MONEY-->
         
          <!--Icon-Panel-->
          <div class="col-xs-4 col-sm-12 col-md-12 col-lg-12 hidden-xs hidden-sm" id="sidebar">
            <div class="white-bg padding-top15">
              <div class="padding-left-right15 clearfix">
                  <div class="sky-box">
                  <div class="margin-top10 text-center font-size20"><strong>Hello</strong></div>
                  <span class="glyphicons glyphicons-user font-size70"></span>
                  <div class="margin-top10 text-center font-size20"><strong><?php echo $last_name." ".$other_names; ?></strong></div>
                </div>
                   <div id="box-panel"> 
              	<a href="sendMoney" class="money-box"> <span class="glyphicons glyphicons-credit-card font-size45"></span><span class="margin-top15 all-icon-box">Send Money</span> </a> 
                <a href="send-mobile-airtime.php" class="send-mobile-box active"> <span><img src="images/mobile-phone-icon.png" height="44"></span><span class="margin-top15 all-icon-box">Send  Mobile Airtime</span> </a> 
                <a href="pay-bills.php"class="pay-bills-box"> <span><img src="images/bill.png" width="37" height="auto"></span><span class="margin-top15 all-icon-box">Pay Bills</span> </a> 
                <a href="myPayments" class="payments-box"> <span class="glyphicons glyphicons-circle-arrow-right small-payments-text"></span><span class="margin-top15 all-icon-box">My Payments</span> </a> 
                <a href="profile" class="profile-box"> <span class="glyphicons glyphicons-user font-size45"></span><span class="margin-top15 all-icon-box">My Profile</span> </a> 
                <a href="myRecipientList"class="recipients-box"> <span class="glyphicons glyphicons-group small-payments-text"></span><span class="margin-top15 all-icon-box">My Recipients</span> </a> 
                <a href="invite-friends.php" class="invite-box"> <span class="glyphicons glyphicons-user-add small-payments-text"></span><span class="margin-top15 all-icon-box">Invite Friends</span> </a> 
                <a href="changePassword" class="password-box"> <span class="glyphicons glyphicons-lock"></span><span class="margin-top15 all-icon-box">Change Password</span> </a> 
             </div>
              </div>
            </div>
          </div>
          <!--/Icon-Panel-->
         </div>
         
         
       </div>
     
   
    <!--/Body Part-->
  
    
  <?php $pages->homeFooter(); ?>

</body>
</html>