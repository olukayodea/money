<?php
	include_once("../functions.php");
	$id = $common->get_prep($_REQUEST['id']);
	$info = $transactions->getOne($id);
	$data = $common->unwrap($info['data']);
	$userData = $users->listOne($data['user']);
	$last_name = $common->get_prep($userData['last_name']);		
	$email = $common->get_prep($userData['email']);
	$other_names = $common->get_prep($userData['other_names']);
?>
<html>
<head>
<style type="text/css">
<!--
.title {
	font-family: Arial, Helvetica, sans-serif;
	padding: 5px;
	font-weight:bold;
	color: #FFFFFF;
	font-size: 16px;
}

.header {
    background: none repeat scroll 0% 0% #0E3F97;
    border-bottom: 3px solid #F0C237;
}

.title2 {
	font-family: Arial, Helvetica, sans-serif;
	padding: 5px;
	font-weight:bold;
	color: #000000;
	font-size: 14px;
}
.messege {
	font-family: Arial, Helvetica, sans-serif;
	padding: 5px;
	font-weight:bold;
	color: #000000;
	font-size: 12px;
}
.logoThumb{
	float:left;
	padding: 2px;
	margin: 3px;
	/*border: 1px solid #F0F0F0;*/
	text-align: center;
	vertical-align: middle;
}
.logoThumb img{border:0px}
body,td,th {
	font-family: tahoma;
	font-size: 11px;
	color: #FFFFFF;
}
.text {
	font-family: tahoma;
	font-size: 11px;
	color: #000000;
	padding: 5px;
}
-->
</style>
<title><?php echo $common->get_prep($_REQUEST['subject']); ?></title>
</head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td>
    <div class="logoThumb"><img src="<?php echo URL; ?>images/logo.png" width="150" alt=""></div>
      
     </td>
  </tr>

  <tr>
    <td>
    <p class="text">Dear <?php echo $last_name; ?>, </p>
    <p class="text">Your recent transfer to <strong><?php echo $recipient_money->getOneField($data['recipient'], "ref", "account_name"); ?></strong> was successful. Please see below a copy of your payment reciept.please do not forget to quote <strong># <?php echo $info['trax_id']; ?></strong> when calling us regarding this payment
      <div class="form-group margin-top24">
                    <div class="text">Transaction Reference</div>
                                 <div class="text"><strong>#<?php echo $info['trax_id']; ?></strong></div>
      </div>
                  <div class="form-group margin-top24">
                    <div class="text">Transaction Status</div>
                                 <div class="text"><strong><?php echo $info['status']; ?></strong></div>
                  </div>
                  <div class="form-group margin-top24">
                    <div class="text">Transaction Completed at</div>
                                 <div class="text"><strong><?php echo date('l jS \of F Y h:i:s A', $info['modify_time']); ?></strong></div>
                  </div>
                  <div class="form-group margin-top24">
                    <div class="text"> Amount to Send</div>
                                 <div class="text"><strong><?php echo $common->selectcurrency($data['send_currency'])." ".number_format($data['amount'], 2); ?></strong></div>
                  </div>
                 <div class="form-group margin-top24">
                   <div class="text"> To </div>
                   <div class="text"><strong>Nigeria</strong></div>
      </div>
                 <div class="form-group margin-top24">
                   <div class="text"> Our Fees</div>
                   <div class="text"><strong><?php echo $common->selectcurrency($data['send_currency'])." ".number_format($data['fee'], 2); ?></strong></div>
      </div>
                 <div class="form-group margin-top24">
                   <div class="text">Recipient Bears Fees</div>
                     <div class="text"><strong>Yes</strong></div>
      </div>
                 <div class="form-group margin-top24">
                   <div class="text">Total to Pay</div>
                   <div class="text"><strong><?php echo $common->selectcurrency($data['send_currency'])." ".number_format($data['balance'], 2); ?></strong></div>
                 </div>
                 <div class="form-group margin-top24">
                   <div class="text">Recipient Recieves</div>
                   <div class="text"><strong><?php echo $common->selectcurrency("NG")." ".number_format($data['balance']*$data['xchange'], 2); ?></strong></div>
                 </div>
                 <div class="form-group margin-top24">
                   <div class="text">Recipient Bank</div>
                   <div class="text"><strong><?php echo $bank->getOneField($recipient_money->getOneField($data['recipient'], "ref", "bank")); ?></strong></div>
                 </div>
                 <div class="form-group margin-top24">
                   <div class="text">Account Number</div>
                   <div class="text"><strong><?php echo $recipient_money->getOneField($data['recipient'], "ref", "account_number"); ?></strong></div>
                 </div>
                 <div class="form-group margin-top24">
                   <div class="text">Account Name</div>
                   <div class="text"><strong><?php echo $recipient_money->getOneField($data['recipient'], "ref", "account_name"); ?></strong></div>
                 </div></p>
  <span class="text">Regards,</span><br>
  <span class="text">PayMack.com</span><span class="text"></span></p>
      <p class="text">This email is intended for <?php echo $last_name; ?> <?php echo $other_names; ?>, please do not reply directly to this email. This email was sent from a notification-only address that cannot accept incoming email.</p>
<p class="text"><strong>Protect Your Password</strong><br>
Be alert to emails that request account information or urgent action.  Be cautious of websites with irregular addresses or those that offer   unofficial payments to PayMack Administrator or other privates accounts.<br>
</p></td>
  </tr>
  <tr>
    <td bgcolor="#009999">&copy; <?php echo date("Y"); ?> PayMack, All Rights Reserved</td>
  </tr>
</table>

<div class="header">
</div>
</body>
</html>