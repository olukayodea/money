<?php
	$urlData = explode("?", $_SERVER['REQUEST_URI']);
		
	if (isset($_SESSION['users']['ref'])) {
		$ref = trim($_SESSION['users']['ref']);
		$last_name = trim($_SESSION['users']['last_name']);
		$other_names = trim($_SESSION['users']['other_names']);
		$phone = trim($_SESSION['users']['phone']);
		$accountStatus = trim($_SESSION['users']['status']);
		$email = trim($_SESSION['users']['email']);
		$loginTime = trim($_SESSION['users']['loginTime']);
		$modify_time = trim($_SESSION['users']['modify_time']);
		$date_time = trim($_SESSION['users']['date_time']);
		
		$sessionTime = trim($_SESSION['users']['sessionTime']);
		
		if (($accountStatus == "NEW") && ($redirect != "profile")) {
			$tagLink = $redirect."?".$urlParam;
			header("location: profile?redirect=".urlencode($redirect."?".$urlData[1]));
		}
		
		if ($sessionTime < time()) {
			//add to log
			$logArray['object'] = "users";
			$logArray['object_id'] = $_SESSION['users']['id'];
			$logArray['owner'] = "users";
			$logArray['owner_id'] = $_SESSION['users']['id'];
			$logArray['desc'] = "Session timed out";
			$logArray['create_time'] = time();
			$system_log = new system_log;
			$system_log->create($logArray);
			
			$logout_time = date("Y-m-d H:i:s");
			$session_id = session_id();
			$_SESSION = array();
			if(isset($_COOKIE[session_name()])) {
				setcookie(session_name(), '', time()-42000, '/');
			}
			session_destroy();
			header("location: login?redirect=".$redirect."&msg=you+must+login+to+continue"."&".$urlData[1]);
		} else {
			$_SESSION['users']['sessionTime'] = time() + 1800;
		}
	} else {
		header("location: login?redirect=".$redirect."&msg=please+login"."&".$urlData[1]);
	}
?>