<?php
	include_once("../functions.php");
	$val = $_REQUEST['val'];
	
	$data = $users->checkAccount($val);
	
	if ($data > 0) {
		echo '2';
	} else {
		echo '1';
	}
?>