<?php
	include_once("../functions.php");
	$id = $common->get_prep($_POST['id']);
	
	$data = $recipient_money->getOne($id);
	$phonedata = explode("-", $data['phone']);
	
	echo $data['bank']."#".$data['account_number']."#".$data['account_name']."#".$phonedata[0]."#".$phonedata[1]."#".$data['email']."#".$bank->getOneField($data['bank']);
?>