<?php
	include_once("../functions.php");
	$formData = $_POST['formData'];
	$id = $common->get_prep($_POST['inventory']);
	$qty = $common->get_prep($_POST['qty']);
	
	$inventoryItemData = $inventory->getOne($id);
	
	$cookieData = json_decode($_COOKIE['history'], true);
	$cookieData[] = $inventoryItemData['category'];
	
	$cookieData = array_unique($cookieData);
	setcookie("history", json_decode($cookieData), time+(60*60*24*30), "/");
	
	$json_data = json_decode($formData, true);
	$otherParameter = "";
	if (is_array($json_data)) {
		foreach ($json_data as $key => $value) {
			$otherParameter .= $key.": ".$value."<br />";
		}
	}
	
	$array = array();
	
	$array['inventory'] = $id;
	$array['qty'] = $qty;
	$array['unit_price'] = $inventoryItemData['price'];
	$array['total_price'] = $inventoryItemData['price']*$qty;
	$array['otherParameter'] = $otherParameter;
	
	$add = $cart->add($array);
	
	$data = $cart->getAll();
	
	if (count($data) > 0) {
		if (count($data) > 4) {
			$count = 3;
		} else {
			$count = count($data);
		} ?>
      <div class="block-subtitle">Recently added item(s)</div>
      <ul id="cart-sidebar" class="mini-products-list">
      <?php for ($i = 0; $i < $count; $i++) {
          $inventoryData = $inventory->getOne($data[$i]['inventory']);
          $photoAlb = $inventory->getMainPicture($data[$i]['inventory']);
          $total = $total + $data[$i]['total_price']; ?>
        <li class="item odd"> <a href="<?php echo $common->seo($data[$i]['inventory'], "item"); ?>" title="<?php echo $inventoryData['title']; ?>" class="product-image"><img src="<?php echo $photoAlb[0]; ?>" alt="<?php echo $inventoryData['title']; ?>" width="55"></a>
          <div class="product_details"> <a href="<?php echo $common->seo($data[$i]['inventory'], "item"); ?>" title="Remove This Item" onClick="" class="btn-remove1">Remove This Item</a> <a class="btn-edit" title="Edit item" href="#">Edit item</a>
            <p class="product-name"><a href="<?php echo $common->seo($data[$i]['inventory'], "item"); ?>"><?php echo $inventoryData['title']; ?></a> </p>
            <strong>1</strong> x <span class="price"><?php echo NGN.number_format($data[$i]['total_price'], 2); ?></span> </div>
        </li>
      <?php } ?>
      </ul>
      <div class="top-subtotal">Subtotal: <span class="price"><?php echo NGN.number_format($total, 2); ?></span></div>
      <div class="actions">
		<button class="btn-checkout" onclick="window.location.href='<?php echo URL; ?>checkout'" type="button"><span>Checkout</span></button>
		<button class="view-cart" onclick="window.location.href='<?php echo URL; ?>shoppingCart'" type="button"><span>View Cart</span></button>
      </div>
    <?php } else { ?>
      <div class="block-subtitle">Cart is Empty</div>
    <?php } ?>
