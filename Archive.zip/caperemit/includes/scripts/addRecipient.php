<?php
	include_once("../functions.php");
	$user = $common->get_prep($_POST['user']);
	$checkEdit = $common->get_prep($_POST['checkEdit']);
	$recipient = $common->get_prep($_POST['recipient']);
	$account_number = $common->get_prep($_POST['account_number']);
	$bank = $common->get_prep($_POST['bank']);
	$account_name = $common->get_prep($_POST['account_name']);
	$phone = $common->get_prep($_POST['phone']);
	$phone2 = $common->get_prep($_POST['phone2']);
	$phoneNumber = $_POST['phoneNumber'] = $phone2."-".ltrim($phone, "0");
	$email = $common->get_prep($_POST['email']);
	$_SESSION['tempPayment']['user'] = $user;
	if ($recipient == -1) {
		if ($checkEdit > 0) {
			$_POST['ref'] = $checkEdit;
		}
		$add = $recipient_money->add($_POST);
		$_SESSION['tempPayment']['recipient'] = $add;
	} else {
		$_SESSION['tempPayment']['recipient'] = $recipient;
	}
	
	echo 1;