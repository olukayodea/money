<?php
	include_once("../functions.php");
	$id = $common->get_prep($_POST['id']);
	$data = $inventory->ListBycategory($id);
?>
<?php if (count($data) > 0) { ?>          
<div class="category-products">
    <ul class="products-grid">
    <?php for ($i = 0; $i < count($data); $i++) {
		$photoAlb = $inventory->getMainPicture($data[$i]['ref']); ?>
      <li class="item col-lg-4 col-md-3 col-sm-4 col-xs-12">
        <div class="item-inner">
          <div class="product-block">
            <div class="product-image"> <a href="<?php echo $common->seo($data[$i]['ref'], "item"); ?>">
              <figure class="product-display">
                 <!--- sales tag --->
                <?php if ($data[$i]['sale'] != 0) { ?>
                <div class="sale-label sale-top-left">Sale</div>
                <?php } ?>
                <img height="250" src="<?php echo $photoAlb[0]; ?>" class="lazyOwl product-mainpic" alt="<?php echo $data[$i]['title']; ?>" style="display: block;"> <img height="250" class="product-secondpic" alt="" src="<?php echo $photoAlb[1]; ?>"> </figure>
              </a> </div>
            <div class="product-meta">
              <div class="product-action"> <a class="addcart" href="<?php echo $common->seo($data[$i]['ref'], "item"); ?>"> <i class="icon-shopping-cart">&nbsp;</i> Add to cart </a> <a class="wishlist" href="<?php echo URL; ?>wishlist.html"> <i class="icon-heart">&nbsp;</i> </a> <a class="quickview" href="<?php echo URL; ?>quick_view?id=<?php echo $data[$i]['ref']; ?>"> <i class="icon-zoom">&nbsp;</i> </a> </div>
            </div>
          </div>
          <div class="item-info">
            <div class="info-inner">
              <div class="item-title"> <a href="<?php echo $common->seo($data[$i]['ref'], "item"); ?>" title="<?php echo $data[$i]['title']; ?>"> <?php echo $data[$i]['title']; ?> </a> </div>
              <div class="item-content">
                <div class="item-price">
                  <div class="price-box">
                  <?php if ($data[$i]['sale'] == 0) { ?>
                  	<!-- no sales --->
                    <span class="regular-price"><span class="price"><?php echo NGN." ".number_format($data[$i]['price'], 2); ?></span> </span>
                    <?php } else { ?>
                  	<!-- with sales --->
                    <p class="old-price"> <span class="price-label">Regular Price:</span> <span class="price" id="old-price-2"> <?php echo NGN." ".number_format($data[$i]['price'], 2); ?> </span> </p>
                    <p class="special-price"> <span class="price-label">Special Price</span> <span class="price" id="product-price-2"> <?php echo NGN." ".number_format($inventory->calcDisc($data[$i]['ref']), 2); ?> </span> </p>
                    <?php } ?>
                  </div>
                </div>
                <div class="rating">
                  <div class="ratings">
                    <div class="rating-box">
                      <div class="rating" style="width:<?php echo $comment->sumItem($data[$i]['ref']); ?>%"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </li>
    <?php } ?>
    </ul>
</div>
<?php } ?>