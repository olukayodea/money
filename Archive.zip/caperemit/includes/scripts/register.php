<?php
	include_once("../functions.php");
	$array = array();
	$array['last_name'] = $common->get_prep($_REQUEST['last_name']); 
	$array['other_names'] = $common->get_prep($_REQUEST['other_names']); 
	$array['email'] = $common->get_prep($_REQUEST['email']); 
	$array['password'] = $common->get_prep($_REQUEST['password']); 
	echo $add = $users->create($array);
?>