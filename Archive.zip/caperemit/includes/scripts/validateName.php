<?php
	include_once("../functions.php");
	$account_number = $common->get_prep($_POST['account_number']);
	$bank = $common->get_prep($_POST['bank']);
	
	//name verification API Call here
	
	$name = "John Smith";
	echo $name;
?>