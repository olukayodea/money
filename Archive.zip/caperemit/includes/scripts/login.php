<?php
	include_once("../functions.php");
	$array = array();
	$array['email'] = $common->get_prep($_REQUEST['email']); 
	$array['password'] = $common->get_prep($_REQUEST['password']); 
	
	echo $add = $users->login($array);
?>