<?php
	include_once("../functions.php");
	$email = $common->get_prep($_REQUEST['email']);
	
	$add = $users->checkAccount($email);
	
	if ($add == 1) {
		$data = $users->listOne($email, "email");
		//print_r($data);
		$client = $data['last_name']." ".$data['other_names']." <".$data['email'].">";
		$subjectToClient = "Password Reset Instructions";
		
		$contact = "PayMack<".replyMail.">";
			
		$fields = 'subject='.urlencode($subjectToClient).
			'&id='.urlencode($data['ref']);
		$mailUrl = URL."includes/emails/passwordInstructions.php?".$fields;
		$messageToClient = $common->curl_file_get_contents($mailUrl);
		
		$mail['from'] = $contact;
		$mail['to'] = $client;
		$mail['subject'] = $subjectToClient;
		$mail['body'] = $messageToClient;
		
		//print_r($mail);
		
		$alerts = new alerts;
		$alerts->sendEmail($mail);
		echo 1;
	} else {
		echo 0;
	}
?>