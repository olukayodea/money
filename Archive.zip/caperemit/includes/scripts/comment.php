<?php
	include_once("../functions.php");
	
	$id = $common->get_prep($_POST['inventory']);
	
	$add = $comment->add($_POST);
	
	if ($add) {
	
	$commentBox = $comment->sortAll("inventory", $id);
?>
    <ul>
    <?php 
    if (count($commentBox) < 1) { ?>
    <li>Be the first to review this product</li>
    <?php } else {
    for ($i = 0; $i < count($commentBox); $i++) { ?>
      <li>
        <table class="ratings-table">
          <colgroup>
          <col width="1">
          <col>
          </colgroup>
          <tbody>
            <tr>
              <th>Value</th>
              <td><div class="rating-box">
                  <div class="rating" style="width:<?php echo $comment->percentile($commentBox[$i]['value']); ?>%;"></div>
                </div></td>
            </tr>
            <tr>
              <th>Quality</th>
              <td><div class="rating-box">
                  <div class="rating" style="width:<?php echo $comment->percentile($commentBox[$i]['quality']); ?>%;"></div>
                </div></td>
            </tr>
            <tr>
              <th>Price</th>
              <td><div class="rating-box">
                  <div class="rating" style="width:<?php echo $comment->percentile($commentBox[$i]['price']); ?>%;"></div>
                </div></td>
            </tr>
          </tbody>
        </table>
        <div class="review">
          <h6><a href="#"><?php echo $commentBox[$i]['summary']; ?></a></h6>
          <small>Review by <span><?php echo $commentBox[$i]['name']; ?> </span> <?php echo $common->get_time_stamp($commentBox[$i]['create_time']); ?></small>
          <div class="review-txt"><?php echo $commentBox[$i]['comment']; ?></div>
        </div>
      </li>
    <?php }
    } ?>
    </ul>
<?php } ?>