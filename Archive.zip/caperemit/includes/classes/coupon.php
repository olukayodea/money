<?php
	class coupon extends common {
		function add($array) {
			$num = $array['num'];
			$batch = $this->confirm_batch(rand(11111, 99999), $clients);
			$point = $this->mysql_prep($array['point']);
			$expire = $this->mysql_prep($array['expire']);
			for ($i = 0; $i < $num; $i++) {
				$code = $this->confirm_code($this->createRandomPassword(5));
				$createTime = $modifyTime = time();
				$sql = mysql_query("INSERT INTO coupon (batch, code, point, expire, createTime, modifyTime) VALUES ( '".$batch."', '".$code."', '".$point."', '".$expire."', '".$createTime."', '".$modifyTime."')") or die (mysql_error());
			}
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "created batch ".$ref;
				$logArray['create_date'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return $batch;
			} else {
				return false;
			}
		}
		
		function modifyOne($tag, $value, $filter, $ref) {
			$value = $this->mysql_prep($value);
			$ref = $this->mysql_prep($ref);
			$modDate = time();
			$sql = mysql_query("UPDATE coupon SET `".$tag."` = '".$value."', `modifyTime` = '".$modDate."' WHERE ".$filter." = '".$ref."'") or die (mysql_error());
			
			if ($sql) {
				return true;
			} else {
				return false;
			}
		}
		
		function confirm_batch($code, $clients){
			$Voucher = mysql_num_rows(mysql_query("SELECT ref FROM coupon WHERE batch = '".$code."'"));
			if ($Voucher == 0) {
				return $code;
			}else{
				return $this->confirm_batch(rand(11111, 99999), $clients);
			}
		}
		
		function confirm_code($code){
			$Voucher = $this->viewOne($code, "code");
			if ($Voucher == false) {
				return $code;
			}else{
				return $this->confirm_code($this->createRandomPassword(7));
			}
		}
		
		function modify($array) {
			$ref = $this->mysql_prep($array['ref']);
			$point = $this->mysql_prep($array['point']);
			$expire = $this->mysql_prep($array['expire']);
			$modifyTime = time();
			$sql = mysql_query("UPDATE coupon SET expire = '".$expire."', point = '".$point."', modifyTime = '".$modifyTime."' WHERE batch = '".$ref."'") or die (mysql_error());
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "modified batch ".$ref;
				$logArray['create_date'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
			
		}
		
		function remove($ref) {
			$ref = $this->mysql_prep($ref);
			$sql = mysql_query("DELETE FROM coupon WHERE batch = '".$ref."'") or die (mysql_error());
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "deleted batch ".$ref;
				$logArray['create_date'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function viewAll($tag, $value, $order = 'ref') {
			if ($tag != 'all') {
				$where = " WHERE ".$tag." = '".$value."'";
			} else {
				$where = "";
			}
			$sql = mysql_query("SELECT * FROM coupon".$where." ORDER BY ".$order." ASC ") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['batch'] = $row['batch'];
					$result[$count]['code'] = $row['code'];
					$result[$count]['point'] = $row['point'];
					$result[$count]['expire'] = $row['expire'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['createTime'] = $row['createTime'];
					$result[$count]['modifyTime'] = $row['modifyTime'];
					$count++;
				}
				return $this->out_prep($result);
			} else {
				return false;
			}
		}
		
		function viewAllGroup($tag, $value =0, $group, $order = 'ref') {
			if ($tag != 'all') {
				$where = " WHERE ".$tag." = '".$value."'";
			} else {
				$where = "";
			}
			$sql = mysql_query("SELECT * FROM coupon".$where." GROUP BY ".$group." ORDER BY ".$order." ASC ") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['batch'] = $row['batch'];
					$result[$count]['code'] = $row['code'];
					$result[$count]['point'] = $row['point'];
					$result[$count]['expire'] = $row['expire'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['createTime'] = $row['createTime'];
					$result[$count]['modifyTime'] = $row['modifyTime'];
					$count++;
				}
				return $this->out_prep($result);
			} else {
				return false;
			}
		}
		
		function viewOne($ref, $tag = 'ref') {
			$sql = mysql_query("SELECT * FROM coupon WHERE ".$tag." = '".$ref."'") or die (mysql_error());
			if ($sql) {
				$result = array();
				
				if (mysql_num_rows($sql) > 0) {
					$row = mysql_fetch_array($sql);
					$result['ref'] = $row['ref'];
					$result['batch'] = $row['batch'];
					$result['code'] = $row['code'];
					$result['point'] = $row['point'];
					$result['expire'] = $row['expire'];
					$result['status'] = $row['status'];
					$result['createTime'] = $row['createTime'];
					$result['modifyTime'] = $row['modifyTime'];
				
					return $this->out_prep($result);
				} else {
					return 0;
				}
			} else {
				return false;
			}
		}
	}
?>