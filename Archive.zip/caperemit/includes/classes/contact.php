<?php
	class contact extends common {
		function add($array) {
			$subject = $this->mysql_prep($array['subject']);
			$message = nl2br($this->mysql_prep($array['message']));
			$name = $this->mysql_prep($array['name']);
			$email = $this->mysql_prep($array['email']);
			$phone = $this->mysql_prep($array['phone']);
			$transaction = $this->mysql_prep($array['transaction']);
			$loc_city = $_SESSION['location_data']['loc_city'];
			$loc_region = $_SESSION['location_data']['loc_region'];
			$loc_country = $_SESSION['location_data']['loc_country'];
			$loc_continent = $_SESSION['location_data']['loc_continent'];
			$loc_lat = $_SESSION['location_data']['loc_lat'];
			$loc_long = $_SESSION['location_data']['loc_long'];
			$create_time = $modify_time = time();
			
			$sql = mysql_query("INSERT INTO `contact` (`subject`,`message`,`name`,`email`,`phone`,`transaction`,`loc_city`,`loc_region`,`loc_country`,`loc_continent`,`loc_lat`,`loc_long`,`create_time`,`modify_time`) VALUES ('".$subject."','".$message."','".$name."','".$email."','".$phone."','".$transaction."','".$loc_city."','".$loc_region."','".$loc_country."','".$loc_continent."','".$loc_lat."','".$loc_long."','".$create_time."','".$modify_time."')") or die (mysql_error());
			
			if ($sql) {
				$contact = $name." <".$email.">";
				$subjectToClient = $subject;
				
				$client = "PayMack <team@PayMack.com>";
				//$client = "PayMack <olukayode.adebiyi@nqb8group.com>";
				
				$messageToClient = "<p>you received the following contact us message from</p>
				<p>Name: <strong>".$name."</strong><br />
				  E-mail: <strong>".$email."</strong><br />
				  Phone: <strong>".$phone."</strong><br />
				  Transaction ID: <strong>".$transaction."</strong><br />
				Subject: <strong>".$subject."</strong></p>
				<p>Message</p>
				<p><strong>".$message."</strong></p>
				<p>Message sent at ".date('l jS \of F Y h:i:s A')." from ".$loc_city." ".$loc_country." ".$loc_region." ".$loc_continent."</p>";
				
				$mail['from'] = $contact;
				$mail['to'] = $client;
				$mail['subject'] = $subjectToClient;
				$mail['body'] = $messageToClient;
				
				$alerts = new alerts;
				$alerts->sendEmail($mail);
				
				return true;
			} else {
				return false;
			}
		}
	}
?>