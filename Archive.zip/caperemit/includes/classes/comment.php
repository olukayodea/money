<?php
	class comment extends common {
		function add($array) {
			$inventory = $this->mysql_prep($array['inventory']);
			$summary = $this->mysql_prep($array['summary']);
			$comment = $this->mysql_prep($array['comment']);
			$value = $this->mysql_prep($array['value']);
			$quality = $this->mysql_prep($array['quality']);
			$price = $this->mysql_prep($array['price']);
			$name = ucfirst(strtolower($this->mysql_prep($array['name'])));
			$create_time = time();
			
			$sql = mysql_query("INSERT INTO `comment` (`inventory`,`summary`, `comment`, `value`, `quality`, `price`, `name`, `create_time`) VALUES ('".$inventory."','".$summary."','".$comment."','".$value."','".$quality."','".$price."','".$name."','".$create_time."')") or die (mysql_error());
			
			if ($sql) {
				$id = mysql_insert_id();
				return $id;
			} else {
				return false;
			}
			
		}
		
		function delete($id) {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("DELETE FROM comment WHERE ref = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "Deleted Album '".$id."' created on ".date('l jS \of F Y h:i:s A', $data['create_time']);
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function listAll() {
			$sql = mysql_query("SELECT * FROM `comment` ORDER BY `inventory` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['comment'] = $row['comment'];
					$result[$count]['inventory'] = $row['inventory'];
					$result[$count]['summary'] = $row['summary'];
					$result[$count]['value'] = $row['value'];
					$result[$count]['quality'] = $row['quality'];
					$result[$count]['price'] = $row['price'];
					$result[$count]['name'] = $row['name'];
					$result[$count]['create_time'] = $row['create_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function sortAll($tag, $id) {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("SELECT * FROM `comment` WHERE `".$tag."`  = '".$id."' ORDER BY `inventory` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['comment'] = $row['comment'];
					$result[$count]['inventory'] = $row['inventory'];
					$result[$count]['summary'] = $row['summary'];
					$result[$count]['value'] = $row['value'];
					$result[$count]['quality'] = $row['quality'];
					$result[$count]['price'] = $row['price'];
					$result[$count]['name'] = $row['name'];
					$result[$count]['create_time'] = $row['create_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function getOne($id, $tag='ref') {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("SELECT * FROM `comment` WHERE `".$tag."` = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				
				$row = mysql_fetch_array($sql);
				if ($row > 0) {
					$result['ref'] = $row['ref'];
					$result['comment'] = $row['comment'];
					$result['inventory'] = $row['inventory'];
					$result['summary'] = $row['summary'];
					$result['value'] = $row['value'];
					$result['quality'] = $row['quality'];
					$result['price'] = $row['price'];
					$result['name'] = $row['name'];
					$result['create_time'] = $row['create_time'];
				}
				
				return $this->out_prep($result);
			}
		}
		
		function sumItem($id) {
			$total = 0;
			$max = 0;
			$data = $this->sortAll("inventory", $id);
			for ($i = 0; $i < count($data); $i++) {
				$avg = $data[$i]['value']+$data[$i]['quality']+$data[$i]['price'];
				$total = $total + $avg;
				$max = $max + 15;
			}
						
			$result = number_format(ceil(($total/$max)*100));
			
			return $result;
		}
		
		function percentile($value) {
			$value = ($value/5)*100;
			
			return $value;
		}
                
		function getOneField($id, $tag="ref", $ref="comment") {
			$data = $this->getOne($id, $tag);
			return $data[$ref];
		}
	}
?>