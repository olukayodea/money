<?php
	class inventory extends common {
		function add($array) {
			$categories_class = new categories;
			$title = ucfirst(strtolower($this->mysql_prep($array['title'])));
			$category = $categories_class->getOneField($this->mysql_prep($array['cat']), "title", "ref");
			$desc = nl2br($this->mysql_prep($array['desc']));
			$keywords = $this->mysql_prep($array['keywords']);
			$meta_description = $this->mysql_prep($array['meta_description']);
			$code = $this->confirmUnique($this->createUnique());
			$quantity = $this->mysql_prep($array['quantity']);
			$sale = $this->mysql_prep($array['sale']);
			$discount = $this->mysql_prep($array['discount']);
			$price = $this->mysql_prep($array['price']);
			$properties = @implode(",", $_SESSION['tempData']['property']);
			$status = $this->mysql_prep($array['status']);
			$createTime = $modifyTime = time();
			$ref = $this->mysql_prep($array['ref']);
			
			if ($ref != "") {
				$firstpart = "`ref`, ";
				$secondPArt = "'".$ref."', ";
				$log = "Modified object ".$title;
			} else {
				$firstpart = "";
				$secondPArt = "";
				$log = "Created object ".$title;
			}
			
			$sql = mysql_query("INSERT INTO `inventory` (".$firstpart."`title`, `category`, `desc`, `keywords`, `meta_description`, `code`, `quantity`, `price`, `properties`, `status`, `createTime`, `modifyTime`) VALUES (".$secondPArt."'".$title."','".$category."','".$desc."','".$keywords."','".$meta_description."','".$code."','".$quantity."','".$price."','".$properties."','".$status."', '".$createTime."', '".$modifyTime."') ON DUPLICATE KEY UPDATE `title` = '".$title."', `category` = '".$category."', `desc` = '".$desc."', `meta_description` = '".$meta_description."', `quantity` = '".$quantity."', `price` = '".$price."', `sale` = '".$sale."',  `discount` = '".$discount."',  `properties` = '".$properties."', `status` = '".$status."', `modifyTime` = '".$modifyTime."'") or die (mysql_error());
			
			if ($sql) {
				$id = mysql_insert_id();
				$photos = new photos;
				$photos->deleteAll($id);
				for ($i = 0; $i < count($_SESSION['tempData']['media']); $i++) {
					$photoArray['inventory'] = $id;
					$photoArray['photos'] = $_SESSION['tempData']['media'][$i];
					$photos->add($photoArray);
				}
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = $tag;
				$logArray['create_date'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				
				unset($_SEEION['tempData']);
				return $id;
			} else {
				return false;
			}
		}
		
		
		function createUnique() {
			$num = $this->createRandomPassword(5).rand(100, 999);
			return $num;
		}
		
		function confirmUnique($key) {
			$key = $this->mysql_prep($key);
			$sql = mysql_query("SELECT * FROM inventory WHERE `code` = '".$key."'") or die (mysql_error()."sch");
			if (mysql_num_rows($sql) == 0) {
				return $key;
			} else {
				return $this->confirmUnique($this->createUnique());
			}
		}
		
		function remove($id) {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("DELETE FROM `inventory` WHERE ref = '".$id."'") or die (mysql_error());
				
			if ($sql) {
				$photos = new photos;
				$photos->deleteAll($id);
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "removed Inventory Item with Ref ".$id;
				$logArray['create_date'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function modifyOne($tag, $value, $id) {
			$value = $this->mysql_prep($value);
			$id = $this->mysql_prep($id);
			$modDate = time();
			$sql = mysql_query("UPDATE `inventory` SET `".$tag."` = '".$value."', `modifyTime` = '".$modDate."' WHERE ref = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "updated field ".$tag."  with value'".$value."' of Inventory Item with Ref ".$id;
				$logArray['create_date'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function listAll() {
			$sql = mysql_query("SELECT * FROM `inventory` ORDER BY `title` DESC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['title'] = $row['title'];
					$result[$count]['category'] = $row['category'];
					$result[$count]['desc'] = $row['desc'];
					$result[$count]['keywords'] = $row['keywords'];
					$result[$count]['meta_description'] = $row['meta_description'];
					$result[$count]['code'] = $row['code'];
					$result[$count]['quantity'] = $row['quantity'];
					$result[$count]['price'] = $row['price'];
					$result[$count]['sale'] = $row['sale'];
					$result[$count]['discount'] = $row['discount'];
					$result[$count]['category'] = $row['category'];
					$result[$count]['properties'] = $row['properties'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['createTime'] = $row['createTime'];
					$result[$count]['modifyTime'] = $row['modifyTime'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function listRandom($limit = 10, $sale=false) {
			if ($sale == true) {
				$addOn = " AND `sale` = 1";
			} else {
				$addOn = "";
			}
			
			$sql = mysql_query("SELECT * FROM `inventory` WHERE `status` = 'active'".$addOn." ORDER BY RAND() LIMIT ".$limit) or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['title'] = $row['title'];
					$result[$count]['category'] = $row['category'];
					$result[$count]['desc'] = $row['desc'];
					$result[$count]['keywords'] = $row['keywords'];
					$result[$count]['meta_description'] = $row['meta_description'];
					$result[$count]['code'] = $row['code'];
					$result[$count]['quantity'] = $row['quantity'];
					$result[$count]['price'] = $row['price'];
					$result[$count]['sale'] = $row['sale'];
					$result[$count]['discount'] = $row['discount'];
					$result[$count]['category'] = $row['category'];
					$result[$count]['properties'] = $row['properties'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['createTime'] = $row['createTime'];
					$result[$count]['modifyTime'] = $row['modifyTime'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function ListBycategory($id, $sale=false) {
			$categories = new categories;
			$ids = $categories->linkListListDef($id);
			
			if ($sale == true) {
				$addOn = " AND `sale` = 1";
			} else {
				$addOn = "";
			}
			
			$sql = mysql_query("SELECT * FROM `inventory` WHERE `category` IN (".$ids.")".$addOn." AND `status` = 'active' ORDER BY `title` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['title'] = $row['title'];
					$result[$count]['category'] = $row['category'];
					$result[$count]['desc'] = $row['desc'];
					$result[$count]['keywords'] = $row['keywords'];
					$result[$count]['meta_description'] = $row['meta_description'];
					$result[$count]['code'] = $row['code'];
					$result[$count]['quantity'] = $row['quantity'];
					$result[$count]['price'] = $row['price'];
					$result[$count]['sale'] = $row['sale'];
					$result[$count]['discount'] = $row['discount'];
					$result[$count]['category'] = $row['category'];
					$result[$count]['properties'] = $row['properties'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['createTime'] = $row['createTime'];
					$result[$count]['modifyTime'] = $row['modifyTime'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function sortAll($id, $tag, $tag2=false, $id2=false, $tag3=false, $id3=false) {
			$id = $this->mysql_prep($id);
			$id2 = $this->mysql_prep($id2);
			$id3 = $this->mysql_prep($id3);
			if ($tag2 != false) {
				$sqlTag = " AND `".$tag2."` = '".$id2."'";
			} else {
				$sqlTag = "";
			}
			if ($tag3 != false) {
				$sqlTag .= " AND `".$tag3."` = '".$id3."'";
			} else {
				$sqlTag .= "";
			}
			
			$sql = mysql_query("SELECT * FROM `inventory` WHERE `".$tag."` = '".$id."'".$sqlTag." ORDER BY `title` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['title'] = $row['title'];
					$result[$count]['category'] = $row['category'];
					$result[$count]['desc'] = $row['desc'];
					$result[$count]['keywords'] = $row['keywords'];
					$result[$count]['meta_description'] = $row['meta_description'];
					$result[$count]['code'] = $row['code'];
					$result[$count]['quantity'] = $row['quantity'];
					$result[$count]['price'] = $row['price'];
					$result[$count]['sale'] = $row['sale'];
					$result[$count]['discount'] = $row['discount'];
					$result[$count]['category'] = $row['category'];
					$result[$count]['properties'] = $row['properties'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['createTime'] = $row['createTime'];
					$result[$count]['modifyTime'] = $row['modifyTime'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function getOne($id, $tag='ref') {
			$id = $this->mysql_prep($id);
			$transaction_type = $this->mysql_prep($transaction_type);
			$sql = mysql_query("SELECT * FROM `inventory` WHERE `".$tag."` = '".$id."' ORDER BY `ref` DESC LIMIT 1") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				
				if (mysql_num_rows($sql) == 1) {
					$row = mysql_fetch_array($sql);
					$result['ref'] = $row['ref'];
					$result['title'] = $row['title'];
					$result['category'] = $row['category'];
					$result['desc'] = $row['desc'];
					$result['keywords'] = $row['keywords'];
					$result['meta_description'] = $row['meta_description'];
					$result['code'] = $row['code'];
					$result['quantity'] = $row['quantity'];
					$result['price'] = $row['price'];
					$result['sale'] = $row['sale'];
					$result['discount'] = $row['discount'];
					$result['category'] = $row['category'];
					$result['properties'] = $row['properties'];
					$result['status'] = $row['status'];
					$result['createTime'] = $row['createTime'];
					$result['modifyTime'] = $row['modifyTime'];
					
					return $this->out_prep($result);
				} else {
					return false;
				}
			}
		}
		
		function getOneField($id, $tag="ref", $ref="title") {
			$data = $this->getOne($id, $tag);
			return $data[$ref];
		}
		
		function calcDisc($id) {
			$discount = $this->getOneField($id, "ref", "discount");
			$price = $this->getOneField($id, "ref", "price");
			
			$percentage = (1-($discount/100))*$price;
			
			return $percentage;
		}
		
		function getMainPicture($id) {
			$photos = new photos;
			$data = $photos->sortAll("inventory", $id);
			if (count($data) > 0) {
				$return[] = URL."products-images/".$data[0]['photos'];
				if (count($data) > 1) {
					$return[] = URL."products-images/".$data[1]['photos'];
				} else {
					$return[] = URL."products-images/".$data[0]['photos'];
				}
			} else {
				$return[] = URL."products-images/product1.jpg";
				$return[] = URL."products-images/product1.jpg";
			}
			return $return;
		}
		
		function getAllictures($id) {
			$photos = new photos;
			$data = $photos->sortAll("inventory", $id);
			if (count($data) > 0) {
				for ($i = 0; $i < count($data); $i++) {
					$return[] = URL."products-images/".$data[$i]['photos'];
				}
			} else {
				$return[] = URL."products-images/product1.jpg";
			}
			return $return;
		}
	}
?>