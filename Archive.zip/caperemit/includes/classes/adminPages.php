<?php
	class adminPages extends common {
		function nav() { ?>
			
     <!-- Navigation -->
        <nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">PayMack Administrator</a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav navbar-right">
				<li class="dropdown">
	        		<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-comments-o"></i><span class="badge">4</span></a>
	        		<ul class="dropdown-menu">
						<li class="dropdown-menu-header">
							<strong>Messages</strong>
							<div class="progress thin">
							  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
							    <span class="sr-only">40% Complete (success)</span>
							  </div>
							</div>
						</li>
						<li class="avatar">
							<a href="#">
								<img src="images/1.png" alt=""/>
								<div>New message</div>
								<small>1 minute ago</small>
								<span class="label label-info">NEW</span>
							</a>
						</li>
						<li class="avatar">
							<a href="#">
								<img src="images/2.png" alt=""/>
								<div>New message</div>
								<small>1 minute ago</small>
								<span class="label label-info">NEW</span>
							</a>
						</li>
						<li class="avatar">
							<a href="#">
								<img src="images/3.png" alt=""/>
								<div>New message</div>
								<small>1 minute ago</small>
							</a>
						</li>
						<li class="avatar">
							<a href="#">
								<img src="images/4.png" alt=""/>
								<div>New message</div>
								<small>1 minute ago</small>
							</a>
						</li>
						<li class="avatar">
							<a href="#">
								<img src="images/5.png" alt=""/>
								<div>New message</div>
								<small>1 minute ago</small>
							</a>
						</li>
						<li class="avatar">
							<a href="#">
								<img src="images/pic1.png" alt=""/>
								<div>New message</div>
								<small>1 minute ago</small>
							</a>
						</li>
						<li class="dropdown-menu-footer text-center">
							<a href="#">View all messages</a>
						</li>	
	        		</ul>
	      		</li>
			    <li class="dropdown">
	        		<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown"><img src="images/1.png"></a>
	        		<ul class="dropdown-menu">
						<li class="dropdown-menu-header text-center">
							<strong>Settings</strong>
						</li>
						<li class="m_2"><a href="#"><i class="fa fa-user"></i> Profile</a></li>
						<li class="m_2"><a href="<?php echo URLAdmin; ?>settings"><i class="fa fa-wrench"></i> Settings</a></li>
						<li class="m_2"><a href="<?php echo URLAdmin; ?>visitorLog"><i class="fa fa-usd"></i> Visitors Log <span class="label label-default">42</span></a></li>
						<li class="m_2"><a href="<?php echo URLAdmin; ?>systemLog"><i class="fa fa-file"></i> System Log <span class="label label-primary">42</span></a></li>
						<li class="divider"></li>
						<li class="m_2"><a href="<?php echo URLAdmin; ?>login?logout"><i class="fa fa-lock"></i> Logout</a></li>	
	        		</ul>
	      		</li>
			</ul>
			<!--<form class="navbar-form navbar-right">
              <input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}">
            </form>-->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw nav_icon"></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Transactions<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="transactions?today">Today</a></li>
                                <li><a href="transactions?yesterday">Yesterday</a></li>
                                <li><a href="transactions?week">This Week</a></li>
                                <li><a href="transactions?month">Thiss Month</a></li>
                                <li><a href="transactions?lastMonth">Last Month</a></li>
                                <li><a href="transactions?year">This Year</a></li>
                                <li><a href="transactions">All Transactions</a></li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li><a href="customers"><i class="fa fa-indent nav_icon"></i>Customers</a></li>
                        <li>
                            <a href="#"><i class="fa fa-envelope nav_icon"></i>Mailbox<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="inbox.html">Inbox</a></li>
                                <li><a href="compose.html">Compose email</a></li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="settings"><i class="fa fa-flask nav_icon"></i>Settings<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="settings">Default Values</a></li>
                                <li><a href="settings.bank">Banks</a></li>
                            </ul>
                        </li>
                         <li><a href="#"><i class="fa fa-check-square-o nav_icon"></i>Administrators<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="administrators?new">Add New Administrators</a></li>
                                <li><a href="administrators">List All</a></li>
                                <li><a href="administrators.right">Manage User Rights</a></li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
		<?php }
		
		function mainHeader() { ?>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>      
            <link href="<?php echo URLAdmin; ?>css/bootstrap.min.css" rel='stylesheet' type='text/css' />
            <link href="<?php echo URLAdmin; ?>css/style.css" rel='stylesheet' type='text/css' />
            <link href="<?php echo URLAdmin; ?>css/lines.css" rel='stylesheet' type='text/css' />
            <link href="<?php echo URLAdmin; ?>css/font-awesome.css" rel="stylesheet"> 
            <script src="<?php echo URLAdmin; ?>js/jquery.min.js"></script>
            <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
            <link href="<?php echo URLAdmin; ?>css/custom.css" rel="stylesheet">
            <script src="<?php echo URLAdmin; ?>js/metisMenu.min.js"></script>
            <script src="<?php echo URLAdmin; ?>js/custom.js"></script>
            <script src="<?php echo URLAdmin; ?>js/d3.v3.js"></script>
            <script src="<?php echo URLAdmin; ?>js/rickshaw.js"></script>
            <link href="<?php echo URL; ?>css/daterangepicker/daterangepicker.css" rel="stylesheet"/>
            <link href="<?php echo URL; ?>css/datatables/dataTables.bootstrap.min.css" rel="stylesheet"/>
			<script src="<?php echo URL; ?>js/daterangepicker/moment.min.js"></script> 
            <script src="<?php echo URL; ?>js/daterangepicker/daterangepicker.js"></script> 
            <script src="<?php echo URL; ?>js/datatables/jquery.dataTables.min.js"></script> 
            <script src="<?php echo URL; ?>js/datatables/dataTables.bootstrap.min.js"></script> 
		<?php }
	}
?>