<?php
	class recipient_money extends common {
		function add($array) {
			$user = $this->mysql_prep($array['user']);
			$bank = $this->mysql_prep($array['bank']);
			$account_number = $this->mysql_prep($array['account_number']);
			$account_name = $this->mysql_prep($array['account_name']);
			$phone = $this->mysql_prep($array['phoneNumber']);
			$email = $this->mysql_prep($array['email']);
			$ref = $this->mysql_prep($array['ref']);
			if ($ref != "") {
				$firstpart = "`ref`, ";
				$secondPArt = "'".$ref."', ";
			} else {
				$firstpart = "";
				$secondPArt = "";
			}
			$create_time = time();
						
			$sql = mysql_query("INSERT INTO `recipient_money` (".$firstpart."`user`,`bank`, `account_number`, `account_name`,`phone`,`email`,`create_time`) VALUES (".$secondPArt."'".$user."','".$bank."','".$account_number."','".$account_name."','".$phone."','".$email."','".$create_time."') ON DUPLICATE KEY UPDATE `bank` = '".$bank."', `account_number` = '".$account_number."', `account_name` = '".$account_name."', `email` = '".$email."', `phone` = '".$phone."'") or die (mysql_error());
			
			if ($sql) {
				$id = mysql_insert_id();
				return $id;
			} else {
				return false;
			}
			
		}
		
		function delete($id) {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("UPDATE `recipient_money` SET `deleted` = 1 WHERE ref = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "Deleted Album '".$id."' created on ".date('l jS \of F Y h:i:s A', $data['create_time']);
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function listAll() {
			$sql = mysql_query("SELECT * FROM `recipient_money` ORDER BY `account_name` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['user'] = $row['user'];
					$result[$count]['bank'] = $row['bank'];
					$result[$count]['account_name'] = $row['account_name'];
					$result[$count]['account_number'] = $row['account_number'];
					$result[$count]['phone'] = $row['phone'];
					$result[$count]['email'] = $row['email'];
					$result[$count]['create_time'] = $row['create_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function sortAll($tag, $id) {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("SELECT * FROM `recipient_money` WHERE `".$tag."`  = '".$id."' AND `deleted` = 0 ORDER BY `account_name` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['user'] = $row['user'];
					$result[$count]['bank'] = $row['bank'];
					$result[$count]['account_name'] = $row['account_name'];
					$result[$count]['account_number'] = $row['account_number'];
					$result[$count]['phone'] = $row['phone'];
					$result[$count]['email'] = $row['email'];
					$result[$count]['create_time'] = $row['create_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function getOne($id, $tag='ref') {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("SELECT * FROM `recipient_money` WHERE `".$tag."` = '".$id."' ORDER BY `ref` ASC LIMIT 1") or die (mysql_error());
			
			if ($sql) {
				
				$row = mysql_fetch_array($sql);
				if ($row > 0) {
					$result = array();
					$result['ref'] = $row['ref'];
					$result['user'] = $row['user'];
					$result['bank'] = $row['bank'];
					$result['account_number'] = $row['account_number'];
					$result['account_name'] = $row['account_name'];
					$result['phone'] = $row['phone'];
					$result['email'] = $row['email'];
					$result['deleted'] = $row['deleted'];
					$result['create_time'] = $row['create_time'];
				}
				
				return $this->out_prep($result);
			}
		}
                
		function getOneField($id, $tag="ref", $ref="account_number") {
			$data = $this->getOne($id, $tag);
			return $data[$ref];
		}
	}
?>