<?php
	class pages extends common {
		function headerFiles() { ?>
<link rel="shortcut icon" href="<?php echo URL; ?>favicon.ico" type="image/x-icon" />
<link href="<?php echo URL; ?>css/bootstrap/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo URL; ?>css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo URL; ?>css/icheck/minimal/blue.css" rel="stylesheet">
<link href="<?php echo URL; ?>css/icheck/minimal/grey.css" type="text/css" rel="stylesheet">
<link href="<?php echo URL; ?>css/icheck/minimal/white.css" type="text/css" rel="stylesheet">
<link href="<?php echo URL; ?>css/daterangepicker/daterangepicker.css" rel="stylesheet"/>
<link href="<?php echo URL; ?>css/select2/select2.css" rel="stylesheet"/>
<link href="<?php echo URL; ?>css/jPushMenu.css" rel="stylesheet"/>
<link href="<?php echo URL; ?>css/datatables/dataTables.bootstrap.min.css" rel="stylesheet"/>
<!--<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>

  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>
<![endif]-->
		<?php }
		
		function topMenu($login=false) { ?>
<!--Mobile right sidebar menu-->
<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right">
<?php if (isset($_SESSION['users']['ref'])) { ?>
	<a href="<?php echo URL; ?>about-us">About Us</a>
	<a href="<?php echo URL; ?>profile">My Account</a>
	<a href="<?php echo URL; ?>sendMoney">Send Money</a>
    <a href="<?php echo URL; ?>send-mobile-airtime">Send Mobile Airtime</a>
	<a href="<?php echo URL; ?>pay-bills">Pay Bills</a>
	<a href="<?php echo URL; ?>myPayments">My Payments</a>
    <a href="<?php echo URL; ?>profile">My Profile</a>
	<a href="<?php echo URL; ?>myRecipientList">My Recipients</a>
	<a href="<?php echo URL; ?>invite-friends">Invite Friends</a>
    <a href="<?php echo URL; ?>changePassword">Change Password</a>
	<a href="<?php echo URL; ?>?login?logout">Log Out</a>
<?php } else {
	if ($login == true) { ?>
	<a href="<?php echo URL; ?>login?redirect=<?php echo $login; ?>">Log In</a>
	<a href="<?php echo URL; ?>register?redirect=<?php echo $login; ?>">Sign Up</a>
    <?php } else { ?>
	<a href="#" data-toggle="modal" data-target="#myModal">Log In</a>
	<a href="#" data-toggle="modal" data-target="#myModal2">Sign Up</a>
    <?php } ?>
	<a href="about-us">About Us</a>
<?php } ?>
</nav>
<!--/Mobile right sidebar menu-->

<div id="main">
  <!--header-->
  <div class="main-header navbar-fixed-top">
    <div class="container text-black">
      <div class="row"> 
        
        <div class="pull-left">
          <h1><a href="<?php echo URL; ?>"><img src="<?php echo URL; ?>images/logo.png" width="210" /></a></h1>
        </div>
        <nav class="main-nav pull-right">
          <ul class="">
            <li><a href="<?php echo URL; ?>">HOME</a></li>
            <li><a href="about-us">ABOUT US</a></li>
			<?php if (isset($_SESSION['users']['ref'])) { ?>
            <li><a href="profile">MY ACCOUNT</a></li>
            <li><a href="<?php echo URL; ?>login?logout" class="btn-login" rel="popover" data-placement="top"  data-trigger="hover" id="login_pop_link">LOG OUT</a></li>
            <?php } else {
				if ($login == true) { ?>
            <li><a href="<?php echo URL; ?>login?redirect=<?php echo $login; ?>" class="btn-login">LOG IN</a></li>
            <li><a href="<?php echo URL; ?>register?redirect=<?php echo $login; ?>" class="btn-red">SIGN UP</a></li>
            <?php } else { ?>
            <li><a href="#" data-toggle="modal" data-target="#myModal" class="btn-login">LOG IN</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal2" class="btn-red">SIGN UP</a></li>
            <?php }
			}?>
          </ul>
        </nav>
        <a class="toggle-menu menu-right push-body jPushMenuBtn" href="#"><i class="glyphicon glyphicon-menu-hamburger"></i></a>
      </div>
    </div>
  </div>
  <!--/header--> 
		<?php }
		
		function topMenuSession() { ?>
<!--Mobile right sidebar menu-->
<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right">
	<a href="<?php echo URL; ?>about-us">About Us</a>
	<a href="<?php echo URL; ?>profile">My Account</a>
	<a href="<?php echo URL; ?>sendMoney">Send Money</a>
    <a href="<?php echo URL; ?>send-mobile-airtime">Send Mobile Airtime</a>
	<a href="<?php echo URL; ?>pay-bills">Pay Bills</a>
	<a href="<?php echo URL; ?>my-payments">My Payments</a>
    <a href="<?php echo URL; ?>profile">My Profile</a>
	<a href="<?php echo URL; ?>myRecipientList">My Recipients</a>
	<a href="<?php echo URL; ?>invite-friends">Invite Friends</a>
    <a href="<?php echo URL; ?>changePassword">Change Password</a>
	<a href="<?php echo URL; ?>login?logout">Log Out</a>
</nav>
<!--/Mobile right sidebar menu-->

<div id="main"> 
  <!--header-->
  <div class="main-header navbar-fixed-top">
    <div class="container text-black">
      <div class="row"> 
        <!--lago-->
        <div class="pull-left">
          <h1><a href="<?php echo URL; ?>"><img src="<?php echo URL; ?>images/logo.png" width="210" /></a></h1>
        </div>
        <!--/lago--> 
        
        <!--navber-->
        <nav class="main-nav pull-right">
          <ul class="">
            <li><a href="<?php echo URL; ?>">HOME</a></li>
            <li><a href="about-us">ABOUT US</a></li>
            <li class="active"><a href="profile">MY ACCOUNT</a></li>
            <li><a href="<?php echo URL; ?>login?logout" class="btn-login" rel="popover" data-placement="top"  data-trigger="hover" id="login_pop_link">LOG OUT</a></li>
          </ul>
        </nav>
        <a class="toggle-menu menu-right push-body jPushMenuBtn" href="#"><i class="glyphicon glyphicon-menu-hamburger"></i></a>
        <!--/navber--> 
      </div>
    </div>
  </div>
  <!--/header--> 
		<?php }
		
		function homeFooter() { ?>
			
  <!--Footer-->
  <footer id="footer-con">
    <div class="gray-box">
      <div class="container">
        <div class="footer-img">
          <div class="row margin-top20">
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3 footer-box">
              <h5>OUR COMPANY</h5>
              <ul class="padding-left0">
                <li><a href="about-us">About  Us</a></li>
                <li><a href="news">News</a></li>
                <li><a href="careers">Careers</a></li>
                <li><a href="affiliates-partners">Affiliates & Partners</a></li>
              </ul>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3 footer-box">
              <h5>HELP & SUPPORT</h5>
              <ul class="padding-left0">
                <li><a href="how-it-works">How it Works</a></li>
                <li><a href="faq">FAQs</a></li>
                <li><a href="security">Security</a></li>
                <li><a href="contact-us">Contact Support</a></li>
              </ul>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3 footer-box">
              <h5>CONTACT US</h5>
              <ul class="padding-left0">
                <li><a href="contact-us">Contact Us</a></li>
                <li><a href="#">UK: +44 (0) 1438 759 067</a></li>
              </ul>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3 footer-box">
              <h5>FOLLOW US</h5>
              <ul class="follow-panel padding-left0">
                <li class="twitter"><a href="#"><img src="images/twitter.png"></a></li>
                <li class="facebook"><a href="#"><img src="images/facebook2.png"></a></li>
                <li class="google-plus"><a href="#"><img src="images/Google-Plus-icon.png"></a></li>
                <li class="in-plus"><a href="#"><img src="images/in.png"></a></li>
              </ul>
            </div>
          </div>
          <p class="fotter-text">© <?php echo date("Y"); ?> PayMack (UK) Limited. All Rights Reserved <a href="terms-conditions" class="text-conditions">Terms & Conditions </a> <a href="privacy-policy" class="text-conditions">Privacy policy</a> <a href="cookie-policy" class="text-conditions">Cookie policy.</a></p>
          <p class="text-center font-size12 margin-top20">PayMack is registered by the Financial Conduct Authority (FCA) in the United Kingdom under the Payment Service Regulations 2009 as a <br>
            Small Payment Institution with reference <span style="color:#09F; text-decoration:underline">724684</span>. We are also registered by Her Majesty's Revenue and Customs as a money service business with certificate number 12845190.</p>
          <p class="text-center font-size12 margin-top20"><a href="https://register.fca.org.uk/ShPo_FirmDetailsPage?id=001b0000025QGTDAA4" target="_blank">FCA certificate number (724684)</a>.</p>
        </div>
      </div>
    </div>
  </footer>
  <!--/Footer--> 

</div>
<!--Model Forgotten your password-->  
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap/bootstrap.min.js"></script> 
<script src="js/icheck/jquery.icheck.min.js"></script> 
<script src="js/select2/select2.full.min.js"></script> 
<script src="js/daterangepicker/moment.min.js"></script> 
<script src="js/daterangepicker/daterangepicker.js"></script> 
<script src="js/datatables/jquery.dataTables.min.js"></script> 
<script src="js/datatables/dataTables.bootstrap.min.js"></script> 
<script src="js/scripts/home.js"></script>
<script src="js/jPushMenu.js"></script>
		<?php }
	}
?>