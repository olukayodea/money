<?php
	class transactions extends common {
		function create() {
			$trax_id = $this->confirmUnique($this->createUnique());
			$amount = $this->mysql_prep($_SESSION['tempPayment']['amount']*$_SESSION['tempPayment']['xchange']);
			$currency = "NG";
			$tx_amount = $this->mysql_prep($_SESSION['tempPayment']['amount']);
			$tx_currency = $this->mysql_prep($_SESSION['tempPayment']['send_currency']);
			$user = $this->mysql_prep($_SESSION['tempPayment']['user']);
			$data = base64_encode(json_encode($_SESSION['tempPayment']));
			$recipient = $this->mysql_prep($_SESSION['tempPayment']['recipient']);
			$type = "sendMoney";
			$create_time = $modify_time = time();
			
			$sql = mysql_query("INSERT INTO `transactions` (`trax_id`,`amount`,`currency`,`tx_amount`,`tx_currency`,`data`,`user`, `recipient`,`type`,`create_time`, `modify_time`) VALUES ('".$trax_id."','".$amount."','".$currency."','".$tx_amount."','".$tx_currency."','".$data."','".$user."','".$recipient."','".$type."','".$create_time."','".$modify_time."')") or die (mysql_error());
			
			if ($sql) {
				$id = mysql_insert_id();
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "users";
				$logArray['owner_id'] = $_SESSION['users']['ref'];
				$logArray['desc'] = "created transaction ID ".$trax_id;
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return $id;
			} else {
				return false;
			}
		}		
		
		function createUnique() {
			$num = date("ymd").rand(11111, 99999);
			return $num;
		}
		
		function confirmUnique($key) {
			$key = $this->mysql_prep($key);
			$sql = mysql_query("SELECT `ref` FROM transactions WHERE `trax_id` = '".$key."'") or die (mysql_error()."sch");
			if (mysql_num_rows($sql) == 0) {
				return $key;
			} else {
				return $this->confirmUnique($this->createUnique());
			}
		}
		
		
		function updateOne($tag, $value, $id) {
			$id = $this->mysql_prep($id);
			$value = $this->mysql_prep($value);
			
			$sql = mysql_query("UPDATE transactions SET `".$tag."` = '".$value."', `modify_time` = '".time()."' WHERE ref = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "system";
				$logArray['owner_id'] = 0;
				$logArray['desc'] = "modified field ".$tag." as ".$value." for object";
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function listAll() {
			$sql = mysql_query("SELECT * FROM `transactions` ORDER BY `amount` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['trax_id'] = $row['trax_id'];
					$result[$count]['currency'] = $row['currency'];
					$result[$count]['amount'] = $row['amount'];
					$result[$count]['tx_amount'] = $row['tx_amount'];
					$result[$count]['tx_currency'] = $row['tx_currency'];
					$result[$count]['data'] = $row['data'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['delivery_status'] = $row['delivery_status'];
					$result[$count]['user'] = $row['user'];
					$result[$count]['recipient'] = $row['recipient'];
					$result[$count]['type'] = $row['type'];
					$result[$count]['create_time'] = $row['create_time'];
					$result[$count]['modify_time'] = $row['modify_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function sortAll($tag, $id) {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("SELECT * FROM `transactions` WHERE `".$tag."`  = '".$id."' ORDER BY `modify_time` DESC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['trax_id'] = $row['trax_id'];
					$result[$count]['currency'] = $row['currency'];
					$result[$count]['amount'] = $row['amount'];
					$result[$count]['tx_amount'] = $row['tx_amount'];
					$result[$count]['tx_currency'] = $row['tx_currency'];
					$result[$count]['data'] = $row['data'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['delivery_status'] = $row['delivery_status'];
					$result[$count]['user'] = $row['user'];
					$result[$count]['recipient'] = $row['recipient'];
					$result[$count]['type'] = $row['type'];
					$result[$count]['create_time'] = $row['create_time'];
					$result[$count]['modify_time'] = $row['modify_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function getRange($tag, $from, $to) {
			$tag = $this->mysql_prep($tag);
			$from = $this->mysql_prep($from);
			$to = $this->mysql_prep($to);
			$sql = mysql_query("SELECT * FROM `transactions` WHERE `".$tag."` BETWEEN  ".$from." AND ".$to." ORDER BY `modify_time` DESC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['trax_id'] = $row['trax_id'];
					$result[$count]['currency'] = $row['currency'];
					$result[$count]['amount'] = $row['amount'];
					$result[$count]['tx_amount'] = $row['tx_amount'];
					$result[$count]['tx_currency'] = $row['tx_currency'];
					$result[$count]['data'] = $row['data'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['delivery_status'] = $row['delivery_status'];
					$result[$count]['user'] = $row['user'];
					$result[$count]['recipient'] = $row['recipient'];
					$result[$count]['type'] = $row['type'];
					$result[$count]['create_time'] = $row['create_time'];
					$result[$count]['modify_time'] = $row['modify_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function getTotal($from=0, $to=0) {
			$from = $this->mysql_prep($from);
			$to = $this->mysql_prep($to);
			if ($from > 0) {
				$sql = mysql_query("SELECT SUM(`amount`) FROM `transactions` WHERE `modify_time` BETWEEN  ".$from." AND ".$to) or die (mysql_error());
			} else {
				$sql = mysql_query("SELECT SUM(`amount`) FROM `transactions`") or die (mysql_error());
			}
			
			if ($sql) {
				$row = mysql_fetch_array($sql);
				return $row[0];
			}
		}
		
		function countAl() {
			$sql = mysql_query("SELECT COUNT(*) FROM transactions") or die (mysql_error());
			if ($sql) {				
				$row = mysql_fetch_array($sql);
				return $row[0];
			}
		}
		
		function getOne($id, $tag='ref') {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("SELECT * FROM `transactions` WHERE `".$tag."` = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				
				$row = mysql_fetch_array($sql);
				if ($row > 0) {
					$result['ref'] = $row['ref'];
					$result['trax_id'] = $row['trax_id'];
					$result['currency'] = $row['currency'];
					$result['amount'] = $row['amount'];
					$result['tx_amount'] = $row['tx_amount'];
					$result['tx_currency'] = $row['tx_currency'];
					$result['data'] = $row['data'];
					$result['status'] = $row['status'];
					$result['delivery_status'] = $row['delivery_status'];
					$result['user'] = $row['user'];
					$result['recipient'] = $row['recipient'];
					$result['type'] = $row['type'];
					$result['create_time'] = $row['create_time'];
					$result['modify_time'] = $row['modify_time'];
				}
				
				return $this->out_prep($result);
			}
		}
                
		function getOneField($id, $tag="ref", $ref="delivery_status") {
			$data = $this->getOne($id, $tag);
			return $data[$ref];
		}
		
		function orderNotification($id) {
			$users = new users;
			$data = $this->getOne($id);
			$userData = $users->listOne($data['user']);
			
			$client = $userData['last_name']." ".$userData['other_names']." <".$userData['email'].">";
			$subjectToClient = "Cape Remit: Transfer Notification # ".$data['trax_id'];
			
			$contact = "PayMack <".replyMail.">";
				
			$fields = 'subject='.urlencode($subjectToClient).
				'&id='.urlencode($id);
			
			$mailUrl = URL."includes/emails/paymentNotification.php?".$fields;
			$messageToClient = $this->curl_file_get_contents($mailUrl);
			
			$mail['from'] = $contact;
			$mail['to'] = $client;
			$mail['subject'] = $subjectToClient;
			$mail['body'] = $messageToClient;
			
			$alerts = new alerts;
			$alerts->sendEmail($mail);
		}
	}
?>