<?php
	class cart extends common {
		function add($array) {
			if (isset($_SESSION['users']['id'])) {
				$inventory = $this->mysql_prep($array['inventory']);
				$qty = $this->mysql_prep($array['qty']);
				$unit_price = $this->mysql_prep($array['unit_price']);
				$total_price = $this->mysql_prep($array['total_price']);
				$otherParameter = $this->mysql_prep($array['otherParameter']);
				$user = $_SESSION['users']['id'];
				$createTime = $modifyTime = time();
				
				$sql = mysql_query("INSERT INTO `cart` (`inventory`, `qty`, `unit_price`, `total_price`, `otherParameter`, `user`, `createTime`, `modifyTime`) VALUES ('".$inventory."','".$qty."','".$unit_price."','".$total_price."','".$otherParameter."','".$user."', '".$createTime."', '".$modifyTime."')") or die (mysql_error());
			} else {
				$array['createTime'] = $createTime;
				$array['modifyTime'] = $modifyTime;
				$_SESSION['cart'][] = $array;
			}
			
			return true;
		}
		
		function removeOne($id) {
			if (isset($_SESSION['users']['id'])) {
				$id = $this->mysql_prep($id);
				$sql = mysql_query("DELETE FROM `cart` WHERE ref = '".$id."'") or die (mysql_error());
			} else {
				unset($_SESSION['cart'][$id]);
			}
			
			return true;
		}
		
		function removeAll() {
			if (isset($_SESSION['users']['id'])) {
				$id = $this->mysql_prep($id);
				$sql = mysql_query("DELETE FROM `cart` WHERE `user` = '".$_SESSION['users']['id']."'") or die (mysql_error());
			} else {
				unset($_SESSION['cart']);
			}
			
			return true;
		}
		
		function sortAll($id, $tag, $tag2=false, $id2=false, $tag3=false, $id3=false) {
			$id = $this->mysql_prep($id);
			$id2 = $this->mysql_prep($id2);
			$id3 = $this->mysql_prep($id3);
			if ($tag2 != false) {
				$sqlTag = " AND `".$tag2."` = '".$id2."'";
			} else {
				$sqlTag = "";
			}
			if ($tag3 != false) {
				$sqlTag .= " AND `".$tag3."` = '".$id3."'";
			} else {
				$sqlTag .= "";
			}
			
			$sql = mysql_query("SELECT * FROM `cart` WHERE `".$tag."` = '".$id."'".$sqlTag) or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['inventory'] = $row['inventory'];
					$result[$count]['qty'] = $row['qty'];
					$result[$count]['unit_price'] = $row['unit_price'];
					$result[$count]['total_price'] = $row['total_price'];
					$result[$count]['otherParameter'] = $row['otherParameter'];
					$result[$count]['user'] = $row['user'];
					$result[$count]['createTime'] = $row['createTime'];
					$result[$count]['modifyTime'] = $row['modifyTime'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function getAll() {
			if (isset($_SESSION['users']['id'])) {
				$sql = mysql_query("SELECT * FROM `cart` WHERE `user` = '".$_SESSION['users']['id']."' ORDER BY `ref` DESC") or die (mysql_error());
				
				if ($sql) {
					$result = array();
					$count = 0;
					
					while ($row = mysql_fetch_array($sql)) {
						$result[$count]['ref'] = $row['ref'];
						$result[$count]['inventory'] = $row['inventory'];
						$result[$count]['qty'] = $row['qty'];
						$result[$count]['unit_price'] = $row['unit_price'];
						$result[$count]['total_price'] = $row['total_price'];
						$result[$count]['otherParameter'] = $row['otherParameter'];
						$result[$count]['user'] = $row['user'];
						$result[$count]['createTime'] = $row['createTime'];
						$result[$count]['modifyTime'] = $row['modifyTime'];
						$count++;
					}
					return $this->out_prep($result);
				}
			} else {
				return @array_reverse($_SESSION['cart']);
			}
		}
		
		function getOneCart($id) {
			if (isset($_SESSION['users']['id'])) {
				$id = $this->mysql_prep($id);
				$sql = mysql_query("SELECT * FROM `cart` WHERE `ref` = '".$id."' LIMIT 1") or die (mysql_error());
				
				if ($sql) {
					$result = array();
					
					if (mysql_num_rows($sql) == 1) {
						$row = mysql_fetch_array($sql);
						$result['ref'] = $row['ref'];
						$result['inventory'] = $row['inventory'];
						$result['qty'] = $row['qty'];
						$result['unit_price'] = $row['unit_price'];
						$result['total_price'] = $row['total_price'];
						$result['otherParameter'] = $row['otherParameter'];
						$result['user'] = $row['user'];
						$result['createTime'] = $row['createTime'];
						$result['modifyTime'] = $row['modifyTime'];
						
						return $this->out_prep($result);
					}
				}
			} else {
				return $_SESSION['cart'][$id];
			}
		}
		
		function getOne($id, $tag='ref') {
			$id = $this->mysql_prep($id);
			$transaction_type = $this->mysql_prep($transaction_type);
			$sql = mysql_query("SELECT * FROM `cart` WHERE `".$tag."` = '".$id."' ORDER BY `ref` unit_price LIMIT 1") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				
				if (mysql_num_rows($sql) == 1) {
					$row = mysql_fetch_array($sql);
					$result['ref'] = $row['ref'];
					$result['inventory'] = $row['inventory'];
					$result['qty'] = $row['qty'];
					$result['unit_price'] = $row['unit_price'];
					$result['total_price'] = $row['total_price'];
					$result['otherParameter'] = $row['otherParameter'];
					$result['user'] = $row['user'];
					$result['createTime'] = $row['createTime'];
					$result['modifyTime'] = $row['modifyTime'];
					
					return $this->out_prep($result);
				} else {
					return false;
				}
			}
		}
	}