<?php
	class categories extends common {
		function add($array) {
			$title = ucfirst(strtolower($this->mysql_prep($array['title'])));
			$parent_id = $this->getOneField($this->mysql_prep($array['cat']), "title", "ref");
			$status = $this->mysql_prep($array['status']);
			$album_art = $this->mysql_prep($array['album_art']);
			$create_time = $modify_time = time();
			$ref = $this->mysql_prep($array['ref']);
			
			if ($ref != "") {
				$firstpart = "`ref`, ";
				$secondPArt = "'".$ref."', ";
				$log = "Modified object ".$title;
			} else {
				$firstpart = "";
				$secondPArt = "";
				$log = "Created object ".$title;
			}
			
			$sql = mysql_query("INSERT INTO `categories` (".$firstpart."`title`, `parent_id`, `album_art`, `status`, `create_time`, `modify_time`) VALUES (".$secondPArt."'".$title."','".$parent_id."','".$album_art."','".$status."', '".$create_time."', '".$modify_time."') ON DUPLICATE KEY UPDATE `title` = '".$title."', `parent_id` = '".$parent_id."', `album_art` = '".$album_art."', `modify_time` = '".$modify_time."'") or die (mysql_error());
			
			if ($sql) {
				$id = mysql_insert_id();
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = $tag;
				$logArray['create_date'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return $id;
			} else {
				return false;
			}
		}
		
		function remove($id) {
			$id = $this->mysql_prep($id);
			$modDate = time();
			$sql = mysql_query("SELECT `ref` FROM `users` WHERE `level` = '".$id."'") or die (mysql_error());
			if (mysql_num_rows($sql) == 0) {
				$sql = mysql_query("DELETE FROM `categories` WHERE ref = '".$id."'") or die (mysql_error());
				
				if ($sql) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
		
		function modifyOne($tag, $value, $id) {
			$value = $this->mysql_prep($value);
			$id = $this->mysql_prep($id);
			$modDate = time();
			$sql = mysql_query("UPDATE `categories` SET `".$tag."` = '".$value."', `modify_time` = '".$modDate."' WHERE ref = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				return true;
			} else {
				return false;
			}
		}
		
		function listAll() {
			$sql = mysql_query("SELECT * FROM `categories` ORDER BY `title` DESC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['title'] = $row['title'];
					$result[$count]['parent_id'] = $row['parent_id'];
					$result[$count]['album_art'] = $row['album_art'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['create_time'] = $row['create_time'];
					$result[$count]['modify_time'] = $row['modify_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function sortAll($id, $tag, $tag2=false, $id2=false, $tag3=false, $id3=false) {
			$id = $this->mysql_prep($id);
			$id2 = $this->mysql_prep($id2);
			$id3 = $this->mysql_prep($id3);
			if ($tag2 != false) {
				$sqlTag = " AND `".$tag2."` = '".$id2."'";
			} else {
				$sqlTag = "";
			}
			if ($tag3 != false) {
				$sqlTag .= " AND `".$tag3."` = '".$id3."'";
			} else {
				$sqlTag .= "";
			}
			
			$sql = mysql_query("SELECT * FROM `categories` WHERE `".$tag."` = '".$id."'".$sqlTag." ORDER BY `title` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['title'] = $row['title'];
					$result[$count]['parent_id'] = $row['parent_id'];
					$result[$count]['album_art'] = $row['album_art'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['create_time'] = $row['create_time'];
					$result[$count]['modify_time'] = $row['modify_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function getOne($id, $tag='ref') {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("SELECT * FROM `categories` WHERE `".$tag."` = '".$id."' ORDER BY `ref` DESC LIMIT 1") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				
				if (mysql_num_rows($sql) == 1) {
					$row = mysql_fetch_array($sql);
					$result['ref'] = $row['ref'];
					$result['title'] = $row['title'];
					$result['parent_id'] = $row['parent_id'];
					$result['album_art'] = $row['album_art'];
					$result['status'] = $row['status'];
					$result['create_time'] = $row['create_time'];
					$result['modify_time'] = $row['modify_time'];
					
					return $this->out_prep($result);
				} else {
					return false;
				}
			}
		}
		
		function getOneField($id, $tag="ref", $ref="title") {
			$data = $this->getOne($id, $tag);
			return $data[$ref];
		}
		
		function gettree($id) {
			$ids = $this->sortAll($id, "parent_id");
			$result = "";
			if (count($ids) > 0) {
				$result .= "<ul>";
				for ($i = 0; $i < count($ids); $i++) {
					$result .= "	<li><a href='#'>".$ids[$i]['title']."</a>";
					$result .= $this->gettree($ids[$i]['ref']);
				}
				$result .= "</li>";
				$result .= "</ul>";
			}
			return $result;
		}
		
		
		function showLink($id) {
			$list = $this->listLink($id);
			$link = '<li class="home"> <a title="Go to Home Page" href="'.URL.'">Home</a><span>&mdash;&rsaquo;</span></li>';
			for ($i = (count($list) - 1); $i >= 0; $i--) {
				$link .= '<li';
				if ($i == 0) {
					$link .= ' class="category13"';
				}
				$link .= '><a href="'.$this->seo($list[$i]['ref'], "category").'">'.$list[$i]['title'].'<span>&mdash;&rsaquo;</span></li> ';
			}
			
			return $link;
			?>
		<?php }
		
		function listLink($id) {
			$count = 0;
			$loop = true;
			$one = $this->getOne($id);
			$result[$count]['ref'] = $one['ref'];
			$result[$count]['title'] = $one['title'];
			$id = $one['parent_id'];
			while ($id > 0) {
				$count++;
				
				$data = $this->getOne($id);
				if ($id > 0) {
					$result[$count]['ref'] = $id;
					$result[$count]['title'] = $data['title'];
				}
				$id = $data['parent_id'];
			}
			$count++;
			return $result;
		}
		
		function linkListListDef($id) {
			$result = $id.",";
			$result .= $this->listLinkList($id);
			return trim($result, ",");
		}
		
		function listLinkList($id, $count = 0) {
			$ids = $this->sortAll($id, "parent_id");
			if (count($ids) > 0) {
				for ($i = 0; $i < count($ids); $i++) {
					$result .= $ids[$i]['ref'].",";
					$count++;
					$result .= $this->listLinkList($ids[$i]['ref'], $count);
				}
			}
			return $result;
		}
	}
?>