<?php
	class bank extends common {
		function add($array) {
			$bank_code = $this->mysql_prep($array['bank_code']);
			$bank_name = $this->mysql_prep($array['bank_name']);
			$ref = $this->mysql_prep($array['ref']);
			if ($ref != "") {
				$firstpart = "`ref`, ";
				$secondPArt = "'".$ref."', ";
			} else {
				$firstpart = "";
				$secondPArt = "";
			}
			$create_time = time();
			$sql = mysql_query("INSERT INTO `bank` (".$firstpart."`bank_code`, `bank_name`,`create_time`) VALUES (".$secondPArt."'".$bank_code."','".$bank_name."','".$create_time."') ON DUPLICATE KEY UPDATE `bank_code` = '".$bank_code."', `bank_name` = '".$bank_name."'") or die (mysql_error());
			
			if ($sql) {
				$id = mysql_insert_id();
				return $id;
			} else {
				return false;
			}
			
		}
		
		function delete($id) {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("DELETE FROM bank WHERE ref = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "Deleted Album '".$id."' created on ".date('l jS \of F Y h:i:s A', $data['create_time']);
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function listAll() {
			$sql = mysql_query("SELECT * FROM `bank` ORDER BY `bank_name` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['bank_code'] = $row['bank_code'];
					$result[$count]['bank_name'] = $row['bank_name'];
					$result[$count]['create_time'] = $row['create_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function sortAll($tag, $id) {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("SELECT * FROM `bank` WHERE `".$tag."`  = '".$id."' ORDER BY `bank_name` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['bank_code'] = $row['bank_code'];
					$result[$count]['bank_name'] = $row['bank_name'];
					$result[$count]['create_time'] = $row['create_time'];
					$count++;
				}
				return $this->out_prep($result);
			}
		}
		
		function getOne($id, $tag='ref') {
			$id = $this->mysql_prep($id);
			$sql = mysql_query("SELECT * FROM `bank` WHERE `".$tag."` = '".$id."' ORDER BY `ref` ASC LIMIT 1") or die (mysql_error());
			
			if ($sql) {
				
				$row = mysql_fetch_array($sql);
				if ($row > 0) {
					$result = array();
					$result['ref'] = $row['ref'];
					$result['bank_code'] = $row['bank_code'];
					$result['bank_name'] = $row['bank_name'];
					$result['create_time'] = $row['create_time'];
				}
				
				return $this->out_prep($result);
			}
		}
                
		function getOneField($id, $tag="ref", $ref="bank_name") {
			$data = $this->getOne($id, $tag);
			return $data[$ref];
		}
	}
?>