<?php
	class inventory_property extends common {
		function add($array) {
			$title = $this->mysql_prep($array['title']);
			$label = $this->mysql_prep($array['label']);
			$data_type = $this->mysql_prep($array['data_type']);
			$category_value = $this->mysql_prep($array['category_value']);
			$ref = $this->mysql_prep($array['ref']);
			
			if ($ref != "") {
				$firstpart = "`id`, ";
				$secondPArt = "'".$ref."', ";
				$log = "Modified object ".$title;
			} else {
				$firstpart = "";
				$secondPArt = "";
				$log = "Created object ".$title;
			}
			$create_date = $last_modified = time();
			$sql = mysql_query("INSERT INTO item_properties (".$firstpart."`title`,`label`, `data_type`, `category_value`, `create_date`, `last_modified`) VALUES (".$secondPArt."'".$title."','".$label."', '".$data_type."', '".$category_value."', '".$create_date."', '".$last_modified."') ON DUPLICATE KEY UPDATE `title` = '".$title."', `label` = '".$label."', `data_type` = '".$data_type."', `category_value` = '".$category_value."', `last_modified` = '".$last_modified."'") or die (mysql_error());
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "users";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = $log;
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return mysql_insert_id();
			} else {
				return false;
			}
		}
		
		function mupdateOne($tag, $value, $id) {
			$id = $this->mysql_prep($id);
			$value = $this->mysql_prep($value);

			$sql = mysql_query("UPDATE item_properties SET `".$tag."` = '".$value."', `modify_time` = '".time()."' WHERE ref = '".$id."'") or die (mysql_error());

			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "users";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "modified field ".$tag." as ".$value." for object";
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function remove($id) {
			$inventory = new inventory;
			$photos = new photos;
			$id = $this->mysql_prep($id);
			
			$sql = mysql_query("DELETE FROM item_properties WHERE id = '".$id."'") or die (mysql_error());
			if ($sql) {
				return true;
			} else {
				return false;
			}
		}
		
		function listAll($order = 'title') {

			$sql = mysql_query("SELECT * FROM item_properties ORDER BY '".$order."'") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['id'] = $row['id'];
					$result[$count]['title'] = $row['title'];
					$result[$count]['label'] = $row['label'];
					$result[$count]['data_type'] = $row['data_type'];
					$result[$count]['category_value'] = $row['category_value'];
					$result[$count]['create_date'] = $row['create_date'];
					$result[$count]['last_modified'] = $row['last_modified'];
					$count++;
				}
				return $result;
			} else {
				return false;
			}
		}
		
		function sortByType($value) {
			$sql = mysql_query("SELECT * FROM item_properties WHERE `data_type` = '".$value."'	 ORDER BY title ASC, RAND()") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['id'] = $row['id'];
					$result[$count]['title'] = $row['title'];
					$result[$count]['label'] = $row['label'];
					$result[$count]['category_value'] = $row['category_value'];
					$result[$count]['data_type'] = $row['data_type'];
					$result[$count]['create_date'] = $row['create_date'];
					$result[$count]['last_modified'] = $row['last_modified'];
					$count++;
				}
				return $result;
			} else {
				return false;
			}
		}
		
		function listMultiple($value, $tag="id") {
			$sql = mysql_query("SELECT * FROM item_properties WHERE `".$tag."` IN (".$value.")	 ORDER BY title ASC, RAND()") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['id'] = $row['id'];
					$result[$count]['title'] = $row['title'];
					$result[$count]['label'] = $row['label'];
					$result[$count]['category_value'] = $row['category_value'];
					$result[$count]['data_type'] = $row['data_type'];
					$result[$count]['create_date'] = $row['create_date'];
					$result[$count]['last_modified'] = $row['last_modified'];
					$count++;
				}
				return $result;
			} else {
				return false;
			}
		}
		
		function getOne($id) {
			$sql = mysql_query("SELECT * FROM item_properties WHERE id = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				
				$row = mysql_fetch_array($sql);
				$result['id'] = $row['id'];
				$result['title'] = $row['title'];
				$result['label'] = $row['label'];
				$result['data_type'] = $row['data_type'];
				$result['category_value'] = $row['category_value'];
				$result['create_date'] = $row['create_date'];
				$result['last_modified'] = $row['last_modified'];
				
				return $result;
			} else {
				return false;
			}
		}
		
		function getOneField($id, $tag="id", $ref="title") {
			$data = $this->getOne($id, $tag);
			return $data[$ref];
		}
		
		function buildList($id) {
			$inventory = new inventory;
			$inventoryData = $inventory->getOne($id);
			if (trim($inventoryData['properties'], ",") != "") {
				$data = $this->listMultiple($inventoryData['properties']);
				
				$result = "<p>";
				for ($i = 0; $i < count($data); $i++) {
					switch ($data[$i]['data_type']) {
						case "Text";
							$result .= "
							<label for=\"form_data".$i."\">".$data[$i]['label']."</label>
							<br><input type=\"text\" name=\"".$data[$i]['label']."\" id=\"form_data".$i."\" value=\"\" title=\"".$data[$i]['label']."\" class=\"dynamic-text\"><br><br>";
							break;
						case "Drop Down";
							$listData = $this->listToArray($data[$i]['category_value']);
							$result .= "
							<label for=\"form_data".$i."\">".$data[$i]['label']."</label>
							<br>
							<select name=\"".$data[$i]['label']."'\" id=\"form_data".$i."\" class=\"dynamic-text\">";
							for ($j = 0; $j < count($listData); $j++) {
								$result .=  "<option value=\"".trim($listData[$j])."\">".trim($listData[$j])."</option>";
							}
							$result .= "</select>
							<br><br>";
							break;
						case "Radio Button";
							$listData = $this->listToArray($data[$i]['category_value']);
							$result .= "
							<label for=\"form_data".$i."\">".$data[$i]['label']."</label><br>";
							for ($j = 0; $j < count($listData); $j++) {
							$result .=  "<label><input type=\"radio\" class=\"dynamic-text\" name=\"".$data[$i]['label']."\" id=\"form_data".$i."\"  value=\"".trim($listData[$j])."\">&nbsp;&nbsp;&nbsp;".trim($listData[$j])."&nbsp;&nbsp;</label>";
							}
							$result .= "<br><br>";
							break;
					}
				}
				$result .= "</p>";
				
				return $result;
			}
		}
		
		function listToArray($lis) {
			$lis = trim($lis, ",");
			
			$data = explode(",", $lis);
			return $data;
		}
	}
?>