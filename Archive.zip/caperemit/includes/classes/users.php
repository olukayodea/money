<?php
	class users extends common {
		function activate($password) {
			$ref = $_SESSION['users']['ref'];
			$password = $this->mysql_prep($password);
			$array = array();
			$array['ref'] = $ref;
			$array['password'] = $password;
			$modify_time = time();
			$change = self::updatePassword($array);
			
			if ($change){
				$sql = mysql_query("UPDATE `users` SET status = 'ACTIVE', modify_time = '".$modify_time."' WHERE ref = '".$ref."'") or die (mysql_error());
				if ($sql) {
					$_SESSION['status'] = "ACTIVE";
					//add to log
					$logArray['object'] = get_class($this);
					$logArray['object_id'] = $ref;
					$logArray['owner'] = "users";
					$logArray['owner_id'] = $_SESSION['users']['id'];
					$logArray['desc'] = "activated user account";
					$logArray['create_time'] = time();
					$system_log = new system_log;
					$system_log->create($logArray);
					return true;
				} else {
					return false;
				}
			}
		}
		
		function deactivate($ref) {
			$ref = $this->mysql_prep($ref);
			$modify_time = time();
			
			$sql = mysql_query("UPDATE `users` SET status = 'INACTIVE', modify_time = '".$modify_time."' WHERE ref = '".$ref."'") or die (mysql_error());
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $ref;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "deactvated user account";
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function delete($ref) {
			$ref = $this->mysql_prep($ref);
			$modify_time = time();
			
			$sql = mysql_query("UPDATE `users` SET status = 'DELETED', modify_time = '".$modify_time."' WHERE ref = '".$ref."'") or die (mysql_error());
			if ($sql) {
				
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $ref;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "deleted user account";
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function login($array) {
			$email = $this->mysql_prep($array['email']);
			$password = $this->mysql_prep($array['password']);
			$sql = mysql_query("SELECT * FROM `users` WHERE email = '".$email."' AND password = '".sha1($password)."' AND `status` != 'DELETED'") or die (mysql_error());
			
			if (mysql_num_rows($sql) == 1) {
				$row = mysql_fetch_array($sql);
				$status = $row['status'];
				setcookie("login_status", $status, null, "/");
				$_SESSION['users']['status'] = $row['status'];
				$_SESSION['users']['email'] = $row['email'];
				$_SESSION['users']['last_name'] = $row['last_name'];
				$_SESSION['users']['other_names'] = $row['other_names'];
				$_SESSION['users']['phone'] = $row['phone'];
				$_SESSION['users']['date_time'] = $row['date_time'];
				$_SESSION['users']['subscription'] = $row['subscription'];
				$_SESSION['users']['ref'] = $row['ref'];
				$_SESSION['users']['modify_time'] = $row['modify_time'];
				$_SESSION['users']['loginTime'] = time();
				$_SESSION['users']['sessionTime'] = time() + 900;
				if ($status == "NEW") {
					return 1;
				} else if ($status == "INACTIVE") {
					return 3;
				} else {
					return 2;
				}
			} else {
				return 0;
			}
		}
		
		function logout() {
			$logout_time = date("Y-m-d H:i:s");
			$session_id = session_id();
			$_SESSION = array();
			if(isset($_COOKIE[session_name()])) {
				setcookie(session_name(), '', time()-42000, '/');
				setcookie("login_status", '', time()-42000, '/');
			}
			session_destroy();
		}
		
		function checkAccount($email) {
			$email = $this->mysql_prep($email);
			$sql = mysql_query("SELECT `ref` FROM `users` WHERE email = '".$email."'") or die (mysql_error());
			$result = mysql_num_rows($sql);
			
			return $result;
		}
		
		function create($array) {
			$password = $this->mysql_prep($array['password']);
			$last_name = ucfirst(strtolower($this->mysql_prep($array['last_name'])));
			$other_names = ucfirst(strtolower($this->mysql_prep($array['other_names'])));
			$email = $this->mysql_prep($array['email']);
			$phone = $this->mysql_prep($array['phone2'])."-".$this->mysql_prep($array['phone']);
			$date_time = time();
			$modify_time = time();
			
			if ($this->checkAccount($email) == 0) {
				
				$sql = mysql_query("INSERT INTO `users` (password, last_name, other_names, email, phone, `status`, date_time, modify_time) VALUES ('".sha1($password)."', '".$last_name."', '".$other_names."', '".$email."', '".$phone."', 'NEW', '".$date_time."', '".$modify_time."')") or die (mysql_error());
				
				$ref = mysql_insert_id();
				
				$client = $last_name." ".$other_names." <".$email.">";
				$subjectToClient = "PayMack User Account";
				
				$contact = "PayMack<".replyMail.">";
					
				$fields = 'subject='.urlencode($subjectToClient).
					'&last_name='.urlencode($last_name).
					'&other_names='.urlencode($other_names).
					'&email='.urlencode($email).
					'&phone='.urlencode($phone).
					'&password='.urlencode($password);
				$mailUrl = URL."includes/emails/welcome.php?".$fields;
				$messageToClient = $this->curl_file_get_contents($mailUrl);
				
				$mail['from'] = $contact;
				$mail['to'] = $client;
				$mail['subject'] = $subjectToClient;
				$mail['body'] = $messageToClient;
				
				$alerts = new alerts;
				$alerts->sendEmail($mail);
				
				$loginArray = array();
				$loginArray['email'] = $email;
				$loginArray['password'] = $password;
				$login = $this->login($loginArray);
				
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $ref;
				$logArray['owner'] = "users";
				$logArray['owner_id'] = $ref;
				$logArray['desc'] = "activated user account";
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				
				return $ref;
			} else {
				return false;
			}
		}
		
		function modifyOne($tag, $value, $id) {
			$value = $this->mysql_prep($value);
			$id = $this->mysql_prep($id);
			$modDate = time();
			$sql = mysql_query("UPDATE `users` SET `".$tag."` = '".$value."', `modify_time` = '".$modDate."' WHERE ref = '".$id."'") or die (mysql_error());
			
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $id;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "modified".$tag." as ".$id;
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function update ($array) {
			$ref = $this->mysql_prep($array['ref']);
			$last_name = $this->mysql_prep($array['last_name']);
			$other_names = $this->mysql_prep($array['other_names']);
			$email = $this->mysql_prep($array['email']);
			$phone = $this->mysql_prep($array['phone']);
			$d_o_b = $this->mysql_prep($array['d_o_b']);
			$address_1 = $this->mysql_prep($array['address_1']);
			$address_2 = $this->mysql_prep($array['address_2']);
			$city = $this->mysql_prep($array['city']);
			$state = $this->mysql_prep($array['state']);
			$post_code = $this->mysql_prep($array['post_code']);
			$country = $this->mysql_prep($array['country']);
			$modify_time = time();
			
			$sql = mysql_query("UPDATE `users` SET `last_name` = '".$last_name."', `other_names` = '".$other_names."', `email` = '".$email."', `phone` = '".$phone."', `d_o_b` = '".$d_o_b."', `address_1` = '".$address_1."', `address_2` = '".$address_2."', `city` = '".$city."', `state` = '".$state."', `post_code` = '".$post_code."', `country` = '".$country."', `modify_time` = '".$modify_time."' WHERE `ref` = '".$ref."'") or die (mysql_error());
			
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $ref;
				$logArray['owner'] = "admin";
				$logArray['owner_id'] = $_SESSION['admin']['id'];
				$logArray['desc'] = "modified user account";
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function updatePassword($array) {
			$ref = $this->mysql_prep($array['ref']);
			$password = $this->mysql_prep(trim($array['password']));
			$modify_time = time();
			
			$sql = mysql_query("UPDATE `users` SET password = '".sha1($password)."', modify_time = '".$modify_time."' WHERE ref = '".$ref."'") or die (mysql_error());
			
			if ($sql) {
				//add to log
				$logArray['object'] = get_class($this);
				$logArray['object_id'] = $ref;
				$logArray['owner'] = "users";
				$logArray['owner_id'] = $_SESSION['users']['ref'];
				$logArray['desc'] = "updated user account password";
				$logArray['create_time'] = time();
				$system_log = new system_log;
				$system_log->create($logArray);
				return true;
			} else {
				return false;
			}
		}
		
		function listAll() {
			$sql = mysql_query("SELECT * FROM `users` WHERE status != 'DELETED' ORDER BY `last_name` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['last_name'] = $row['last_name'];
					$result[$count]['other_names'] = $row['other_names'];
					$result[$count]['email'] = $row['email'];
					$result[$count]['phone'] = $row['phone'];
					$result[$count]['d_o_b'] = $row['d_o_b'];
					$result[$count]['address_1'] = $row['address_1'];
					$result[$count]['address_2'] = $row['address_2'];
					$result[$count]['city'] = $row['city'];
					$result[$count]['state'] = $row['state'];
					$result[$count]['post_code'] = $row['post_code'];
					$result[$count]['country'] = $row['country'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['date_time'] = $row['date_time'];
					$result[$count]['modify_time'] = $row['modify_time'];
					$count++;
				}
				return $this->out_prep($result);
			} else {
				return false;
			}
		}
		
		function listRange($from, $to) {
			$from = $this->mysql_prep($from);
			$to = $this->mysql_prep($to);
			$sql = mysql_query("SELECT * FROM `users` WHERE status != 'DELETED' AND `date_time` BETWEEN '".$from."' AND '".$to."' ORDER BY `last_name` ASC") or die (mysql_error());
			
			if ($sql) {
				$result = array();
				$count = 0;
				
				while ($row = mysql_fetch_array($sql)) {
					$result[$count]['ref'] = $row['ref'];
					$result[$count]['last_name'] = $row['last_name'];
					$result[$count]['other_names'] = $row['other_names'];
					$result[$count]['email'] = $row['email'];
					$result[$count]['phone'] = $row['phone'];
					$result[$count]['d_o_b'] = $row['d_o_b'];
					$result[$count]['address_1'] = $row['address_1'];
					$result[$count]['address_2'] = $row['address_2'];
					$result[$count]['city'] = $row['city'];
					$result[$count]['state'] = $row['state'];
					$result[$count]['post_code'] = $row['post_code'];
					$result[$count]['country'] = $row['country'];
					$result[$count]['status'] = $row['status'];
					$result[$count]['date_time'] = $row['date_time'];
					$result[$count]['modify_time'] = $row['modify_time'];
					$count++;
				}
				return $this->out_prep($result);
			} else {
				return false;
			}
		}
		
		function countAl() {
			$sql = mysql_query("SELECT COUNT(*) FROM users WHERE status != 'DELETED'") or die (mysql_error());
			if ($sql) {				
				$row = mysql_fetch_array($sql);
				return $row[0];
			}
		}
		
		function listOne($ref, $tag='ref') {
			$ref = $this->mysql_prep($ref);
			$sql = mysql_query("SELECT * FROM `users` WHERE `".$tag."` = '".$ref."'") or die (mysql_error());
						
			if ($sql) {
				$result = array();
				
				$row = mysql_fetch_array($sql);
				$result['ref'] = $row['ref'];
				$result['last_name'] = $row['last_name'];
				$result['other_names'] = $row['other_names'];
				$result['password'] = $row['password'];
				$result['email'] = $row['email'];
				$result['phone'] = $row['phone'];
				$result['d_o_b'] = $row['d_o_b'];
				$result['address_1'] = $row['address_1'];
				$result['address_2'] = $row['address_2'];
				$result['city'] = $row['city'];
				$result['state'] = $row['state'];
				$result['post_code'] = $row['post_code'];
				$result['country'] = $row['country'];
				$result['status'] = $row['status'];
				$result['date_time'] = $row['date_time'];
				$result['modify_time'] = $row['modify_time'];
				
				return $this->out_prep($result);
			} else {
				return false;
			}
		}
		
		function getOneField($id, $tag="ref", $ref="title") {
			$data = $this->listOne($id, $tag);
			return $data[$ref];
		}
	}
?>