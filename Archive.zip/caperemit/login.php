<?php
	include_once("includes/functions.php");
	if ((isset($_REQUEST['redirect'])) && ($_REQUEST['redirect'] != "")) {
		$redirect = $_REQUEST['redirect'];
	} else {
		$redirect = "index";
	}
	
	$urlParam = $common->getParam($_SERVER['REQUEST_URI']);
	
	if (isset($_GET['logout'])) {
		$users->logout();
		header("location: ./");
	}
		
	if (isset($_REQUEST['msg'])) {
		$er = $_REQUEST['msg'];
	} else {
		$er = false;
	}
	
	$tagLink = $redirect."?".$urlParam;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Login</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body class="my-account">
<?php $pages->topMenu($redirect); ?>
  
  <!--Body Part-->
  <div class="gray-bg">
    <div class="container">
      <div class="row margin-top10"> 
        <!--REGISTRATION-->
        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" id="main-body">
          <div class="white-bg">
            <h2 class="header registration-box hidden-xs hidden-sm"><i class="glyphicons glyphicons-user"></i> LOGIN</h2>
            <p class="text-center font-size14">Welcome, Please enter your username and password to continue.</p>
            
        <?php if (isset($_REQUEST['done'])) { ?>
          <p class="text-center font-size14" style="color:#060">Action completed successfully</p>
        <?php } else if (isset($_REQUEST['done'])) { ?>
          <p class="text-center font-size14" style="color:#F00">An error occured, please try again</p>
        <?php } ?>
            <?php if ($er) { ?>
            <p class="text-center font-size14" style="color:#F00;" align="center"><?php echo $er; ?></p>
            <?php } ?>
            <p class="text-center font-size14" id="notificationDialogue" style="color:#F00; display:none" align="center"></p>
            <div class="form-horizontal">
              <div class="row margin-top30 choose-box">
                <div class="col-xs-12 margin-left20">
                  <div class="form-group">
                    <div class="col-xs-3 text-center">
                    <input name="redirect" id="redirect" type="hidden" value="<?php echo $tagLink; ?>">
                      <label for="email" class="control-label">Email</label>
                    </div>
                    <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                      <input type="email" name="email" id="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control">
                    </div>
                    <div class="pull-left margin-top10"> <span class="text-red">*</span> </div>
                  </div>
                  <div class="form-group margin-top24">
                    <div class="col-xs-3 text-center">
                      <label for="password" class="control-label">Password</label>
                    </div>
                    <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                      <input type="password" name="password" id="password" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
                    </div>
                    <div class="pull-left margin-top10"> <span class="text-red">*</span> </div>
                  </div>
                  <div class="row margin-top30">
                     <p class="continue-btn">
                      <a class="btn-sky" href="Javascript:void(0)" id="login_button" onClick="login()">LOGIN</a>
                     </p>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--/REGISTRATION--> 
        
        <!--Icon-Panel-->
        <div class="col-xs-4 col-sm-12 col-md-12 col-lg-12 hidden-xs hidden-sm" id="sidebar">
          <div class="white-bg padding-top15">
            <div class="padding-left-right15 clearfix">
              <div id="box-panel"> 
              	<a href="sendMoney" class="money-box"> <span class="glyphicons glyphicons-credit-card font-size45"></span><span class="margin-top15 all-icon-box">Send Money</span> </a> 
                <a href="send-mobile-airtime.php" class="send-mobile-box"> <span><img src="images/mobile-phone-icon.png" height="44"></span><span class="margin-top15 all-icon-box">Send  Mobile Airtime</span> </a> 
                <a href="pay-bills.php"class="pay-bills-box"> <span><img src="images/bill.png" width="37" height="auto"></span><span class="margin-top15 all-icon-box">Pay Bills</span> </a> 
                <a href="myPayments" class="payments-box"> <span class="glyphicons glyphicons-circle-arrow-right small-payments-text"></span><span class="margin-top15 all-icon-box">My Payments</span> </a> 
                <a href="profile" class="profile-box"> <span class="glyphicons glyphicons-user font-size45"></span><span class="margin-top15 all-icon-box">My Profile</span> </a> 
                <a href="myRecipientList"class="recipients-box"> <span class="glyphicons glyphicons-group small-payments-text"></span><span class="margin-top15 all-icon-box">My Recipients</span> </a> 
                <a href="invite-friends.php" class="invite-box"> <span class="glyphicons glyphicons-user-add small-payments-text"></span><span class="margin-top15 all-icon-box">Invite Friends</span> </a> 
                <a href="changePassword" class="password-box"> <span class="glyphicons glyphicons-lock"></span><span class="margin-top15 all-icon-box">Change Password</span> </a> 
             </div>
            </div>
          </div>
        </div>
        <!--/Icon-Panel--> 
      </div>
    </div>
  </div>
  
  <!--/Body Part--> 
  
  <?php $pages->homeFooter(); ?>
<script language="javascript" src="js/home.js"></script>
</body>
</html>