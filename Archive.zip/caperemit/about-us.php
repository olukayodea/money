<?php
	$redirect = "sendMoney";
	include_once("includes/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>About Us</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body>

<!--Model login-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Log in to your PayMack Account</span></div>
      </div>
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15">
        	<input name="redirect" id="redirect" type="hidden" value="<?php echo $redirect; ?>">
          <input type="email" name="email" id="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="password" id="password" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
         <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-green1" href="Javascript:void(0)" onClick="login()" id="login_button">LOG IN</a>
           </p>
         </div>
        <div class="forgotten-password"><a href="#" data-dismiss="modal" data-target="#myModal5" data-toggle="modal">Forgotten your password?</a> </div>
        <p class="text-center font-size14 margin-top20">Don’t have an Account? <a href="#" class="text-red" data-dismiss="modal" data-target="#myModal2" data-toggle="modal"><strong>Sign up</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model login-->

<!--Model singup-->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content  model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Create an Account with PayMack</span></div>
      </div>
		<input name="redirect" id="redirect2" type="hidden" value="<?php echo $redirect; ?>">
      <div class="modal-body form-horizontal">
        <div class="padding-left-right15" id="notificationDialogue2" style="color:#F00; display:none" align="center"></div>
        <!-- <div class="padding-left-right15">
          <input type="text" name="fullNames" id="fullNames" placeholder="Full Names" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Full Names'" class="form-control">
        </div> -->
        <div class="padding-left-right15 margin-top15">
          <input type="text" name="createEmail" id="createEmail" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control" onChange="checkEmail(this.value)">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="newPassword" id="newPassword" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" class="form-control">
        </div>
        <div class="padding-left-right15 margin-top15">
          <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Confirm Password'"  class="form-control">
        </div>
        <p class="text-center font-size11 margin-top15">By signing up, you are agreeing to PayMack’s <br>
          <a class="margin-right5" href="terms-conditions.php" target="_blank"><u>Terms and Conditions</u></a> and <a class="margin-left5" href="privacy-policy.php" target="_blank"><u>Privacy Policy</u></a></p>
        <!--<div class="text-center"> <a href="registration.html" class="btn btn-red btn-signup" type="button">SIGN UP</a> </div>-->
        <div class="row margin-top30">
           <p class="continue-btn">
             <a class="btn-red1" href="Javascript:void(0)" onClick="register()" id="register_button">SIGN UP</a>
           </p>
         </div>
        
        <p class="text-center font-size14 margin-top4">Already have an account? <a href="#" class="text-green" data-toggle="modal" data-target="#myModal" data-dismiss="modal"><strong>Log in</strong></a></p>
      </div>
    </div>
  </div>
</div>
<!--Model singup--> 

<!--Model Forgotten your password-->
<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content model-box">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <div class="padding-top15 font-size20"> <span class="text-sky">Reset Your PayMack Password</span></div>
         <p class="forgotten-text">Enter the email address you registered with and we will send <br>you an email with a link to reset your password </p>
      </div>
		<input name="redirect" id="redirect3" type="hidden" value="<?php echo $redirect; ?>">
        
        <div class="padding-left-right15" id="notificationDialogue3" style="color:#F00; display:none" align="center"></div>
        <div class="padding-left-right15" id="notificationDialogue4" style="color:#060; display:none" align="center"></div>
      <div class="modal-body form-horizontal modal-box">
        <div class="padding-left-right15">
          <input name="forgotPassword" id="forgotPassword" type="text" placeholder="Enter your email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your email address'" class="form-control">
        </div>
        <div class="send-email"> <a href="Javascript:void(0)" onClick="remeberPassword()" class="btn btn-green btn-login2" type="button">SEND EMAIL</a> </div>
      </div>
    </div>
  </div>
</div>
<!--Model send now--> 

<?php $pages->topMenu(); ?>

<!--Body Part-->
 <div class="main-container">
  <div class="container margin-bottom50">
    <div class="row margin-top10 margin-bottom20"> 
      <!--From-left-panel-->
      <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
        <div id="box-con" class="all-box-panel hidden-xs hidden-sm">
        <div class="red-box"><a href="about-us.php">About Us</a></div>
        <div class="gray-box-con sky-box-con"><a href="news.html">News</a></div>
        <div class="gray-box-con green-box-con"><a href="careers.php">Careers</a></div>
        <div class="gray-box-con yellow-box-con"><a href="affiliates-partners.html">Affiliates & Partners</a></div>
        </div>
      </div>
      <!--/From-left-panel--> 
      
      <!--ABOUT US-->
      <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
         <h2 class="border-panel"><strong>ABOUT US</strong></h2>
        <div class="row margin-top20">  
         <p class="text-con">"The secret of change is to focus all of your energy not on fighting the old, but on building the new" </p>
      	 </div>
         <div class="text-sky2 small-text-panel"><strong>Socrates;</strong> "Way of the Peaceful Warrior" by <br><strong>Dan Millman.</strong></div>
     	<div class="margin-top20">
          <p>PayMack was conceived out of a desperate desire for change in the money transfer industry. It has been developed as an entirely new remittance platform devoid of everything that is wrong with the traditional means of sending money abroad. Traditional means of money transfer are time-consuming, expensive and cumbersome; definitely not fit for this generation, and we are determined to change all that.</p>
          <p>PayMack enables people to send money online to their friends and family abroad, using a computer, tablet or smart phone. Our service is cheaper, faster and more convenient than the traditional alternatives.</p>	
          <p>You can send money using your debit and credit cards, very much in the same way you pay for goods on online shops, or you can send by bank transfer. Your recipient can receive money directly into their bank account or mobile wallet or they can choose to receive by mobile airtime or withdraw the funds at an ATM without using a card.</p>
          <p>We are constantly thinking of new ways to send and receive money across borders. We are committed to the introduction of innovative new technology ideas to the money transfer industry. We are focusing all our energy on building the new so we can eventually replace the old. While the old system decays and slowly dies around us, we are building the new using the ashes of the old as building blocks for the new.</p>
            <div class="from-text text-sky2"><strong>From the PayMack team.</strong></div>
              <span class="send-now-btn">
                <a class="btn-red2" href="#" data-toggle="modal" data-target="#myModal3">SEND MONEY NOW</a>
              </span>
           </div>
         </div>
      <!--/ABOUT US--> 
    </div>
   </div>
 </div>
<!--/Body Part--> 
    
  <?php $pages->homeFooter(); ?>
<script language="javascript" src="js/home.js"></script>
</body>
</html>