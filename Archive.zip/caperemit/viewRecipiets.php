<?php
	$redirect = "viewRecipiets";
	include_once("includes/functions.php");
	include_once("includes/session.php");
	
	if (isset($_REQUEST['id'])) {
		$id = $common->get_prep($_REQUEST['id']);
	} else {
		header("location: myPayments");
	}
	if (isset($_REQUEST['remove'])) {
		$del = $recipient_money->delete($id);
		
		if ($del) {
			header("location: myPayments?done");
		} else {
			header("location: myPayments?error=".urlencode("Cannot complete this action"));
		}
	}
	
	$data = $recipient_money->getOne($id);
	$list = $transactions->sortAll("recipient", $id);
	if ($data['deleted'] == 1) {
		header("location: myPayments?error=".urlencode("This recipient has been deleted"));
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>View Recipients</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body class="my-account">
<?php $pages->topMenuSession(); ?>
    
    <!--Body Part-->
    <div class="container">
     <div class="row margin-top10">
     <!--MY PROFILE-->
       <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" id="main-body">
         <div class="white-bg">
            <h2 class="header recipients-con hidden-xs hidden-sm"><i class="glyphicons glyphicons-group"></i> VIEW RECIPIENT</h2>
           <div class="row margin-left-right15">
             <div class="pull-left">
                <h5>Recipient's Details</h5>
             </div>
            <div class="pull-right">
              <a href="?remove&id=<?php echo $id; ?>" onClick="return confirm('do you really want to remove this recipient?\n\nRemoving this user will remove this account from your recipient list but previous transactions to this recipients will continue to be available')"><span class="glyphicon glyphicon-trash font-size18 margin-left15  delite-icon" aria-hidden="true"></span><p class="text-center font-size12">Delete <br>Recipient</p></a>
             </div>  
           </div>
             
             <div class="form-horizontal">
             <!--Personal Details-->
             <div class="form-group margin-top24">
                    <div class="col-xs-3 text-center">
                     Account Number
               </div>
                    <div class="col-xs-9 col-sm-6 col-md-6 col-lg-6">
                      <strong><?php echo $data['account_number']; ?></strong>
                    </div>
               </div>
                   <div class="form-group margin-top24">
                    <div class="col-xs-3 text-center">
                     Account Name
                     </div>
                    <div class="col-xs-9 col-sm-6 col-md-6 col-lg-6">
                      <strong><?php echo $data['account_name']; ?></strong>
                    </div>
                  </div>
                   <div class="form-group margin-top24">
                    <div class="col-xs-3 text-center">
                     Bank Name
                     </div>
                    <div class="col-xs-9 col-sm-6 col-md-6 col-lg-6">
                      <strong><?php echo $bank->getOneField($data['bank']); ?></strong>
                    </div>
                  </div>
                   <div class="form-group margin-top24">
                    <div class="col-xs-3 text-center">
                     Mobile Number
                     </div>
                    <div class="col-xs-9 col-sm-6 col-md-6 col-lg-6">
                      <strong><?php echo $data['phone']; ?></strong>
                    </div>
                  </div>
                   <div class="form-group margin-top24">
                    <div class="col-xs-3 text-center">
                     Email Address
                     </div>
                    <div class="col-xs-9 col-sm-6 col-md-6 col-lg-6">
                      <strong><?php echo $data['email']; ?></strong>
                    </div>
                  </div>
                  <div class="col-xs-10 col-sm-12 col-md-12 col-lg-12 margin-top30 continue-btn">
                      <a href="myRecipientList" class="btn-gray">Back</a>
                      <a href="addRecipient?edit=<?php echo $id; ?>" class="btn-sky1 margin-left18">Edit Recipient</a>
               </div>
           </div>
             <!--/Personal Details-->
                <p>&nbsp;</p>
             <div class="pull-left">
                <h5>Transaction Details</h5>
           </div>
                <p>&nbsp;</p>
           <p>&nbsp;</p>
                <table id="my-payments-tables" class="table view-recipients dataTable">
                  <thead>
                    <tr>
                      <th valign="middle" width="30" nowrap="" class="text-center" align="left" >TRANSACTION<br>
                      DATE</th>
                      <th valign="middle" width="30" nowrap="" class="text-center" align="left" >AMOUNT <br>
                        SENT</th>
                      <th valign="middle" width="30" nowrap="" class="text-center" align="center" >AMOUNT <br>
                        RECEIVED</th>
                      <th valign="middle" width="20" nowrap="" class="text-center" align="center" >TRANSACTION <br>
                        NUMBER</th>
                      <th valign="middle" width="30" nowrap="" class="text-center" align="center" >STATUS</th>
                      <th width="30" class="white">&nbsp;</th>
                    </tr>
                  </thead>
                  <tbody class="text-center">
                    <?php for ($i = 0; $i < count($list); $i++) { ?>
                    <tr>
                      <td ><?php echo date("Y/m/d", $list[$i]['modify_time']); ?></td>
                      <td><?php echo $common->selectcurrency($list[$i]['tx_currency']). " ".number_format($list[$i]['tx_amount'], 2); ?></td>
                      <td><?php echo $common->selectcurrency($list[$i]['currency']). " ".number_format($list[$i]['amount'], 2); ?></td>
                      <td><?php echo $list[$i]['trax_id']; ?></td>
                      <td><?php echo $list[$i]['status']; ?></td>
                      <td class="text-center view-bg"><a href="sendReciept?id=<?php echo $list[$i]['ref']; ?>&recipient=<?php echo $id; ?>">View <br>
                        Receipt</a></td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
         </div>
          </div>
     <!--/MY PROFILE-->
     
     <!--MY PROFILE-->
       <div class="col-xs-4 col-sm-12 col-md-12 col-lg-12 hidden-xs hidden-sm" id="sidebar">
        <div class="white-bg padding-top15">
          <div class="padding-left-right15 clearfix">
              <div class="sky-box">
              <div class="margin-top10 text-center font-size20"><strong>Hello</strong></div>
              <span class="glyphicons glyphicons-user font-size70"></span>
              <div class="margin-top10 text-center font-size20"><strong><?php echo $last_name." ".$other_names; ?></strong></div>
            </div>
               <div id="box-panel"> 
              	<a href="sendMoney" class="money-box"> <span class="glyphicons glyphicons-credit-card font-size45"></span><span class="margin-top15 all-icon-box">Send Money</span> </a> 
                <a href="send-mobile-airtime.php" class="send-mobile-box"> <span><img src="images/mobile-phone-icon.png" height="44"></span><span class="margin-top15 all-icon-box">Send  Mobile Airtime</span> </a> 
                <a href="pay-bills.php"class="pay-bills-box"> <span><img src="images/bill.png" width="37" height="auto"></span><span class="margin-top15 all-icon-box">Pay Bills</span> </a> 
                <a href="myPayments" class="payments-box"> <span class="glyphicons glyphicons-circle-arrow-right small-payments-text"></span><span class="margin-top15 all-icon-box">My Payments</span> </a> 
                <a href="profile" class="profile-box"> <span class="glyphicons glyphicons-user font-size45"></span><span class="margin-top15 all-icon-box">My Profile</span> </a> 
                <a href="myRecipientList"class="recipients-box active"> <span class="glyphicons glyphicons-group small-payments-text"></span><span class="margin-top15 all-icon-box">My Recipients</span> </a> 
                <a href="invite-friends.php" class="invite-box"> <span class="glyphicons glyphicons-user-add small-payments-text"></span><span class="margin-top15 all-icon-box">Invite Friends</span> </a> 
                <a href="changePassword" class="password-box"> <span class="glyphicons glyphicons-lock"></span><span class="margin-top15 all-icon-box">Change Password</span> </a> 
             </div>
          </div>
        </div>
      </div>
     <!--/Icon-Panel-->
     </div>
    </div>
    <!--/Body Part-->
  <?php $pages->homeFooter(); ?>
</body>
</html>