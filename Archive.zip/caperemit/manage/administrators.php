<?php
	$redirect = "administrators";
	include_once("../includes/functions.php");
	include_once("session.php");
	
	
	//administrator
	if (isset($_POST['addAdmin'])) {
		$add = $admin->create($_POST);
		if ($add) {
			header("location: ?done");
		} else {
			header("location: ?error");
		}
	} else if (isset($_POST['editButton'])) {
		$edit = $admin->update($_POST);
		if ($edit) {
			header("location: ?done");
		} else {
			header("location: ?error");
		}
	}
	
	if (isset($_GET['editAdmin'])) {
		$getData = $admin->listOne($common->get_prep($_GET['id']));
		
		$editID = $getData['id'];
		$editName = $getData['name'];
		$editEmail = $getData['email'];
		$editPhone = $getData['phone'];
		$editRead = $getData['read'];
		$editWrite = $getData['write'];
		$editModify = $getData['modify'];
		$eitAdminType = $getData['adminType'];
		$editPages = explode(",", $getData['pages']);
		$editAdmin = true;
				
	} else if (isset($_GET['deactivateAdmin'])) {
		$edit = $admin->deactivate($common->get_prep($_GET['id']));
		if ($edit) {
			header("location: ?done");
		} else {
			header("location: ?error");
		} 
	} else if (isset($_GET['deleteAdmin'])) {
		$edit = $admin->delete($common->get_prep($_GET['id']));
		if ($edit) {
			header("location: ?done");
		} else {
			header("location: ?error");
		}
	}
	
	if (isset($_REQUEST['active'])) {
		$listAdmin = $admin->sortList("status", "ACTIVE");
		$title = "All Active Customers";
	} else if (isset($_REQUEST['inactive'])) {
		$listAdmin = $admin->sortList("status", "INACTIVE");
		$title = "All In-active Customers";
	} else if (isset($_REQUEST['deleted'])) {
		$listAdmin = $admin->sortList("status", "DELETED");
		$title = "All Deleted Customers";
	} else {
		$listAdmin = $admin->listAll();
		$title = "All Administrators";
	}
	
	$listAdminType = $admin->listAdmintypes();
	
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Administrator Setup :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Administrator Manager</h3>
	<div class="bs-example4" data-example-id="simple-responsive-table">
    <?php if (isset($_GET['new'])) { ?>
    <h3>Add/Update Administrator</h3>
    <?php if (isset($_REQUEST['done'])) { ?>
       <div class="alert alert-success" role="alert">
        <strong>Well done!</strong> Actions performed successfully
       </div>
    <?php } ?>
    <?php if (isset($_GET['error'])) { ?>
       <div class="alert alert-danger" role="alert">
        <strong>Oh snap!</strong> An error occured, please try again. <?php echo $common->get_prep($_GET['error']); ?>
       </div>
    <?php } ?>
    <div class="table-responsive">
    <form class="form-horizontal" method="post" action="" onsubmit="return vlidate()">
        <div class="form-group">
            <label for="name" class="col-sm-2 control-label">Name <em>*</em><small>Enter Administrtor Full names</small></label>
            <div class="col-sm-8">
                <input type="text" name="name" id="name" value="<?php echo $editName; ?>" required class="form-control1">
            </div>
        </div>
        <div class="form-group">
            <label for="email" class="col-sm-2 control-label">Email <em>*</em><small>Enter email of administrator, the username and password will be sent to this address</small></label>
            <div class="col-sm-8">
                <input type="email" name="email" id="email" value="<?php echo $editEmail; ?>" required class="form-control1">
            </div>
        </div>
        <div class="form-group">
            <label for="phone" class="col-sm-2 control-label">Phone <em>*</em><small>Administrator phone number</small></label>
            <div class="col-sm-8">
                <input name="phone" type="number" id="phone" required value="<?php echo $editPhone; ?>" class="form-control1">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label" for="adminType">User Right <em>*</em><small>Administrator access right</small></label>
            <div class="col-sm-8">
                <select name="adminType" class="form-control1" id="adminType">
                <?php for ($j = 0; $j < count($listAdminType); $j++) { ?>
                <option value="<?php echo $listAdminType[$j]['id']; ?>"<?php if ($eitAdminType == $listAdminType[$j]['id']) { ?> selected<?php } ?>><?php echo $listAdminType[$j]['title']; ?></option>
                <?php } ?>
                </select>
            </div>
        </div>
      <div class="panel-footer">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
                <?php if ($editAdmin === true) { ?>
                        <input type="hidden" name="id" value="<?php echo $editID; ?>">
                        <button class="btn-default btn" name="editButton" id="editButton" type="submit" data-icon-primary="ui-icon-circle-check">Save Changes</button>
                	<button class="btn-default btn" name="button2" id="button" type="button" onClick="location='<?php echo $redirect; ?>'" data-icon-primary="ui-icon-circle-check">Cancel</button>
                <?php } else { ?>
                	<button class="btn-default btn" name="addAdmin" id="addAdmin" type="submit" data-icon-primary="ui-icon-circle-check">Add</button>
                <?php } ?>
			</div>
		</div>
	 </div>
    </form>
    </div>
    <?php } else { ?>
    <h3>List All</h3>
    <div class="table-responsive">
      <table class="table table-bordered" id="example">
        <thead>
          <tr>
            <th>&nbsp;</th>
            <th>Username</th>
            <th>Full Names</th>
            <th>E-Mail</th>
            <th>Creation Date</th>
            <th>Modified Last</th>
            <th>Status</th>
            <th>&nbsp;</th>
          </tr>
        </thead>
        <tbody>
          <?php for ($i = 0; $i < count($listAdmin); $i++) {
$sn++; ?>
          <tr>
            <td><?php echo $sn; ?></td>
            <td><?php echo $listAdmin[$i]['username']; ?></td>
            <td><?php echo $listAdmin[$i]['name']; ?></td>
            <td><?php echo $listAdmin[$i]['email']; ?></td>
            <td><?php echo $common->get_time_stamp($listAdmin[$i]['date_time']); ?></td>
            <td><?php echo $common->get_time_stamp($listAdmin[$i]['timeStamp']); ?></td>
            <td><?php echo $listAdmin[$i]['status']; ?></td>
            <td><a href="?new&add&editAdmin&id=<?php echo $listAdmin[$i]['id']; ?>&tab=<?php echo $Tab4; ?>">edit</a>
              <?php if ($listAdmin[$i]['id'] != $ref) { ?>
              | <a href="?deactivateAdmin&id=<?php echo $listAdmin[$i]['id']; ?>">de-activate</a> | <a href="?deleteAdmin&id=<?php echo $listAdmin[$i]['id']; ?>" onClick="return confirm('this action will remove this user. are you sure you want to continue ?')">delete</a>
              <?php } ?></td>
          </tr>
          <?php }
unset($i); 
unset($sn); ?>
        </tbody>
      </table>
    </div><!-- /.table-responsive -->
    <?php } ?>
  </div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript">
	function setSelectedIndex(s, valsearch) {
		// Loop through all the items in drop down list
		for (i = 0; i< s.options.length; i++) { 
			if (s.options[i].value == valsearch) {
			// Item is found. Set its property and exit
			s.options[i].selected = true;
			break;
			}
		}
		return;
	}
	
	function setMultiSelectedIndex(s, data) {
		var main = data.split(",");
		// Loop through all the items in drop down list
		for (var j = 0; j < main.length; j++) {
			var opt = main[j];
			for (i = 0; i< s.options.length; i++) { 
				if (s.options[i].value == opt) {
				// Item is found. Set its property and exit
				s.options[i].selected = true;
				break;
				}
			}
		}
		return;
	}
	$(document).ready(function() {
		setSelectedIndex(document.getElementById("mainPage"),"<?php echo $editMain; ?>");
		setSelectedIndex(document.getElementById("level"),"<?php echo $editLevel; ?>");
		setMultiSelectedIndex(document.getElementById("pages"),"<?php echo $getData['pages']; ?>");
	});
</script>
</body>
</html>
