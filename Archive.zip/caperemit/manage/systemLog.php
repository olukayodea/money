<?php
	$redirect = "visitorLog";
	include_once("../includes/functions.php");
	include_once("session.php");
	$list = $system_log->listAll();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>System Log :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>System Log</h3>
  	 <div class="bs-example4" data-example-id="simple-responsive-table">
  	   <div class="table-responsive">
      <table class="table dataTable">
        <thead>
          <tr>
            <th>#</th>
            <th>Object</th>
            <th>Object ID</th>
            <th>Owner</th>
            <th>Owner ID</th>
            <th>Description</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
        <?php for ($i = 0; $i < count($list); $i++) {
			$sn++ ?>
          <tr>
            <th scope="row"><?php echo $sn; ?></th>
            <td><?php echo $list[$i]['object']; ?></td>
            <td><?php echo $list[$i]['object_id']; ?></td>
            <td><?php echo $list[$i]['owner']; ?></td>
            <td><?php echo $list[$i]['owner_id']; ?></td>
            <td><?php echo $list[$i]['desc']; ?></td>
            <td><?php echo $common->get_time_stamp($list[$i]['create_time']); ?></td>
          </tr>
        <?php } ?>
        </tbody>
      </table>
    </div><!-- /.table-responsive -->
    <div class="table-responsive"></div><!-- /.table-responsive -->
</div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>