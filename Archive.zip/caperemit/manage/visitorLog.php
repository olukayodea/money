<?php
	$redirect = "visitorLog";
	include_once("../includes/functions.php");
	include_once("session.php");
	$from = time()-(60*60*24*60);
	$list = $visitorData->getUnigue($from, time());
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Visitors Log :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Visitors' Log</h3>
  	 <div class="bs-example4" data-example-id="simple-responsive-table">
  	   <div class="table-responsive">
      <table class="table dataTable">
        <thead>
          <tr>
            <th>#</th>
            <th>Address</th>
            <th>City</th>
            <th>Region</th>
            <th>Country</th>
            <th>Continent</th>
            <th>Latitude</th>
            <th>Longitude</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
        <?php for ($i = 0; $i < count($list); $i++) {
			$sn++ ?>
          <tr>
            <th scope="row"><?php echo $sn; ?></th>
            <td><?php echo $list[$i]['address']; ?></td>
            <td><?php echo $list[$i]['loc_city']; ?></td>
            <td><?php echo $list[$i]['loc_region']; ?></td>
            <td><?php echo $list[$i]['loc_country']; ?></td>
            <td><?php echo $list[$i]['loc_continent']; ?></td>
            <td><?php echo $list[$i]['loc_lat']; ?></td>
            <td><?php echo $list[$i]['loc_long']; ?></td>
            <td><?php echo $common->get_time_stamp($list[$i]['time_stamp']); ?></td>
          </tr>
        <?php } ?>
        </tbody>
      </table>
    </div><!-- /.table-responsive -->
    <div class="table-responsive"></div><!-- /.table-responsive -->
</div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>