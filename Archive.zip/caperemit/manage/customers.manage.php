<?php
	$redirect = "customers.manage";
	include_once("../includes/functions.php");
	include_once("session.php");
	
	if ((isset($_REQUEST['id'])) && ($_REQUEST['id'] != "")) {
		$id = $common->get_prep($_GET['id']);
	} else {
		header("location: customers?error=".urlencode("select a profile first"));
	}
	
	//administrator
	if (isset($_GET['del'])) {
		$add = $users->delete($id);
		if ($add) {
			header("location: customers?done");
		} else {
			header("location: ?error&id=".$id);
		}
	}
	if (isset($_POST['editButton'])) {
		$add = $users->update($_POST);
		if ($add) {
			header("location: customers?done");
		} else {
			header("location: ?error&id=".$id);
		}
	}
	
	$data = $users->listOne($id);
	
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Administrator Setup :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Customers</h3>
	<div class="bs-example4" data-example-id="simple-responsive-table">
    <h3>View/Update Customers</h3>
    <?php if (isset($_REQUEST['done'])) { ?>
       <div class="alert alert-success" role="alert">
        <strong>Well done!</strong> Actions performed successfully
       </div>
    <?php } ?>
    <?php if (isset($_GET['error'])) { ?>
       <div class="alert alert-danger" role="alert">
        <strong>Oh snap!</strong> An error occured, please try again. <?php echo $common->get_prep($_GET['error']); ?>
       </div>
    <?php } ?>
    <div class="table-responsive">
    <form class="form-horizontal" method="post" action="">
        <div class="form-group">
            <label for="last_name" class="col-sm-2 control-label">Last Name <em>*</em></label>
            <div class="col-sm-8"><span id="sprytextfield1">
              <input type="text" class="form-control1" id="last_name" name="last_name" value="<?php echo $data['last_name']; ?>" required>
              <span class="textfieldRequiredMsg">A value is required.</span></span>
              <input type="hidden" name="ref" id="ref" value="<?php echo $data['ref']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="other_names" class="col-sm-2 control-label">Other Names <em>*</em></label>
            <div class="col-sm-8"><span id="sprytextfield2">
              <input type="text" id="other_names" name="other_names" value="<?php echo $data['other_names']; ?>" class="form-control1" required>
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
        <div class="form-group">
            <label for="email" class="col-sm-2 control-label">Email <em>*</em></label>
            <div class="col-sm-8"><span id="sprytextfield3">
              <input type="email" id="email" name="email" value="<?php echo trim($data['email']); ?>" readonly class="form-control1" required>
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
        <div class="form-group">
            <label for="phone" class="col-sm-2 control-label">Phone <em>*</em></label>
            <div class="col-sm-8"><span id="sprytextfield4">
              <input type="text" id="phone" name="phone" value="<?php echo $data['phone']; ?>" class="form-control1" required>
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
        <div class="form-group">
            <label for="d_o_b" class="col-sm-2 control-label">Date of Birth <em>*</em></label>
            <div class="col-sm-8"><span id="sprytextfield5">
              <input type="text" id="d_o_b" name="d_o_b" value="<?php echo $data['d_o_b']; ?>" class="form-control1 daterange" required>
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
        <div class="form-group">
            <label for="address_1" class="col-sm-2 control-label">Address Line  <em>*</em></label>
            <div class="col-sm-8"><span id="sprytextfield6">
              <input type="text" class="form-control1" id="address_1" name="address_1" value="<?php echo $data['address_1']; ?>" required>
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
        <div class="form-group">
            <label for="address_2" class="col-sm-2 control-label">Address Line 2</label>
            <div class="col-sm-8">
                <input type="text" class="form-control1" id="address_2" name="address_2" value="<?php echo $data['address_2']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="city" class="col-sm-2 control-label">City <em>*</em></label>
            <div class="col-sm-8"><span id="sprytextfield7">
              <input type="text" class="form-control1" id="city" name="city" value="<?php echo $data['city']; ?>" required>
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
        <div class="form-group">
            <label for="state" class="col-sm-2 control-label">State <em>*</em></label>
            <div class="col-sm-8"><span id="sprytextfield8">
              <input type="text" class="form-control1" id="state" name="state" value="<?php echo $data['state']; ?>" required>
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
        <div class="form-group">
            <label for="post_code" class="col-sm-2 control-label">Post Code <em>*</em></label>
            <div class="col-sm-8"><span id="sprytextfield9">
              <input type="text" class="form-control1" id="post_code" name="post_code" value="<?php echo $data['post_code']; ?>">
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
        <div class="form-group">
            <label for="country" class="col-sm-2 control-label">Country <em>*</em></label>
            <div class="col-sm-8">
                <select class="form-control1" id="country" name="country" style="width:100%" required>
                    <!--<option value="CA">Canada</option>-->
                    <option value="GB">United Kingdom</option>
                    <!--<option value="US">United States</option>-->
                </select>
            </div>
        </div>
      <div class="panel-footer">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
                <button class="btn-default btn" name="editButton" id="editButton" type="submit" data-icon-primary="ui-icon-circle-check">Save Changes</button>
                <button class="btn-default btn" name="button2" id="button" type="button" onClick="location='<?php echo $redirect; ?>'" data-icon-primary="ui-icon-circle-check">Back</button>
                <button class="btn-default btn" name="button2" id="button" type="button" onClick="ConfirmDelete()" data-icon-primary="ui-icon-circle-check">Delete Profile</button>
			</div>
		</div>
	 </div>
    </form>
    </div><!-- /.table-responsive -->
  </div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
</div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript">
function ConfirmDelete()
    {
      var x = confirm("Are you sure you want to delete?");
      if (x)
          window.location='<?php echo $redirect."?del&id=".$data['ref']; ?>';
      else
        return false;
    }

var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");
var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5");
var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6");
var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7");
var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8");
var sprytextfield9 = new Spry.Widget.ValidationTextField("sprytextfield9");
</script>
</body>
</html>
