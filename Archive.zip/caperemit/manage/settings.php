<?php
	include_once("../includes/functions.php");
	
	$redirect = "settings";
	include_once("session.php");
	//administrator
	
	if ((isset($_POST['addAdmin'])) || (isset($_POST['editButton']))) {
		$add = $settings->add($_POST);
		if ($add) {
			header("location: ?done");
		} else {
			header("location: ?error");
		}
	}
	
	$USD = $settings->getOne("US");
	$CAD = $settings->getOne("CA");
	$GBP = $settings->getOne("GB");
	$EURO = $settings->getOne("EURO");
	$CH1 = $settings->getOne("CH1");
	$CH2 = $settings->getOne("CH2");
	$CH3 = $settings->getOne("CH3");
	$CH4 = $settings->getOne("CH4");
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Settings :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Settings</h3>
	<div class="bs-example4" data-example-id="simple-responsive-table">
    <?php if (isset($_REQUEST['done'])) { ?>
       <div class="alert alert-success" role="alert">
        <strong>Well done!</strong> Actions performed successfully
       </div>
    <?php } ?>
    <?php if (isset($_GET['error'])) { ?>
       <div class="alert alert-danger" role="alert">
        <strong>Oh snap!</strong> An error occured, please try again. <?php echo $common->get_prep($_GET['error']); ?>
       </div>
    <?php } ?>
    <div class="table-responsive">
    <form class="form-horizontal" method="post" action="">
        <div class="form-group">
            <label for="CAD" class="col-sm-2 control-label">CAD <em>*</em><small>Amount 1 CAD will change for in NGN</small></label>
            <div class="col-sm-8">
                <input type="number" class="form-control1" name="CAD" id="CAD" value="<?php echo $CAD; ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="EURO" class="col-sm-2 control-label">EURO <em>*</em><small>Amount 1 EURO will change for in NGN</small></label>
            <div class="col-sm-8">
                <input type="number" class="form-control1" name="EURO" id="EURO" value="<?php echo $EURO; ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="GBP" class="col-sm-2 control-label">GBP <em>*</em><small>Amount 1 GBP will change for in NGN</small></label>
            <div class="col-sm-8">
                <input type="number" class="form-control1" name="GBP" id="GBP" value="<?php echo $GBP; ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="USD" class="col-sm-2 control-label">USD <em>*</em><small>Amount 1 USD will change for in NGN</small></label>
            <div class="col-sm-8">
                <input type="number" class="form-control1" name="USD" id="USD" value="<?php echo $USD; ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="USD" class="col-sm-2 control-label">Fixed Charge 1 <em>*</em><small>amount to be charged by PayMack for every transaction</small></label>
            <div class="col-sm-8">
                <input type="number" class="form-control1" name="CH1" id="CH1" value="<?php echo $CH1; ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="USD" class="col-sm-2 control-label">Fixed Charge 2 <em>*</em><small>amount to be charged by PayMack for every transaction</small></label>
            <div class="col-sm-8">
                <input type="number" class="form-control1" name="CH2" id="CH2" value="<?php echo $CH2; ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="USD" class="col-sm-2 control-label">Fixed Charge 3 <em>*</em><small>amount to be charged by PayMack for every transaction</small></label>
            <div class="col-sm-8">
                <input type="number" class="form-control1" name="CH3" id="CH3" value="<?php echo $CH3; ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="USD" class="col-sm-2 control-label">Fixed Charge 4 <em>*</em><small>amount to be charged by PayMack for every transaction</small></label>
            <div class="col-sm-8">
                <input type="number" class="form-control1" name="CH4" id="CH4" value="<?php echo $CH4; ?>" required>
            </div>
        </div>
      <div class="panel-footer">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
                <input type="hidden" name="id" value="<?php echo $editID; ?>">
                <button class="btn-default btn" name="editButton" id="editButton" type="submit" data-icon-primary="ui-icon-circle-check">Save Changes</button>
			</div>
		</div>
	 </div>
    </form>
    </div>
  </div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
</div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript">
	function setSelectedIndex(s, valsearch) {
		// Loop through all the items in drop down list
		for (i = 0; i< s.options.length; i++) { 
			if (s.options[i].value == valsearch) {
			// Item is found. Set its property and exit
			s.options[i].selected = true;
			break;
			}
		}
		return;
	}
	
	function setMultiSelectedIndex(s, data) {
		var main = data.split(",");
		// Loop through all the items in drop down list
		for (var j = 0; j < main.length; j++) {
			var opt = main[j];
			for (i = 0; i< s.options.length; i++) { 
				if (s.options[i].value == opt) {
				// Item is found. Set its property and exit
				s.options[i].selected = true;
				break;
				}
			}
		}
		return;
	}
	$(document).ready(function() {
		setSelectedIndex(document.getElementById("mainPage"),"<?php echo $editMain; ?>");
		setSelectedIndex(document.getElementById("level"),"<?php echo $editLevel; ?>");
		setMultiSelectedIndex(document.getElementById("pages"),"<?php echo $getData['pages']; ?>");
	});
</script>
</body>
</html>