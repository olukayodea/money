<?php
	include_once("../includes/functions.php");
	
	$redirect = "transactions.view";
	include_once("session.php");
	
	if ((isset($_REQUEST['id'])) && ($_REQUEST['id'] != "")) {
		$id = $common->get_prep($_GET['id']);
	} else {
		header("location: transactions?error=".urlencode("select a profile first"));
	}
	
	$data = $transactions->getOne($id);
	
	$raw = $common->unwrap($data['data']);
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Administrator Setup :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Transactions</h3>
	<div class="bs-example4" data-example-id="simple-responsive-table">
    <h3>Viewing #<?php echo $data['trax_id']; ?></h3>
    <?php if (isset($_REQUEST['done'])) { ?>
       <div class="alert alert-success" role="alert">
        <strong>Well done!</strong> Actions performed successfully
       </div>
    <?php } ?>
    <?php if (isset($_GET['error'])) { ?>
       <div class="alert alert-danger" role="alert">
        <strong>Oh snap!</strong> An error occured, please try again. <?php echo $common->get_prep($_GET['error']); ?>
       </div>
    <?php } ?>
    <table width="100%" border="0">
      <tr>
        <td width="25%">Transactin ID</td>
        <td><?php echo $data['trax_id']; ?></td>
      </tr>
      <tr bgcolor="#CCCCCC">
        <td width="25%">Sent Amount</td>
        <td><?php if ($data['tx_currency'] == "CA") {echo CAD; } else if ($data['tx_currency'] == "US") {echo USD; } else if ($data['tx_currency'] == "GB") { echo GBP; } else if ($data['tx_currency'] == "NG") { echo NGN; } echo number_format($data['tx_amount'], 2); ?></td>
      </tr>
      <?php if ($data['type'] == "sendMoney") { ?>
      <tr>
        <td width="25%">Fee</td>
        <td><?php if ($raw['send_currency'] == "CA") {echo CAD; } else if ($raw['send_currency'] == "US") {echo USD; } else if ($raw['send_currency'] == "GB") { echo GBP; } else if ($raw['send_currency'] == "NG") { echo NGN; } echo $raw['fee']; ?></td>
      </tr>
      <tr bgcolor="#CCCCCC">
        <td width="25%">Total</td>
        <td><?php if ($raw['send_currency'] == "CA") {echo CAD; } else if ($raw['send_currency'] == "US") {echo USD; } else if ($raw['send_currency'] == "GB") { echo GBP; } else if ($raw['send_currency'] == "NG") { echo NGN; } echo $raw['total']; ?></td>
      </tr>
      <tr>
        <td width="25%">Total Recieved</td>
        <td><?php if ($raw['send_currency'] == "CA") {echo CAD; } else if ($raw['send_currency'] == "US") {echo USD; } else if ($raw['send_currency'] == "GB") { echo GBP; } else if ($raw['send_currency'] == "NG") { echo NGN; } echo $raw['balance']; ?></td>
      </tr>
      <tr bgcolor="#CCCCCC">
        <td width="25%">Excahnge Rate</td>
        <td><?php echo NGN." ".$raw['xchange']; ?></td>
      </tr>
      <?php } ?>
      <tr>
        <td width="25%">Recieved Amount (Local)</td>
        <td><?php if ($datac['currency'] == "CA") {echo CAD; } else if ($data['currency'] == "US") {echo USD; } else if ($data['currency'] == "GB") { echo GBP; } else if ($data['currency'] == "NG") { echo NGN; } echo number_format($data['amount'], 2); ?></td>
      </tr>
      <tr bgcolor="#CCCCCC">
        <td width="25%">Status</td>
        <td><?php echo $data['status']; ?></td>
      </tr>
      <tr>
        <td width="25%">Delivery Status</td>
        <td><?php echo $data['delivery_status']; ?></td>
      </tr>
      <tr bgcolor="#CCCCCC">
        <td width="25%">User</td>
        <td><?php echo $users->getOneField($data['user'], "ref", "last_name")." ".$users->getOneField($data['user'], "ref", "other_names"); ?></td>
      </tr>
      <?php if ($data['type'] == "sendMoney") { ?>
      <tr>
        <td width="25%">Recipient</td>
        <td><?php echo $recipient_money->getOneField($data['recipient'], "ref", "account_name"); ?></td>
      </tr>
      <tr bgcolor="#CCCCCC">
        <td width="25%">Account Number</td>
        <td><?php echo $recipient_money->getOneField($data['recipient'], "ref", "account_number"); ?></td>
      </tr>
      <tr>
        <td width="25%">Bank</td>
        <td><?php echo $bank->getOneField($recipient_money->getOneField($data['recipient'], "ref", "bank"), "ref", "bank_name"); ?></td>
      </tr>
      <?php } ?>
      <tr bgcolor="#CCCCCC">
        <td width="25%">Type</td>
        <td><?php echo $data['type']; ?></td>
      </tr>
      <tr>
        <td width="25%">Created</td>
        <td><?php echo date('l jS \of F Y h:i:s A', $data['create_time']); ?></td>
      </tr>
      <tr bgcolor="#CCCCCC">
        <td width="25%">Last Modified</td>
        <td><?php echo date('l jS \of F Y h:i:s A', $data['modify_time']); ?></td>
      </tr>
    </table>
    </div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript">
	function setSelectedIndex(s, valsearch) {
		// Loop through all the items in drop down list
		for (i = 0; i< s.options.length; i++) { 
			if (s.options[i].value == valsearch) {
			// Item is found. Set its property and exit
			s.options[i].selected = true;
			break;
			}
		}
		return;
	}
	
	function setMultiSelectedIndex(s, data) {
		var main = data.split(",");
		// Loop through all the items in drop down list
		for (var j = 0; j < main.length; j++) {
			var opt = main[j];
			for (i = 0; i< s.options.length; i++) { 
				if (s.options[i].value == opt) {
				// Item is found. Set its property and exit
				s.options[i].selected = true;
				break;
				}
			}
		}
		return;
	}
	$(document).ready(function() {
		setSelectedIndex(document.getElementById("mainPage"),"<?php echo $editMain; ?>");
		setSelectedIndex(document.getElementById("level"),"<?php echo $editLevel; ?>");
		setMultiSelectedIndex(document.getElementById("pages"),"<?php echo $getData['pages']; ?>");
	});
</script>
</body>
</html>
