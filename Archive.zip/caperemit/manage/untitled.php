<?php
	include_once("../includes/functions.php");
	$data = $settings->listAll();
	print_r($data);
?>