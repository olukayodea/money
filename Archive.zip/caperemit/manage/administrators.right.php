<?php
	include_once("../includes/functions.php");
	
	$redirect = "administrators.right";
	include_once("session.php");
	//administrator
	
	if ((isset($_POST['addAdmin'])) || (isset($_POST['editButton']))) {
		$add = $admin->createAdminType($_POST);
		if ($add) {
			header("location: ?done");
		} else {
			header("location: ?error");
		}
	}
	
	if (isset($_GET['editAdmin'])) {
		$getData = $admin->listOneType($common->get_prep($_GET['id']));
		
		$editID = $getData['id'];
		$editName = $getData['title'];
		$editRead = $getData['read'];
		$editWrite = $getData['write'];
		$editLevel = $getData['level'];
		$editModify = $getData['modify'];
		$editMain = $getData['mainPage'];
		$editPagesRaw = explode(",", $getData['pages']);
		$editAdmin = true;
				
	} else if (isset($_GET['deactivateAdmin'])) {
		$edit = $admin->deactivate($common->get_prep($_GET['id']));
		if ($edit) {
			header("location: ?done");
		} else {
			header("location: ?error");
		} 
	} else if (isset($_GET['deleteAdmin'])) {
		$edit = $admin->delete($common->get_prep($_GET['id']));
		if ($edit) {
			header("location: ?done");
		} else {
			header("location: ?error");
		}
	}

	$listAdmin = $admin->listAdmintypes();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Administrator Setup :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Administrator Rights Manager</h3>
	<div class="bs-example4" data-example-id="simple-responsive-table">
    <h3>Add/Update Right</h3>
    <?php if (isset($_REQUEST['done'])) { ?>
       <div class="alert alert-success" role="alert">
        <strong>Well done!</strong> Actions performed successfully
       </div>
    <?php } ?>
    <?php if (isset($_GET['error'])) { ?>
       <div class="alert alert-danger" role="alert">
        <strong>Oh snap!</strong> An error occured, please try again. <?php echo $common->get_prep($_GET['error']); ?>
       </div>
    <?php } ?>
    <div class="table-responsive">
    <form class="form-horizontal" method="post" action="" onsubmit="return vlidate()">
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Title <em>*</em><small>Enter administrator full name</small></label>
            <div class="col-sm-8">
                <input type="text" class="form-control1" name="title"<?php if (isset($_REQUEST['view'])) { ?> disabled<?php } ?> id="title" value="<?php echo $editName; ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="read" class="col-sm-2 control-label">List <em>*</em><small>Enable permission for users to list entries</small></label>
            <div class="col-sm-8">
                <input name="read" type="checkbox"<?php if (isset($_REQUEST['view'])) { ?> disabled<?php } ?> id="read" value="1" checked readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="write" class="col-sm-2 control-label">Create <em>*</em><small>Enable permissions for users to create entries</small></label>
            <div class="col-sm-8">
                <input type="checkbox" name="write"<?php if (isset($_REQUEST['view'])) { ?> disabled<?php } ?> id="write"<?php if ($editWrite == 1) { ?> checked<?php } ?> value="1">
            </div>
        </div>
        <div class="form-group">
            <label for="write" class="col-sm-2 control-label">Modify <em>*</em><small>Enable permissions for users to modify entries</small></label>
            <div class="col-sm-8">
                <input type="checkbox" name="modify"<?php if (isset($_REQUEST['view'])) { ?> disabled<?php } ?> id="modify"<?php if ($editModify == 1) { ?> checked<?php } ?> value="1">
            </div>
        </div>
        <div class="form-group">
            <label for="level" class="col-sm-2 control-label">Level <em>*</em><small>Define access level for user type </small></label>
            <div class="col-sm-8">
            <select name="level" id="level"<?php if (isset($_REQUEST['view'])) { ?> disabled<?php } ?> class="form-control1">
                <option>Select</option>
                <option value="1">Normal User</option>
                <option value="2">Admin Users</option>
                <option value="3">Power Users</option>
                <option value="4">System Users</option>
              </select>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label" for="mainPage">Main Page<em>*</em><small>Landing page for user type</small></label>
            <div class="col-sm-8">
                <select name="mainPage" id="mainPage" <?php if (isset($_REQUEST['view'])) { ?> disabled<?php } ?> class="form-control1">
                    <option>Select</option>
                    <option value="index" selected>Dashboard</option>
                    <optgroup label="Transactions">
                        <option value="transactions">Transactions</option>
                        <option value=" transactions.view">View Transactions</option>
                    </optgroup>
                    <optgroup label="Settings">
                    	<option value="settings">Default Values</option>
                    	<option value="settings.bank">Setup Banks</option>
                    </optgroup>
                    <optgroup label="Users">
						<option value="customers">Customers</option>
						<option value="customers.manage">Manage Customers</option>
                        <option value="administrators">Manage Administrators</option>
                        <option value="profile">Manage Profile</option>
                        <option value="account">Manage Profile Password</option>
                        <option value="administrators.right">Manage Administrator Rights</option>
                    </optgroup>
                    <optgroup label="Reports">
                        <option value="systemLog">System Log</option>
                        <option value="visitorLog">Visitors Log</option>
                    </optgroup>
                  </select>
            </div>
        </div>
        <div class="form-group">
            <label for="pages" class="col-sm-2 control-label">Allowable Pages<em>*</em><small>Pages the user can access. To select multiple vlue press and hold [CRTL] for windows or [cmd] for Mac while clicking</small></label>
            <div class="col-sm-8">
            	<select name="pages[]" size="9" multiple="multiple" class="form-control1" id="pages"<?php if (isset($_REQUEST['view'])) { ?> disabled<?php } ?>>
                    <option value="index" selected>Dashboard</option>
                    <optgroup label="Transactions">
                        <option value="transactions">Transactions</option>
                        <option value=" transactions.view">View Transactions</option>
                    </optgroup>
                    <optgroup label="Settings">
                    	<option value="settings">Default Values</option>
                    	<option value="settings.bank">Setup Banks</option>
                    </optgroup>
                    <optgroup label="Users">
						<option value="customers">Customers</option>
						<option value="customers.manage">Manage Customers</option>
                        <option value="administrators">Manage Administrators</option>
                        <option value="profile">Manage Profile</option>
                        <option value="account">Manage Profile Password</option>
                        <option value="administrators.right">Manage Administrator Rights</option>
                    </optgroup>
                    <optgroup label="Reports">
                        <option value="systemLog">System Log</option>
                        <option value="visitorLog">Visitors Log</option>
                    </optgroup>
                  </select>
            </div>
        </div>
      <div class="panel-footer">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
                <?php if ($editAdmin === true) { ?>
					<?php if (!isset($_GET['view'])) { ?>
                        <input type="hidden" name="id" value="<?php echo $editID; ?>">
                        <button class="btn-default btn" name="editButton" id="editButton" type="submit" data-icon-primary="ui-icon-circle-check">Save Changes</button>
                    <?php } ?>
                	<button class="btn-default btn" name="button2" id="button" type="button" onClick="location='<?php echo $redirect; ?>'" data-icon-primary="ui-icon-circle-check">Cancel</button>
                <?php } else { ?>
                	<button class="btn-default btn" name="addAdmin" id="addAdmin" type="submit" data-icon-primary="ui-icon-circle-check">Add</button>
                <?php } ?>
			</div>
		</div>
	 </div>
    </form>
    </div>
    <h3>List All</h3>
    <div class="table-responsive">
      <table class="table table-bordered dataTable" id="example">
        <thead>
          <tr>
            <th>&nbsp;</td>
            <th><strong>Title</strong></th>
            <th><strong>Level</strong></th>
            <th><strong>Read</strong></th>
            <th><strong>Write</strong></th>
            <th><strong>Modify</strong></th>
            <th><strong>Creation Date</strong></th>
            <th><strong>Modified Last</strong></th>
            <th>&nbsp;</th>
          </tr>
        </thead>
        <tbody>
          <?php for ($i = 0; $i < count($listAdmin); $i++) {
                        $sn++; ?>
          <tr>
            <td><?php echo $sn; ?></td>
            <td><?php echo $listAdmin[$i]['title']; ?></td>
            <td><?php echo $admin->getReadable($listAdmin[$i]['level'], "level"); ?></td>
            <td><?php echo $admin->getReadable($listAdmin[$i]['read']); ?></td>
            <td><?php echo $admin->getReadable($listAdmin[$i]['write']); ?></td>
            <td><?php echo $admin->getReadable($listAdmin[$i]['modify']); ?></td>
            <td><?php echo $common->get_time_stamp($listAdmin[$i]['createTime']); ?></td>
            <td><?php echo $common->get_time_stamp($listAdmin[$i]['modifyTime']); ?></td>
            <td><a href="?view&editAdmin&id=<?php echo $listAdmin[$i]['id']; ?>">view</a> | <a href="?editAdmin&id=<?php echo $listAdmin[$i]['id']; ?>">edit</a> | <a href="?copy&editAdmin&id=<?php echo $listAdmin[$i]['id']; ?>">copy</a></td>
          </tr>
          <?php }
                        unset($i); 
              unset($sn); ?>
        </tbody>
      </table>
    </div><!-- /.table-responsive -->
  </div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript">
	function setSelectedIndex(s, valsearch) {
		// Loop through all the items in drop down list
		for (i = 0; i< s.options.length; i++) { 
			if (s.options[i].value == valsearch) {
			// Item is found. Set its property and exit
			s.options[i].selected = true;
			break;
			}
		}
		return;
	}
	
	function setMultiSelectedIndex(s, data) {
		var main = data.split(",");
		// Loop through all the items in drop down list
		for (var j = 0; j < main.length; j++) {
			var opt = main[j];
			for (i = 0; i< s.options.length; i++) { 
				if (s.options[i].value == opt) {
				// Item is found. Set its property and exit
				s.options[i].selected = true;
				break;
				}
			}
		}
		return;
	}
	$(document).ready(function() {
		setSelectedIndex(document.getElementById("mainPage"),"<?php echo $editMain; ?>");
		setSelectedIndex(document.getElementById("level"),"<?php echo $editLevel; ?>");
		setMultiSelectedIndex(document.getElementById("pages"),"<?php echo $getData['pages']; ?>");
	});
</script>
</body>
</html>
