<?php
	include_once("../includes/functions.php");
	
	$redirect = "settings.bank";
	include_once("session.php");
	//administrator
	
	if ((isset($_POST['addAdmin'])) || (isset($_POST['editButton']))) {
		$add = $bank->add($_POST);
		if ($add) {
			header("location: ?done");
		} else {
			header("location: ?error");
		}
	}
	
	if (isset($_GET['editAdmin'])) {
		$getData = $bank->getOne($common->get_prep($_GET['id']));
		
		$editAdmin = true;
			
	} else if (isset($_GET['deleteAdmin'])) {
		$edit = $bank->delete($common->get_prep($_GET['id']));
		if ($edit) {
			header("location: ?done");
		} else {
			header("location: ?error");
		}
	}

	$listAdmin = $bank->listAll();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Bank Setup :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Settings</h3>
	<div class="bs-example4" data-example-id="simple-responsive-table">
    <h3>Add/Update Banks</h3>
    <?php if (isset($_REQUEST['done'])) { ?>
       <div class="alert alert-success" role="alert">
        <strong>Well done!</strong> Actions performed successfully
       </div>
    <?php } ?>
    <?php if (isset($_GET['error'])) { ?>
       <div class="alert alert-danger" role="alert">
        <strong>Oh snap!</strong> An error occured, please try again. <?php echo $common->get_prep($_GET['error']); ?>
       </div>
    <?php } ?>
    <div class="table-responsive">
    <form class="form-horizontal" method="post" action="">
        <div class="form-group">
            <label for="bank_name" class="col-sm-2 control-label">Name <em>*</em><small>Enter bank name</small></label>
            <div class="col-sm-8"><span id="sprytextfield1">
              <input type="text" class="form-control1" name="bank_name" id="bank_name" value="<?php echo $getData['bank_name']; ?>" required>
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
        <div class="form-group">
            <label for="bank_code" class="col-sm-2 control-label">Sort Code <em>*</em><small>Enter bank 3 digit sort code</small></label>
            <div class="col-sm-8"><span id="sprytextfield2">
              <input name="bank_code" type="text" required class="form-control1" id="bank_code" value="<?php echo $getData['bank_code']; ?>" maxlength="3">
              <span class="textfieldRequiredMsg">A value is required.</span></span></div>
        </div>
      <div class="panel-footer">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
                <?php if ($editAdmin === true) { ?>
                    <input type="hidden" name="ref" id="ref" value="<?php echo $getData['ref']; ?>">
                    <button class="btn-default btn" name="editButton" id="editButton" type="submit" data-icon-primary="ui-icon-circle-check">Save Changes</button>
                    <button class="btn-default btn" name="button2" id="button" type="button" onClick="location='<?php echo $redirect; ?>'" data-icon-primary="ui-icon-circle-check">Cancel</button>
				<?php } else { ?>
                    <button class="btn-default btn" name="addAdmin" id="addAdmin" type="submit" data-icon-primary="ui-icon-circle-check">Add</button>
                <?php } ?>
			</div>
		</div>
	 </div>
    </form>
    </div>
    <h3>List All</h3>
    <div class="table-responsive">
      <table class="table table-bordered dataTable" id="example">
        <thead>
          <tr>
            <th>&nbsp;</td>
            <th><strong>Bank Name</strong></th>
            <th><strong>Sort Code</strong></th>
            <th><strong>Created</strong></th>
            <th>&nbsp;</th>
          </tr>
        </thead>
        <tbody>
          <?php for ($i = 0; $i < count($listAdmin); $i++) {
                        $sn++; ?>
          <tr>
            <td><?php echo $sn; ?></td>
            <td><?php echo $listAdmin[$i]['bank_name']; ?></td>
            <td><?php echo $listAdmin[$i]['bank_code']; ?></td>
            <td><?php echo $common->get_time_stamp($listAdmin[$i]['create_time']); ?></td>
            <td><a href="?editAdmin&id=<?php echo $listAdmin[$i]['ref']; ?>">edit</a> | <a href="?deleteAdmin&id=<?php echo $listAdmin[$i]['ref']; ?>" onclick="return confirm('Are you sure you want to delete this Bank??');">Delete</a></td>
          </tr>
          <?php }
                        unset($i); 
              unset($sn); ?>
        </tbody>
      </table>
    </div><!-- /.table-responsive -->
  </div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
</div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
</script>
</body>
</html>
