<?php
	$redirect = "transactions";
	include_once("../includes/functions.php");
	include_once("session.php");
	
	if (isset($_REQUEST['today'])) {
		$tag = "Today";
		$upperBand = time();
		$lowerBand = mktime(0, 0, 0, date('m'), date('j'), date('y'));
		$list = $transactions->getRange("modify_time", $lowerBand, $upperBand);
	} else if (isset($_REQUEST['yesterday'])) {
		$tag = "Yesterday";
		$upperBand = mktime(23, 59, 59, date('m'), date('j')-1, date('y'));
		$lowerBand = mktime(0, 0, 0, date('m'), date('j')-1, date('y'));
		$list = $transactions->getRange("modify_time", $lowerBand, $upperBand);
	} else if (isset($_REQUEST['week'])) {
		$tag = "This Week";
		$upperBand = time();
		$lowerBand = strtotime("last Sunday");
		$list = $transactions->getRange("modify_time", $lowerBand, $upperBand);
	} else if (isset($_REQUEST['month'])) {
		$tag = "This Month";
		$upperBand = time();
		$lowerBand = mktime(0, 0, 0, date('m'), 1, date('y'));
		$list = $transactions->getRange("modify_time", $lowerBand, $upperBand);
	} else if (isset($_REQUEST['lastMonth'])) {
		$tag = "Last Month";
		$upperBand = mktime(0, 0, 0, date('m'), 1, date('y'));
		$lowerBand = mktime(0, 0, 0, date('m')-1, 1, date('y'));
		$list = $transactions->getRange("modify_time", $lowerBand, $upperBand);
	} else if (isset($_REQUEST['year'])) {
		$tag = "This Year";
		$upperBand = time();
		$lowerBand = mktime(0, 0, 0, 1, 1, date('y'));
		$list = $transactions->getRange("modify_time", $lowerBand, $upperBand);
	} else {
		$list = $transactions->listAll();
	}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Transactions<?php echo $tag; ?>:: PayMack</title>
<?php $adminPages->mainHeader(); ?>
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Transactions <?php echo $tag; ?></h3>
  	 <div class="bs-example4" data-example-id="simple-responsive-table">
  	   <div class="table-responsive">
      <table class="table dataTable">
        <thead>
          <tr>
            <th>#</th>
            <th><strong>ID</strong></th>
            <th><strong>Amount</strong></th>
            <th><strong>Status</strong></th>
            <th><strong>User</strong></th>
            <th><strong>Creationd</strong></th>
            <th><strong>Modified</strong></th>
          </tr>
        </thead>
        <tbody>
		  <?php for ($i = 0; $i < count($list); $i++) {
                        $sn++; ?>
          <tr>
            <td><?php echo $sn; ?></td>
            <td><a href="<?php echo URLAdmin; ?>transactions.view?id=<?php echo $list[$i]['ref']; ?>"><?php echo $list[$i]['trax_id']; ?></a></td>
            <td><?php if ($list[$i]['tx_currency'] == "CA") {echo CAD; } else if ($list[$i]['tx_currency'] == "US") {echo USD; } else if ($list[$i]['tx_currency'] == "GB") { echo GBP; }
			echo number_format($list[$i]['tx_amount'], 2); ?></td>
            <td><?php echo $list[$i]['status']; ?></td>
            <td><?php echo $users->getOneField($list[$i]['user'], "ref", "last_name")." ".$users->getOneField($list[$i]['user'], "ref", "other_names"); ?></td>
            <td><?php echo $common->get_time_stamp($list[$i]['create_time']); ?></td>
            <td><?php echo $common->get_time_stamp($list[$i]['modify_time']); ?></td>
          </tr>
          <?php }
                        unset($i); 
              unset($sn); ?>
        </tbody>
      </table>
    </div><!-- /.table-responsive -->
    <div class="table-responsive"></div><!-- /.table-responsive -->
</div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>