<?php
	$redirect = "index";
	include_once("../includes/functions.php");
	include_once("session.php");
	
	$upperBand = time();
	$lowerBand = mktime(0, 0, 0, date('m'), date('j'), date('y'));
	$todayData = $transactions->getRange("modify_time", $lowerBand, $upperBand);
	$today = count($todayData);
	$visit = count($visitorData->getUnigue($lowerBand, $upperBand));
	$totalVisit = count($visitorData->getVisit($lowerBand, $upperBand));
	$totalCust = count($users->listRange($lowerBand, $upperBand));
		
	$system_log_count = $system_log->countAl();
	$visitors_count = $visitorData->countAl();
	$admin_count = $admin->countAl();
	$customer_count = $users->countAl();
	$transaction_count = $transactions->countAl();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Home :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="graphs">
     	<div class="col_3">
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-thumbs-up icon-rounded" title="total transactions Tooday"></i>
                    <div class="stats">
                      <h5><strong><?php echo $common->numberPrintFormat($today); ?></strong></h5>
                      <span>Transactions</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-comment user2 icon-rounded" title="total visits Tooday"></i>
                    <div class="stats">
                      <h5><strong><?php echo $common->numberPrintFormat($totalVisit); ?></strong></h5>
                      <span>Total Visits</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-users user1 icon-rounded" title="Unique Visitors Tooday"></i>
                    <div class="stats">
                      <h5><strong><?php echo $common->numberPrintFormat($visit); ?></strong></h5>
                      <span>Unique Visitors</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-comment user2 icon-rounded" title="New sign-ons Tooday"></i>
                    <div class="stats">
                      <h5><strong><?php echo $common->numberPrintFormat($totalCust); ?></strong></h5>
                      <span>Users</span>
                    </div>
                </div>
        	</div>
        	<div class="clearfix"> </div>
      </div>
     	<div class="span_11">
     	  <div class="clearfix"> </div>
    </div>
    <div class="content_bottom">
     <div class="col-md-8 span_3">
		  <div class="bs-example1" data-example-id="contextual-table">
		    <table class="table">
		      <thead>
		        <tr>
		          <th>#</th>
		          <th>Transaction ID</th>
		          <th>Amount</th>
		          <th>Status</th>
		        </tr>
		      </thead>
		      <tbody>
              <?php for ($i = 0; $i < count($todayData); $i++) {
				$sn++; ?>
		        <tr <?php if (($sn % 2) == 0) { ?> class="active"<?php } ?>>
                    <th scope="row">1<?php echo $sn; ?></td>
                    <td><a href="<?php echo URLAdmin; ?>transactions.view?id=<?php echo $todayData[$i]['ref']; ?>"><?php echo $todayData[$i]['trax_id']; ?></a></td>
                    <td><?php if ($todayData[$i]['tx_currency'] == "CA") {echo CAD; } else if ($todayData[$i]['tx_currency'] == "US") {echo USD; } else if ($todayData[$i]['tx_currency'] == "GB") { echo GBP; }
                    echo number_format($todayData[$i]['tx_amount'], 2); ?></td>
                    <td><?php echo $todayData[$i]['status']; ?></td>
		        </tr>
		      <?php }
				unset($i); 
				unset($sn); ?>
              </tbody>
		    </table>
		   </div>
	   </div>
	   <div class="col-md-4 span_4">
		 <div class="col_2">
		  <div class="box_1">
		   <div class="col-md-6 col_1_of_2 span_1_of_2">
             <a class="tiles_info">
			    <div class="tiles-head red1">
			        <div class="text-center">Trasactions</div>
			    </div>
			    <div class="tiles-body red"><?php echo $common->numberPrintFormat($transaction_count); ?></div>
			 </a>
		   </div>
		   <div class="col-md-6 col_1_of_2 span_1_of_2">
              <a class="tiles_info tiles_blue">
			    <div class="tiles-head tiles_blue1">
			        <div class="text-center">Customers</div>
			    </div>
			    <div class="tiles-body blue1"><?php echo $common->numberPrintFormat($customer_count); ?></div>
			  </a>
		   </div>
		   <div class="clearfix"> </div>
		 </div>
		 <div class="box_1">
		   <div class="col-md-6 col_1_of_2 span_1_of_2">
             <a class="tiles_info">
			    <div class="tiles-head fb1">
			        <div class="text-center">Admin</div>
			    </div>
			    <div class="tiles-body fb2"><?php echo $common->numberPrintFormat($admin_count); ?></div>
			 </a>
		   </div>
		   <div class="col-md-6 col_1_of_2 span_1_of_2">
              <a class="tiles_info tiles_blue">
			    <div class="tiles-head tw1">
			        <div class="text-center">System Log</div>
			    </div>
			    <div class="tiles-body tw2"><?php echo $common->numberPrintFormat($system_log_count); ?></div>
			  </a>
		   </div>
		   <div class="clearfix"> </div>
		   </div>
		  </div>
		  <div class="cloud">
			<div class="grid-date">
				<div class="date">
					<p class="date-in"><?php $_SESSION['location_data']["loc_city"]." ".$_SESSION['location_data']["loc_country"]; ?></p>
					<span class="date-on">°C </span>
					<div class="clearfix"> </div>							
				</div>
				<h4><?php echo ceil($_SESSION['location_data']["temp"]); ?>°<i class="fa fa-cloud-upload"> </i></h4>
			</div>
			<p class="monday"><?php echo date("l j F"); ?></p>
		  </div>
		</div>
		<div class="clearfix"> </div>
	    </div>
		<div class="copy">
            <p>Copyright &copy; <?php echo date("Y"); ?> PayMack. All Rights Reserved </p>
	    </div>
		</div>
       </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
