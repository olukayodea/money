<?php
	$redirect = "customers";
	include_once("../includes/functions.php");
	include_once("session.php");
	
	$list = $users->listAll();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Customers :: PayMack</title>
<?php $adminPages->mainHeader(); ?>
</head>
<body>
<div id="wrapper">
	<?php $adminPages->nav(); ?>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Customers</h3>
  	 <div class="bs-example4" data-example-id="simple-responsive-table">
  	   <div class="table-responsive">
      <table class="table dataTable">
        <thead>
          <tr>
            <th>#</th>
            <th>Names</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Status</th>
            <th>Created</th>
            <th>Last Modified</th>
          </tr>
        </thead>
        <tbody>
        <?php for ($i = 0; $i < count($list); $i++) {
			$sn++ ?>
          <tr>
            <th scope="row"><?php echo $sn; ?></th>
            <td><a href="customers.manage?id=<?php echo $list[$i]['ref']; ?>" title="View and edit"><?php echo $list[$i]['last_name']; ?> <?php echo $list[$i]['other_names']; ?></a></td>
            <td><a href="customers.manage?id=<?php echo $list[$i]['ref']; ?>" title="View and edit"><?php echo $list[$i]['email']; ?></a></td>
            <td><?php echo $list[$i]['phone']; ?></td>
            <td><?php echo $list[$i]['status']; ?></td>
            <td><?php echo $common->get_time_stamp($list[$i]['date_time']); ?></td>
            <td><?php echo $common->get_time_stamp($list[$i]['modify_time']); ?></td>
          </tr>
        <?php } ?>
        </tbody>
      </table>
    </div><!-- /.table-responsive -->
    <div class="table-responsive"></div><!-- /.table-responsive -->
</div>
  </div>
  <div class="copy_layout">
      <p>Copyright © <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>