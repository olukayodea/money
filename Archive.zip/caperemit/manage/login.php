<?php
	include_once("../includes/functions.php");
	//print_r($_SESSION);
	if ((isset($_REQUEST['redirect'])) && ($_REQUEST['redirect'] != "")) {
		$redirect = $common->get_prep($_REQUEST['redirect']);
		if ($redirect == "index") {
			$redirect = false;
		}
	} else {
		$redirect = false;
	}
	
	$urlParam = $common->getParam($_SERVER['REQUEST_URI']);
	$tagLink = $redirect."?".$urlParam;

	if (isset($_REQUEST['msg'])) {
		$er = $common->get_prep($_REQUEST['msg']);
	}
	
	if (isset($_GET['logout'])) {
		$logout = $admin->logout();
		header("location: login");
	} else if (isset($_POST['changePassword'])) {
		$password = $_POST['newPassword'];
		$activate = $admin->activate($password);
		
		header("location: ./");
	} else if (isset($_POST['Login2'])) {
		$check = $admin->passwordReset($_POST['reset_email']);
		
		if ($check) {
			header("location: ?loginDone=".urlencode("A new password has been sent to the email address you specified"));
		} else {
			header("location: ?reset&msg=".urlencode("We are sorry, no trace of this account was found in our records"));
		}
	} else if (isset($_POST['Login'])) {
		//print_r($_POST);
		$login = $admin->login($_POST);
		
		if ($login == 0) {
			$er = "Incorect username and password combination";
		} else if ($login == 1) {
			header("location: login?confirm");
		} else if ($login == 2) {
			if ($_SESSION['admin']['mainPage'] == "") {
				$mainPage = "index";
			} else {
				$mainPage = $_SESSION['admin']['mainPage'];
			}
			if ($redirect == false) {
				header("location: ".$mainPage);
			} else {
				header("location: ".$tagLink);
			}
		} else if ($login == 3) {
		} 
	}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Login :: PayMack</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="PayMack Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!----webfonts--->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</head>
<body id="login">
  <div class="login-logo">
    <a href="index.php">Cape Remit Administrator</a>
  </div>
  <h2 class="form-heading">login</h2>
  <div class="app-cam">
  <?php if (isset($_GET['loginDone'])) { ?>
  
       <div class="alert alert-success" role="alert">
        <strong>Well done!</strong> <?php echo $common->get_prep($_GET['loginDone']); ?>.
       </div>
<?php } else if (isset($_GET['confirm'])) { ?>
       <div class="alert alert-info" role="alert">
        <strong>Heads up!</strong> Please create new password.
       </div>
<?php } else if (isset($er)) { ?>
       <div class="alert alert-danger" role="alert">
        <strong>Oh snap!</strong> <?php echo $common->get_prep($er); ?>
       </div>
<?php } else if (isset($_REQUEST['msg'])) { ?>
       <div class="alert alert-warning" role="alert">
        <strong>Warning!</strong> <?php echo $common->get_prep($_GET['msg']); ?>
       </div>
<?php } ?>
	  <form id="form" action="" method="post">
	  <?php if (isset($_GET['reset'])) { ?>
        <input type="email" name="reset_email" id="reset_email" class="large" placeholder="Email Address" required>
		<div class="submit"><input type="submit" name="Reset Password" id="Login2"  value="Login2">
        </div>
      <?php } else if (!isset($_GET['confirm'])) { ?>
        <input type="text" name="username" id="username" class="large" placeholder="Enter Username" required>
        <input type="password" id="password" class="large" value="" name="password" required placeholder="password" />
		<div class="submit">
        	<input type="submit" name="Login" id="Login"  value="Login">
        </div>
      <?php } else { ?>
        <input type="password" id="newPassword"  class="large" value="" name="newPassword" required placeholder="new Password" />
        <input type="password" id="confirm" class="large" value="" name="confirm" required placeholder="confirm pssword" />
		<div class="submit">
        	<input type="submit" name="changePassword" id="changePassword"  value="Change Password">
        </div>
        <?php } ?>
		<ul class="new">
			<li class="new_left"><p><a href="<?php echo URLAdmin; ?>login?reset">Forgot Password ?</a></p></li>
			<li class="new_right"><p class="sign"><a href="<?php echo URLAdmin; ?>login"> Sign In</a></p></li>
			<div class="clearfix"></div>
		</ul>
	</form>
  </div>
   <div class="copy_layout login">
      <p>Copyright &copy; <?php echo date("Y"); ?> PayMack. All Rights Reserved</p>
   </div>
</body>
</html>
