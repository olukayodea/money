<?php
	$redirect = "sendMoney";
	include_once("includes/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Invite Friends</title>

<!-- Bootstrap -->
<?php $pages->headerFiles(); ?>
</head>
<body class="my-account">
<?php $pages->topMenuSession(); ?>
    
    <!--Body Part-->
       <div class="container">
         <div class="row margin-top10">
         <!--MY PROFILE-->
           <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" id="main-body">
             <div class="white-bg">
                <h2 class="header invite-con hidden-xs hidden-sm"><i class="glyphicons glyphicons-user-add"></i> INVITE FRIENDS</h2>
                 <div class="row padding-left-right15">
                   <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                     <h2><strong>Invite a friend and get a</strong></h2>
                     <p class="free-text"><strong>FREE TRANSFER!</strong></p>
                     <ul class="text-invite">
                        <li><strong>Invite a friend to use PayMack and get a free transfer to any destination.</strong></li>
                     	<li class="margin-top10"><strong>You’ll earn your free transfer reward when your invited friend makes a transfer of over £100 or equivalent.</strong></li>
                        <li class="margin-top10"><strong>Your invited friend will also get their first transfer free.</strong></li>
                     </ul>
                   </div>
                   <div class="col-xs-1 margin-top30 hidden-xs hidden-sm"><span><img src="images/border-line.png"></div>
                   <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 text-center">
                     <p class="text-sky small-box">0</p>
                     <span class="invites-text"><strong>INVITES SO FAR</strong></span>
                     </div>
                   </div> 
                      <p class="invite-friend"><strong>INVITE YOUR FRIENDS</strong></p>
                    <div class="email-box">
                      <div class="address-text"><strong>Add Email Addresses from</strong><span class="margin-left10"><img src="images/massage.png"></span><span class="margin-left10"><img src="images/yahoo.png"></span></div>
                    </div>
                    <div class="row margin-left20">
                       <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10">
                        <input class="form-control" placeholder="ADD EMAIL ADDRESSES" onfocus="this.placeholder = ''" onblur="this.placeholder = 'ADD EMAIL ADDRESSES'" type="text">
                    </div>
                    <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 margin-top15">
                        <textarea class="form-control margin-bottom10 font-size12 textarea" rows="6" cols="70">Hello,   
I’ll like to invite you to use a new money transfer service called PayMack. Their service is great and their rates are fantastic. Sign up now and get your first transfer absolutely free!
                        </textarea>
                      </div>
                    </div>
                    <div class="row margin-left20">
                    <div class="invite-btn"><a href="#" class="btn btn-red margin-top30">INVITE FRIENDS</a></div>
                      <div class=" text-sky margin-top40 font-size18"><strong>FRIENDS INVITED SO FAR</strong></div>
                      <div>You invited <strong>adebayofamilusi@gmail.com</strong> on 24/09/2015</div>
                      <div>You invited <strong>ifeoluwaooluyemi@gmail.com</strong> on 24/09/2015</div>
                  </div>
                </div>
              </div>
         <!--/MY PROFILE-->
         
         <!--Icon-Panel-->  
           <div class="col-xs-4 col-sm-12 col-md-12 col-lg-12 hidden-xs hidden-sm" id="sidebar">
            <div class="white-bg padding-top15">
              <div class="padding-left-right15 clearfix">
                  <div class="sky-box">
                  <div class="margin-top10 text-center font-size20"><strong>Hello</strong></div>
                  <span class="glyphicons glyphicons-user font-size70"></span>
                  <div class="margin-top10 text-center font-size20"><strong><?php echo $last_name." ".$other_names; ?></strong></div>
                </div>
                   <div id="box-panel"> 
              	<a href="sendMoney" class="money-box"> <span class="glyphicons glyphicons-credit-card font-size45"></span><span class="margin-top15 all-icon-box">Send Money</span> </a> 
                <a href="send-mobile-airtime.php" class="send-mobile-box"> <span><img src="images/mobile-phone-icon.png" height="44"></span><span class="margin-top15 all-icon-box">Send  Mobile Airtime</span> </a> 
                <a href="pay-bills.php"class="pay-bills-box"> <span><img src="images/bill.png" width="37" height="auto"></span><span class="margin-top15 all-icon-box">Pay Bills</span> </a> 
                <a href="myPayments" class="payments-box"> <span class="glyphicons glyphicons-circle-arrow-right small-payments-text"></span><span class="margin-top15 all-icon-box">My Payments</span> </a> 
                <a href="profile" class="profile-box"> <span class="glyphicons glyphicons-user font-size45"></span><span class="margin-top15 all-icon-box">My Profile</span> </a> 
                <a href="myRecipientList"class="recipients-box"> <span class="glyphicons glyphicons-group small-payments-text"></span><span class="margin-top15 all-icon-box">My Recipients</span> </a> 
                <a href="invite-friends.php" class="invite-box active"> <span class="glyphicons glyphicons-user-add small-payments-text"></span><span class="margin-top15 all-icon-box">Invite Friends</span> </a> 
                <a href="changePassword" class="password-box"> <span class="glyphicons glyphicons-lock"></span><span class="margin-top15 all-icon-box">Change Password</span> </a> 
             </div>
              </div>
            </div>
          </div>   
         <!--/Icon-Panel-->
         </div>
       </div>
    <!--/Body Part-->
  
    
  <?php $pages->homeFooter(); ?>
</body>
</html>